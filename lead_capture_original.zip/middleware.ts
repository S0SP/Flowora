import { createServerClient } from '@supabase/ssr';
import { NextResponse, type NextRequest } from 'next/server';

const WORKSPACE_COOKIE = 'fw_ws';

export async function middleware(request: NextRequest) {
  let supabaseResponse = NextResponse.next({ request });

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return request.cookies.getAll();
        },
        setAll(cookiesToSet: { name: string; value: string; options?: any }[]) {
          cookiesToSet.forEach(({ name, value }) =>
            request.cookies.set(name, value),
          );
          supabaseResponse = NextResponse.next({ request });
          cookiesToSet.forEach(({ name, value, options }) =>
            supabaseResponse.cookies.set(name, value, options),
          );
        },
      },
    },
  );

  const {
    data: { user },
  } = await supabase.auth.getUser();

  const pathname = request.nextUrl.pathname;
  const isAuthPage = pathname.startsWith('/auth');
  const isDashboard = pathname.startsWith('/dashboard');
  const isOnboarding = pathname.startsWith('/onboarding');
  const isApiRoute = pathname.startsWith('/api');
  const isPublicAsset = pathname.match(/\.(svg|png|jpg|jpeg|gif|webp|ico|css|js)$/);
  const isRoot = pathname === '/';

  // Redirect unauthenticated users away from protected routes
  if (!user && (isDashboard || isOnboarding)) {
    const url = request.nextUrl.clone();
    url.pathname = '/auth/login';
    return NextResponse.redirect(url);
  }

  // Redirect authenticated users away from auth/root to dashboard
  if (user && (isAuthPage || isRoot)) {
    const url = request.nextUrl.clone();
    url.pathname = '/dashboard';
    return NextResponse.redirect(url);
  }

  // For authenticated dashboard requests, resolve the active workspace
  if (user && isDashboard && !isApiRoute) {
    const workspaceId = request.cookies.get(WORKSPACE_COOKIE)?.value;

    if (!workspaceId) {
      // Look up the user's first active workspace
      try {
        const { data: membership } = await supabase
          .from('workspace_members')
          .select('workspace_id, workspaces(onboarding_completed)')
          .eq('user_id', user.id)
          .eq('status', 'active')
          .order('created_at', { ascending: true })
          .limit(1)
          .single();

        if (!membership) {
          // No workspace — go to onboarding
          const url = request.nextUrl.clone();
          url.pathname = '/onboarding';
          return NextResponse.redirect(url);
        }

        const ws = membership.workspaces as { onboarding_completed: boolean } | null;
        if (!ws?.onboarding_completed) {
          const url = request.nextUrl.clone();
          url.pathname = '/onboarding';
          const redirect = NextResponse.redirect(url);
          redirect.cookies.set(WORKSPACE_COOKIE, membership.workspace_id, {
            path: '/',
            httpOnly: true,
            sameSite: 'lax',
          });
          return redirect;
        }

        // Set workspace cookie and continue
        supabaseResponse.cookies.set(WORKSPACE_COOKIE, membership.workspace_id, {
          path: '/',
          httpOnly: true,
          sameSite: 'lax',
        });
      } catch {
        // If DB is unavailable (e.g., in dev without Supabase), continue
      }
    }
  }

  return supabaseResponse;
}

export const config = {
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)',
  ],
};
