import os
import re
import json

file_path = r"d:\wa\Flowra\mockup\brand_guideline and user flow.txt"
out_dir = r"d:\wa\Flowra\design_spec"

if not os.path.exists(out_dir):
    os.makedirs(out_dir)

with open(file_path, "r", encoding="utf-8") as f:
    content = f.read()

# Strategy to find all JSON objects in the file
# We will use regex to find all matches of '{' and then parse the JSON using a stack
extracted = 0

def extract_jsons(text):
    global extracted
    idx = 0
    while idx < len(text):
        idx = text.find('{', idx)
        if idx == -1:
            break
        
        # We found a brace, let's try to parse a JSON object
        brace_count = 0
        in_string = False
        escape = False
        end_idx = -1
        
        for i in range(idx, len(text)):
            c = text[i]
            if not escape and c == '"':
                in_string = not in_string
            
            if not in_string:
                if c == '{':
                    brace_count += 1
                elif c == '}':
                    brace_count -= 1
                    
            if brace_count == 0:
                end_idx = i
                break
                
            if c == '\\' and not escape:
                escape = True
            else:
                escape = False
                
        if end_idx != -1:
            json_str = text[idx:end_idx+1]
            try:
                data = json.loads(json_str)
                if isinstance(data, dict) and "meta" in data and "file" in data["meta"]:
                    filename = data["meta"]["file"]
                    filename = filename.split("—")[0].strip()
                    if not filename.endswith(".json"):
                        filename += ".json"
                    
                    with open(os.path.join(out_dir, filename), "w", encoding="utf-8") as out_f:
                        json.dump(data, out_f, indent=2)
                    print(f"Extracted: {filename}")
                    extracted += 1
                idx = end_idx + 1
            except json.JSONDecodeError:
                idx += 1
        else:
            idx += 1

extract_jsons(content)
print(f"Total files extracted: {extracted}")
