import os
import json

file_path = r"d:\wa\Flowra\mockup\frontend architecture.txt"
out_dir = r"d:\wa\Flowra\design_spec"

if not os.path.exists(out_dir):
    os.makedirs(out_dir)

with open(file_path, "r", encoding="utf-8") as f:
    content = f.read()

# Try to extract the JSON starting with '{' and ending properly
start = content.find('{')
if start != -1:
    brace_count = 0
    end = -1
    in_string = False
    escape = False
    for i in range(start, len(content)):
        c = content[i]
        if not escape and c == '"':
            in_string = not in_string
        if not in_string:
            if c == '{':
                brace_count += 1
            elif c == '}':
                brace_count -= 1
        if brace_count == 0:
            end = i
            break
        if c == '\\' and not escape:
            escape = True
        else:
            escape = False
            
    if end != -1:
        json_str = content[start:end+1]
        try:
            data = json.loads(json_str)
            filename = "flowora_frontend_stack.json"
            if "meta" in data and "file" in data["meta"]:
                filename = data["meta"]["file"]
            
            out_path = os.path.join(out_dir, filename)
            with open(out_path, "w", encoding="utf-8") as out_f:
                json.dump(data, out_f, indent=2)
            print(f"Successfully extracted to {out_path}")
        except json.JSONDecodeError as e:
            print(f"JSON Decode Error: {e}")
    else:
        print("Could not find matching end brace")
else:
    print("Could not find starting brace")
