"use client"

import React, { useState, useEffect } from "react"
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query"
import {
  DndContext,
  closestCorners,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragOverlay,
  DragStartEvent,
  DragOverEvent,
  DragEndEvent,
  useDroppable,
} from "@dnd-kit/core"
import {
  SortableContext,
  arrayMove,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
  useSortable,
} from "@dnd-kit/sortable"
import { CSS } from "@dnd-kit/utilities"
import { MoreHorizontal, Phone, Mail, FileText, CheckCircle2, MessageSquare, Zap, Mic, Plus } from "lucide-react"
import { Avatar, AvatarFallback } from "@/components/atoms/Avatar"
import { Badge } from "@/components/atoms/Badge"
import { mockDb, Lead } from "@/lib/api/mock-db"

type LeadCard = {
  id: string
  name: string
  source?: string
  phone?: string
  time?: string
  tags?: { text: string; class: string }[]
  type: "standard" | "simple" | "contacted" | "value" | "demo" | "value_time" | "converted"
  value?: string
  date?: string
  voice?: boolean
}

type ColumnData = {
  id: string
  title: string
  colorClass: string
  badgeBg: string
}

const initialColumns: ColumnData[] = [
  { id: "new", title: "New Lead", colorClass: "border-chart-2/40", badgeBg: "bg-chart-2/20 text-foreground" },
  { id: "contacted", title: "Contacted", colorClass: "border-primary/50", badgeBg: "bg-primary/20 text-foreground" },
  { id: "qualified", title: "Qualified", colorClass: "border-chart-4/50", badgeBg: "bg-chart-4/20 text-foreground" },
  { id: "proposal", title: "Proposal", colorClass: "border-lavender/50", badgeBg: "bg-lavender/20 text-foreground" },
  { id: "won", title: "Won", colorClass: "border-chart-5/50", badgeBg: "bg-chart-5/20 text-foreground" },
  { id: "lost", title: "Lost", colorClass: "border-chart-3/50", badgeBg: "bg-chart-3/20 text-foreground" },
]

function SortableItem({ id, item, onEdit }: { id: string; item: LeadCard, onEdit: () => void }) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id })

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.4 : 1,
  }

  return (
    <div ref={setNodeRef} style={style} {...attributes} {...listeners}>
      <LeadCardComponent item={item} onEdit={onEdit} />
    </div>
  )
}

function LeadCardComponent({ item, onEdit }: { item: LeadCard, onEdit: () => void }) {
  return (
    <div className="bg-card border rounded-xl p-3.5 shadow-sm hover:shadow-md transition-shadow cursor-grab active:cursor-grabbing group">
      <div className="flex items-start justify-between mb-2 relative">
        <div className="flex items-center gap-2">
          {item.type !== "simple" && item.type !== "value" && item.type !== "value_time" && item.type !== "converted" && (
            <Avatar className="h-8 w-8">
              <AvatarFallback className="text-[10px]">{item.name.substring(0, 2).toUpperCase()}</AvatarFallback>
            </Avatar>
          )}
          <div>
            <h4 className="font-semibold text-sm leading-tight">{item.name}</h4>
            {item.source && (
              <p className="text-[10px] text-muted-foreground flex items-center gap-1 mt-0.5">
                {item.source === "Google Sheet" ? <FileText className="h-3 w-3 text-chart-4" /> : null} {item.source}
              </p>
            )}
          </div>
        </div>
        <button onPointerDown={(e) => { e.stopPropagation(); onEdit() }} className="text-muted-foreground opacity-0 group-hover:opacity-100 hover:text-foreground z-10">
          {item.type === "converted" ? <span className="text-base" title="Celebration">🎉</span> : <MoreHorizontal className="h-4 w-4" />}
        </button>
      </div>

      {item.phone && <p className="text-xs text-muted-foreground mb-2 flex items-center gap-1"><Phone className="h-3 w-3" /> {item.phone}</p>}

      {item.tags && item.tags.length > 0 && (
        <div className="flex flex-wrap gap-1 mb-3">
          {item.tags.map((tag, idx) => (
            <Badge key={idx} className={`${tag.class} border-none font-medium px-2 py-0 h-5 text-[10px]`}>{tag.text}</Badge>
          ))}
        </div>
      )}

      {item.date && (
        <div className="bg-muted/50 rounded p-1.5 mb-3 flex flex-col gap-1">
          <span className="text-[11px] font-medium">📅 {item.date}</span>
          {item.voice && (
            <div className="flex items-center gap-1 text-[10px] text-lavender-foreground font-medium">
              <Mic className="h-3 w-3" /> Voice call done
            </div>
          )}
        </div>
      )}

      <div className="flex items-center justify-between text-muted-foreground border-t pt-2 mt-1">
        {item.time && <span className="text-[10px]">{item.time}</span>}
        {item.value && <span className={`text-[13px] font-bold ${item.type === "converted" ? "text-chart-4" : item.type === "value" ? "text-chart-4" : "text-foreground"}`}>{item.value}</span>}
        
        {item.type === "standard" && (
          <div className="flex gap-1.5">
            <MessageSquare className="h-3.5 w-3.5 text-chart-4" />
            <Mail className="h-3.5 w-3.5 text-chart-3" />
          </div>
        )}
        
        {item.type === "contacted" && !item.time && (
          <div className="flex items-center gap-2 text-[10px] font-medium w-full justify-between">
            <div className="flex items-center gap-1" title="Sent"><MessageSquare className="h-3 w-3" /> 3</div>
            <div className="flex items-center gap-1 text-chart-3" title="Read"><CheckCircle2 className="h-3 w-3" /> 3</div>
            <div className="flex items-center gap-1 text-chart-4" title="Replied"><Zap className="h-3 w-3" /> 2</div>
          </div>
        )}
      </div>
    </div>
  )
}

function SortableColumn({ col, items, onOpenAdd, onEditLead }: { col: ColumnData; items: LeadCard[], onOpenAdd: () => void, onEditLead: (id: string) => void }) {
  const { setNodeRef } = useDroppable({
    id: col.id,
    data: {
      type: "Column",
      col,
    },
  })

  return (
    <div className="w-[280px] flex-shrink-0 flex flex-col h-full">
      <div className={`flex items-center justify-between mb-3 border-b-2 ${col.colorClass} pb-2`}>
        <h3 className="font-semibold text-sm">{col.title}</h3>
        <Badge className={`${col.badgeBg} border-none font-semibold px-2 hover:${col.badgeBg}`}>{items.length}</Badge>
      </div>
      <div ref={setNodeRef} className="flex-1 overflow-y-auto space-y-3 pb-4 hide-scrollbar min-h-[150px]">
        <SortableContext items={items.map(i => i.id)} strategy={verticalListSortingStrategy}>
          {items.map((item) => (
            <SortableItem key={item.id} id={item.id} item={item} onEdit={() => onEditLead(item.id)} />
          ))}
        </SortableContext>
        {col.id === "new" && (
          <button onClick={onOpenAdd} className="w-full py-2 flex items-center justify-center gap-2 text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-muted/50 rounded-lg border border-transparent transition-colors mt-2">
            <Plus className="h-4 w-4" /> Add Lead
          </button>
        )}
      </div>
    </div>
  )
}

export function KanbanBoard({ onOpenAdd, onEditLead }: { onOpenAdd: () => void, onEditLead: (id: string) => void }) {
  const queryClient = useQueryClient()
  const { data: leads = [], isLoading } = useQuery({
    queryKey: ["leads"],
    queryFn: () => mockDb.getLeads()
  })

  const [items, setItems] = useState<Record<string, LeadCard[]>>({})
  const [activeId, setActiveId] = useState<string | null>(null)

  // Map db leads to UI columns
  useEffect(() => {
    if (leads.length > 0) {
      const newItems: Record<string, LeadCard[]> = {
        new: [],
        contacted: [],
        qualified: [],
        proposal: [],
        won: [],
        lost: []
      }
      leads.forEach((lead) => {
        if (newItems[lead.status]) {
          newItems[lead.status].push({
            id: lead.id,
            name: lead.name,
            source: lead.company,
            value: lead.value,
            type: lead.status === "won" ? "converted" : "standard"
          })
        }
      })
      setItems(newItems)
    }
  }, [leads])

  const updateLeadMutation = useMutation({
    mutationFn: ({ id, status }: { id: string, status: Lead["status"] }) => mockDb.updateLeadStatus(id, status),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["leads"] })
    }
  })

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 5,
      },
    }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  )

  const findContainer = (id: string) => {
    if (id in items) {
      return id
    }
    return Object.keys(items).find((key) => items[key].map(i => i.id).includes(id))
  }

  const handleDragStart = (event: DragStartEvent) => {
    setActiveId(event.active.id as string)
  }

  const handleDragOver = (event: DragOverEvent) => {
    const { active, over } = event
    if (!over) return

    const activeId = active.id as string
    const overId = over.id as string

    const activeContainer = findContainer(activeId)
    const overContainer = findContainer(overId)

    if (!activeContainer || !overContainer || activeContainer === overContainer) {
      return
    }

    setItems((prev) => {
      const activeItems = prev[activeContainer]
      const overItems = prev[overContainer]
      
      const activeIndex = activeItems.findIndex((i) => i.id === activeId)
      const overIndex = overId in prev ? overItems.length + 1 : overItems.findIndex((i) => i.id === overId)

      return {
        ...prev,
        [activeContainer]: [
          ...prev[activeContainer].filter((item) => item.id !== activeId)
        ],
        [overContainer]: [
          ...prev[overContainer].slice(0, overIndex),
          activeItems[activeIndex],
          ...prev[overContainer].slice(overIndex, prev[overContainer].length)
        ]
      }
    })
  }

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event
    if (!over) {
      setActiveId(null)
      return
    }

    const activeId = active.id as string
    const overId = over.id as string

    const activeContainer = findContainer(activeId)
    const overContainer = findContainer(overId)

    if (!activeContainer || !overContainer) {
      setActiveId(null)
      return
    }

    if (activeContainer !== overContainer) {
      // Changed column, trigger mutation
      updateLeadMutation.mutate({ id: activeId, status: overContainer as Lead["status"] })
    } else {
      const activeIndex = items[activeContainer].findIndex((i) => i.id === activeId)
      const overIndex = items[overContainer].findIndex((i) => i.id === overId)

      if (activeIndex !== overIndex) {
        setItems((items) => ({
          ...items,
          [overContainer]: arrayMove(items[overContainer], activeIndex, overIndex),
        }))
      }
    }

    setActiveId(null)
  }

  const activeItem = activeId
    ? Object.values(items).flat().find((i) => i.id === activeId)
    : null

  if (isLoading) {
    return <div className="flex-1 flex items-center justify-center text-muted-foreground p-8">Loading leads...</div>
  }

  return (
    <DndContext
      sensors={sensors}
      collisionDetection={closestCorners}
      onDragStart={handleDragStart}
      onDragOver={handleDragOver}
      onDragEnd={handleDragEnd}
    >
      <div className="flex gap-4 h-full p-6 w-max">
        <SortableContext items={initialColumns.map(c => c.id)}>
          {initialColumns.map((col) => (
            <SortableColumn key={col.id} col={col} items={items[col.id] || []} onOpenAdd={onOpenAdd} onEditLead={onEditLead} />
          ))}
        </SortableContext>
      </div>
      <DragOverlay>
        {activeItem ? (
          <div className="opacity-90 transform rotate-2">
            <LeadCardComponent item={activeItem} />
          </div>
        ) : null}
      </DragOverlay>
    </DndContext>
  )
}
