"use client"

import React, { useCallback } from "react"
import {
  ReactFlow,
  Background,
  Controls,
  MiniMap,
  useNodesState,
  useEdgesState,
  addEdge,
  Handle,
  Position,
  Connection,
  Edge,
  useReactFlow
} from "@xyflow/react"
import "@xyflow/react/dist/style.css"
import { Database, MessageSquare, Clock, Mail, Phone, Bell } from "lucide-react"
import { cn } from "@/lib/utils"

// ---------------------------------------------------------
// 1. Define Custom Node Component
// ---------------------------------------------------------
const iconMap: Record<string, React.ElementType> = {
  Database: Database,
  MessageSquare: MessageSquare,
  Clock: Clock,
  Mail: Mail,
  Phone: Phone,
  Bell: Bell,
}

const CustomNode = ({ data, selected }: { data: any; selected: boolean }) => {
  const Icon = iconMap[data.icon] || Database

  return (
    <div 
      className={cn(
        "w-[220px] shadow-sm cursor-pointer z-10 transition-transform bg-white rounded-[10px]",
        selected ? "ring-4 ring-[#FFE27C]/30 border-2 border-primary" : "border border-transparent"
      )}
      onClick={() => data.onClick && data.onClick(data.id)}
    >
      <Handle type="target" position={Position.Left} className="w-3 h-3 bg-white border-2 border-muted-foreground" />
      
      <div className={cn("rounded-t-[10px] p-2 flex items-center gap-2", data.headerBg)}>
        <Icon className={cn("h-4 w-4", data.iconColor)} />
        <span className={cn("text-[13px] font-semibold flex-1", data.titleColor)}>{data.title}</span>
        {data.badge && <span className="text-[10px] text-white/50">{data.badge}</span>}
      </div>
      <div className="bg-white border border-border border-t-0 rounded-b-[10px] p-3 space-y-1.5">
        {data.fields.map((field: any, idx: number) => (
          <div key={idx} className="flex justify-between items-center text-[12px]">
            <span className="text-muted-foreground">{field.label}</span>
            <span className="text-foreground font-medium truncate w-[100px] text-right">{field.value}</span>
          </div>
        ))}
      </div>

      <Handle type="source" position={Position.Right} className="w-3 h-3 bg-white border-2 border-muted-foreground" />
    </div>
  )
}

const nodeTypes = {
  customNode: CustomNode,
}

// ---------------------------------------------------------
// 2. Initial Setup
// ---------------------------------------------------------
export const initialNodes = [
  {
    id: "1",
    type: "customNode",
    position: { x: 50, y: 150 },
    data: {
      id: "google_sheet",
      title: "Google Sheet Trigger",
      icon: "Database",
      headerBg: "bg-foreground",
      iconColor: "text-white",
      titleColor: "text-primary",
      badge: "Trigger",
      fields: [
        { label: "Sheet", value: "Webinar Leads" },
        { label: "Interval", value: "60 sec" }
      ]
    }
  },
  {
    id: "2",
    type: "customNode",
    position: { x: 350, y: 50 },
    data: {
      id: "whatsapp",
      title: "WhatsApp Message",
      icon: "MessageSquare",
      headerBg: "bg-[#22C55E]",
      iconColor: "text-white",
      titleColor: "text-white",
      fields: [
        { label: "Template", value: "webinar_invite" }
      ]
    }
  },
  {
    id: "3",
    type: "customNode",
    position: { x: 350, y: 250 },
    data: {
      id: "delay1",
      title: "Delay",
      icon: "Clock",
      headerBg: "bg-muted",
      iconColor: "text-muted-foreground",
      titleColor: "text-foreground",
      fields: [
        { label: "Wait", value: "30 Minutes" }
      ]
    }
  },
  {
    id: "4",
    type: "customNode",
    position: { x: 650, y: 50 },
    data: {
      id: "email",
      title: "Send Email",
      icon: "Mail",
      headerBg: "bg-[#B1D8FC]",
      iconColor: "text-foreground",
      titleColor: "text-foreground",
      fields: [
        { label: "Template", value: "Confirmation" }
      ]
    }
  },
  {
    id: "5",
    type: "customNode",
    position: { x: 650, y: 250 },
    data: {
      id: "delay2",
      title: "Delay",
      icon: "Clock",
      headerBg: "bg-muted",
      iconColor: "text-muted-foreground",
      titleColor: "text-foreground",
      fields: [
        { label: "Wait", value: "2 Hours" }
      ]
    }
  },
  {
    id: "6",
    type: "customNode",
    position: { x: 950, y: 150 },
    data: {
      id: "voice",
      title: "Voice Call",
      icon: "Phone",
      headerBg: "bg-[#C4B1F9]",
      iconColor: "text-foreground",
      titleColor: "text-foreground",
      fields: [
        { label: "Voice", value: "Sophia" }
      ]
    }
  },
  {
    id: "7",
    type: "customNode",
    position: { x: 1250, y: 150 },
    data: {
      id: "reminder",
      title: "Reminder",
      icon: "Bell",
      headerBg: "bg-primary",
      iconColor: "text-foreground",
      titleColor: "text-foreground",
      fields: [
        { label: "Event", value: "Jan 20, 2026" },
        { label: "Reminders", value: "3 configured" }
      ]
    }
  }
]

export const initialEdges = [
  { id: "e1-2", source: "1", target: "2", animated: true, style: { stroke: "#22C55E", strokeWidth: 2 } },
  { id: "e1-3", source: "1", target: "3", type: "smoothstep" },
  { id: "e3-4", source: "3", target: "4", animated: true, style: { stroke: "#B1D8FC", strokeWidth: 2 } },
  { id: "e3-5", source: "3", target: "5", type: "smoothstep" },
  { id: "e5-6", source: "5", target: "6", animated: true, style: { stroke: "#C4B1F9", strokeWidth: 2 } },
  { id: "e6-7", source: "6", target: "7", animated: true, style: { stroke: "#FFE27C", strokeWidth: 2 } },
]

// ---------------------------------------------------------
// 3. Workflow Canvas Component
// ---------------------------------------------------------
export function WorkflowCanvas({ 
  nodes,
  edges,
  onNodesChange,
  onEdgesChange,
  onConnect,
  setNodes,
  setActiveRightPanel 
}: { 
  nodes: any[],
  edges: any[],
  onNodesChange: any,
  onEdgesChange: any,
  onConnect: any,
  setNodes: any,
  setActiveRightPanel: (id: string) => void 
}) {
  const { screenToFlowPosition } = useReactFlow()

  const onDragOver = useCallback((event: React.DragEvent) => {
    event.preventDefault()
    event.dataTransfer.dropEffect = "move"
  }, [])

  const onDrop = useCallback((event: React.DragEvent) => {
    event.preventDefault()

    const typeId = event.dataTransfer.getData("application/reactflow")
    if (!typeId) return

    const position = screenToFlowPosition({ x: event.clientX, y: event.clientY })

    let icon = "Database"
    let headerBg = "bg-foreground"
    let title = typeId
    if (typeId === "whatsapp") { icon = "MessageSquare"; headerBg = "bg-[#22C55E]"; title = "WhatsApp" }
    else if (typeId === "email") { icon = "Mail"; headerBg = "bg-[#B1D8FC]"; title = "Email" }
    else if (typeId === "voice") { icon = "Phone"; headerBg = "bg-[#C4B1F9]"; title = "Voice Call" }
    else if (typeId === "delay") { icon = "Clock"; headerBg = "bg-muted"; title = "Delay" }

    const newNode = {
      id: `${typeId}-${Date.now()}`,
      type: "customNode",
      position,
      data: {
        id: typeId,
        title,
        icon,
        headerBg,
        iconColor: "text-white",
        titleColor: headerBg === "bg-muted" || headerBg === "bg-[#B1D8FC]" ? "text-foreground" : "text-white",
        fields: [{ label: "Configure", value: "Required" }],
        onClick: setActiveRightPanel
      }
    }
    setNodes((nds) => nds.concat(newNode))
  }, [screenToFlowPosition, setNodes, setActiveRightPanel])

  return (
    <div className="w-full h-full relative">
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        onDrop={onDrop}
        onDragOver={onDragOver}
        nodeTypes={nodeTypes}
        fitView
        className="bg-background"
      >
        <Background gap={20} size={1} color="hsl(var(--border))" />
        <Controls className="bg-white border-border shadow-sm" />
      </ReactFlow>
    </div>
  )
}
