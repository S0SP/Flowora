import { NextRequest, NextResponse } from "next/server"
import { createClient, createAdminClient } from "@/lib/supabase/server"
import { getTenantContext } from "@/lib/tenant"
import { z } from "zod"

// GET /api/inbox/threads — paginated thread list
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const page = parseInt(searchParams.get("page") ?? "1")
  const limit = parseInt(searchParams.get("limit") ?? "30")
  const status = searchParams.get("status") ?? "open"
  const assigneeId = searchParams.get("assignee") ?? undefined
  const search = searchParams.get("q") ?? undefined
  const offset = (page - 1) * limit

  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const ctx = await getTenantContext(req)
  if (!ctx) return NextResponse.json({ error: "No workspace" }, { status: 400 })

  let query = supabase
    .from("threads")
    .select(`
      id, status, channel, assigned_to, created_at, updated_at, ai_active, unread_count, last_message_at,
      contacts!threads_contact_id_fkey(id, full_name, phone, email, avatar_url, lead_score),
      messages(id, content, type, sender_type, created_at, status)
    `, { count: "exact" })
    .eq("workspace_id", ctx.workspaceId)
    .order("last_message_at", { ascending: false })
    .range(offset, offset + limit - 1)

  if (status !== "all") query = query.eq("status", status)
  if (assigneeId) query = query.eq("assigned_to", assigneeId)

  const { data, count, error } = await query
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })

  return NextResponse.json({
    threads: data ?? [],
    total: count ?? 0,
    page,
    limit,
  })
}

// POST /api/inbox/threads — create new thread (outbound conversation)
export async function POST(req: NextRequest) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const ctx = await getTenantContext(req)
  if (!ctx) return NextResponse.json({ error: "No workspace" }, { status: 400 })

  const body = await req.json()
  const { contactId, channel, initialMessage } = body

  if (!contactId || !channel) {
    return NextResponse.json({ error: "contactId and channel required" }, { status: 400 })
  }

  const { data: thread, error } = await supabase.from("threads").insert({
    workspace_id: ctx.workspaceId,
    contact_id: contactId,
    channel,
    status: "open",
    assigned_to: user.id,
    ai_active: true,
    created_by: user.id,
  }).select("id").single()

  if (error || !thread) return NextResponse.json({ error: error?.message }, { status: 500 })

  if (initialMessage) {
    await supabase.from("messages").insert({
      workspace_id: ctx.workspaceId,
      thread_id: thread.id,
      content: initialMessage,
      sender_type: "agent",
      sender_id: user.id,
      type: "text",
      status: "sent",
    })
  }

  return NextResponse.json({ threadId: thread.id }, { status: 201 })
}
