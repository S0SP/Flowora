import { NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"
import { getTenantContext } from "@/lib/tenant"

// GET /api/inbox/threads/[id]/messages
export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id: threadId } = await params
  const { searchParams } = new URL(req.url)
  const cursor = searchParams.get("cursor") ?? undefined
  const limit = parseInt(searchParams.get("limit") ?? "50")

  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const ctx = await getTenantContext(req)
  if (!ctx) return NextResponse.json({ error: "No workspace" }, { status: 400 })

  let query = supabase
    .from("messages")
    .select("id, content, type, sender_type, sender_id, status, created_at, metadata, file_url, file_name, file_size")
    .eq("workspace_id", ctx.workspaceId)
    .eq("thread_id", threadId)
    .order("created_at", { ascending: true })
    .limit(limit)

  if (cursor) query = query.gt("created_at", cursor)

  const { data, error } = await query
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })

  // Mark as read
  await supabase.from("threads")
    .update({ unread_count: 0 })
    .eq("id", threadId)
    .eq("workspace_id", ctx.workspaceId)

  return NextResponse.json({ messages: data ?? [] })
}

// POST /api/inbox/threads/[id]/messages — send a message
export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id: threadId } = await params

  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const ctx = await getTenantContext(req)
  if (!ctx) return NextResponse.json({ error: "No workspace" }, { status: 400 })

  const body = await req.json()
  const { content, type = "text", isNote = false } = body

  if (!content?.trim()) return NextResponse.json({ error: "content required" }, { status: 400 })

  const { data: msg, error } = await supabase.from("messages").insert({
    workspace_id: ctx.workspaceId,
    thread_id: threadId,
    content: content.trim(),
    type,
    sender_type: isNote ? "note" : "agent",
    sender_id: user.id,
    status: "sent",
  }).select("id, content, type, sender_type, created_at, status").single()

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })

  // Update thread last_message_at
  await supabase.from("threads").update({ last_message_at: new Date().toISOString() }).eq("id", threadId)

  return NextResponse.json({ message: msg }, { status: 201 })
}
