import { NextRequest, NextResponse } from "next/server"
import { createAdminClient } from "@/lib/supabase/server"

const VERIFY_TOKEN = process.env.META_VERIFY_TOKEN ?? "flowora_webhook_verify"

// GET — WhatsApp webhook verification challenge
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const mode = searchParams.get("hub.mode")
  const token = searchParams.get("hub.verify_token")
  const challenge = searchParams.get("hub.challenge")

  if (mode === "subscribe" && token === VERIFY_TOKEN) {
    console.log("[WhatsApp Webhook] Verified")
    return new NextResponse(challenge, { status: 200 })
  }
  return new NextResponse("Forbidden", { status: 403 })
}

// POST — Receive incoming WhatsApp messages
export async function POST(req: NextRequest) {
  const body = await req.json()
  const admin = await createAdminClient()

  // Extract entries from WhatsApp Cloud API payload
  const entries = body?.entry ?? []

  for (const entry of entries) {
    const changes = entry?.changes ?? []
    for (const change of changes) {
      const value = change?.value
      if (!value) continue

      const phoneNumberId: string = value.metadata?.phone_number_id
      const messages: any[] = value.messages ?? []
      const contacts: any[] = value.contacts ?? []
      const statuses: any[] = value.statuses ?? []

      // ── Handle incoming messages ────────────────────────────────────────
      for (const msg of messages) {
        const waId: string = msg.from // sender phone in E.164 format
        const waName = contacts.find((c: any) => c.wa_id === waId)?.profile?.name ?? null

        // Find workspace by phone_number_id
        const { data: channelConn } = await admin
          .from("channel_connections")
          .select("workspace_id, id")
          .eq("type", "whatsapp")
          .filter("config->phoneNumberId", "eq", phoneNumberId)
          .single()

        if (!channelConn) {
          console.warn("[WhatsApp Webhook] No workspace for phone_number_id:", phoneNumberId)
          continue
        }

        const workspaceId: string = channelConn.workspace_id

        // Find or create contact
        let { data: contact } = await admin
          .from("contacts")
          .select("id")
          .eq("workspace_id", workspaceId)
          .eq("phone", waId)
          .single()

        if (!contact) {
          const { data: newContact } = await admin.from("contacts").insert({
            workspace_id: workspaceId,
            phone: waId,
            full_name: waName ?? waId,
            channel: "whatsapp",
          }).select("id").single()
          contact = newContact
        }

        if (!contact) continue

        // Find or create open thread
        let { data: thread } = await admin
          .from("threads")
          .select("id")
          .eq("workspace_id", workspaceId)
          .eq("contact_id", contact.id)
          .eq("status", "open")
          .order("created_at", { ascending: false })
          .limit(1)
          .single()

        if (!thread) {
          const { data: newThread } = await admin.from("threads").insert({
            workspace_id: workspaceId,
            contact_id: contact.id,
            channel: "whatsapp",
            status: "open",
            ai_active: true,
            channel_connection_id: channelConn.id,
          }).select("id").single()
          thread = newThread
        }

        if (!thread) continue

        // Extract message content
        let content = ""
        let type = "text"
        let fileUrl: string | null = null
        let fileName: string | null = null
        let fileSize: number | null = null

        if (msg.type === "text") {
          content = msg.text?.body ?? ""
        } else if (msg.type === "image") {
          type = "image"
          content = msg.image?.caption ?? ""
          fileUrl = msg.image?.id ?? null // WhatsApp media ID (needs separate download)
        } else if (msg.type === "document") {
          type = "file"
          content = msg.document?.caption ?? ""
          fileUrl = msg.document?.id ?? null
          fileName = msg.document?.filename ?? null
        } else if (msg.type === "audio" || msg.type === "voice") {
          type = "audio"
          fileUrl = msg.audio?.id ?? msg.voice?.id ?? null
        } else {
          content = `[${msg.type} message]`
        }

        // Persist message
        await admin.from("messages").insert({
          workspace_id: workspaceId,
          thread_id: thread.id,
          wa_message_id: msg.id,
          content,
          type,
          sender_type: "contact",
          sender_id: contact.id,
          status: "delivered",
          file_url: fileUrl,
          file_name: fileName,
          file_size: fileSize,
          metadata: { waId, waName, raw: msg },
        })

        // Update thread
        await admin.from("threads").update({
          last_message_at: new Date().toISOString(),
          unread_count: admin.rpc("increment_unread", { thread_id: thread.id }),
        }).eq("id", thread.id)
      }

      // ── Handle message status updates ────────────────────────────────────
      for (const status of statuses) {
        const waMessageId = status.id
        const newStatus = status.status // sent | delivered | read | failed

        if (waMessageId && newStatus) {
          await admin.from("messages")
            .update({ status: newStatus })
            .eq("wa_message_id", waMessageId)
        }
      }
    }
  }

  return NextResponse.json({ ok: true })
}
