"use client"

import React, { useState, useEffect, useRef } from "react"
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query"
import { Search, Filter, Plus, Phone, Video, MoreVertical, Paperclip, Smile, Zap, Send, Edit2, User, Building, Clock, Tag, Bot, ChevronDown, Check, CheckCheck, FileText, File, Calendar, BarChart2, Mic, Grid, MapPin } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/atoms/Avatar"
import { Input } from "@/components/atoms/Input"
import { Badge } from "@/components/atoms/Badge"
import { cn } from "@/lib/utils"
import { mockDb, Thread, Message, Contact } from "@/lib/api/mock-db"
import { useInboxStore } from "@/lib/store/useInboxStore"
import { format } from "date-fns"

export default function InboxPage() {
  const [activeTopTab, setActiveTopTab] = useState("All")
  const [chatFilter, setChatFilter] = useState<"My Chats" | "All Chats">("My Chats")
  const { selectedThreadId, setSelectedThreadId, drafts, setDraft, clearDraft } = useInboxStore()
  const queryClient = useQueryClient()
  
  const [composerText, setComposerText] = useState("")
  const [composerMode, setComposerMode] = useState<"Reply" | "Note">("Reply")
  const chatScrollRef = useRef<HTMLDivElement>(null)

  const [collapsedSections, setCollapsedSections] = useState<Record<string, boolean>>({
    leadScore: false,
    contactDetails: false,
    tags: false,
    assignedTo: false,
    events: false
  })

  const toggleSection = (section: string) => {
    setCollapsedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }))
  }

  const { data: threads = [], isLoading: loadingThreads } = useQuery({
    queryKey: ["threads"],
    queryFn: () => mockDb.getThreads()
  })

  useEffect(() => {
    if (!selectedThreadId && threads.length > 0) {
      setSelectedThreadId(threads[0].id)
    }
  }, [threads, selectedThreadId, setSelectedThreadId])

  const { data: messages = [], isLoading: loadingMessages } = useQuery({
    queryKey: ["messages", selectedThreadId],
    queryFn: () => mockDb.getMessages(selectedThreadId!),
    enabled: !!selectedThreadId
  })

  // Auto-scroll to bottom of chat
  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight
    }
  }, [messages])

  const { data: contacts = [] } = useQuery({
    queryKey: ["contacts"],
    queryFn: () => mockDb.getContacts()
  })

  useEffect(() => {
    if (selectedThreadId) {
      setComposerText(drafts[selectedThreadId] || "")
    }
  }, [selectedThreadId, drafts])

  const handleComposerChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setComposerText(e.target.value)
    if (selectedThreadId) {
      setDraft(selectedThreadId, e.target.value)
    }
  }

  const sendMessageMutation = useMutation({
    mutationFn: (content: string) => mockDb.sendMessage(selectedThreadId!, content),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["messages", selectedThreadId] })
      queryClient.invalidateQueries({ queryKey: ["threads"] })
      if (selectedThreadId) clearDraft(selectedThreadId)
      setComposerText("")
    }
  })

  const handleSend = () => {
    if (composerText.trim() && selectedThreadId) {
      sendMessageMutation.mutate(composerText)
    }
  }

  const activeThread = threads.find(t => t.id === selectedThreadId)
  const contact = contacts.find(c => c.id === activeThread?.contactId)

  // Group threads (mocking the UI sections)
  const activeThreads = threads.slice(0, 4)
  const requestingThreads = threads.slice(4)

  const topTabs = [
    { name: "All", count: 132 },
    { name: "Open", count: 88 },
    { name: "Bot", count: 34 },
    { name: "Unread", count: 49 },
    { name: "Closed", count: 791 },
  ]

  return (
    <div className="flex flex-col h-full overflow-hidden bg-card border border-border shadow-sm rounded-xl">
      {/* Shared Inbox Top Nav Row */}
      <div className="flex-shrink-0 border-b border-border bg-card px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-6">
          <h1 className="text-xl font-bold mr-4">Shared Inbox</h1>
          <div className="flex items-center gap-1">
            {topTabs.map((tab) => (
              <button
                key={tab.name}
                onClick={() => setActiveTopTab(tab.name)}
                className={cn(
                  "px-4 py-1.5 rounded-full text-sm font-medium flex items-center gap-2 transition-all",
                  activeTopTab === tab.name 
                    ? "text-primary border-b-2 border-primary rounded-none -mb-[17px] pb-[19px]" 
                    : "text-muted-foreground hover:text-foreground"
                )}
              >
                {tab.name}
                <span className={cn(
                  "text-xs px-2 py-0.5 rounded-full",
                  activeTopTab === tab.name ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"
                )}>{tab.count}</span>
              </button>
            ))}
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button className="flex items-center gap-1.5 px-2.5 py-1.5 border border-border rounded-lg text-xs font-medium text-muted-foreground hover:bg-muted transition-colors">
            <Filter className="h-3.5 w-3.5" /> Filter
          </button>
          <button className="flex items-center gap-1.5 px-2.5 py-1.5 border border-border rounded-lg text-xs font-medium text-muted-foreground hover:bg-muted transition-colors">
            <BarChart2 className="h-3.5 w-3.5 rotate-90" /> Sort
          </button>
          <button className="flex items-center gap-1.5 px-2.5 py-1.5 border border-border rounded-lg text-xs font-medium text-muted-foreground hover:bg-muted transition-colors">
            <Search className="h-3.5 w-3.5" /> Search
          </button>
          <button className="p-1.5 border border-border rounded-lg text-muted-foreground hover:bg-muted transition-colors">
            <Grid className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      <div className="flex flex-1 min-h-0">
        {/* Left Column: Conversation List */}
        <div className="w-[280px] xl:w-[300px] flex-shrink-0 border-r border-border bg-muted/30 flex flex-col">
          <div className="p-3 flex flex-col gap-3">
            <div className="relative">
              <Search className="absolute left-2.5 top-2 h-3.5 w-3.5 text-muted-foreground" />
              <Input className="pl-8 h-8 bg-card border border-border rounded-xl shadow-sm text-xs" placeholder="Search chats..." />
            </div>
            
            <div className="flex p-1 bg-muted/50 rounded-xl">
              {(["My Chats", "All Chats"] as const).map((tab) => (
                <button
                  key={tab}
                  onClick={() => setChatFilter(tab)}
                  className={cn(
                    "flex-1 py-1.5 text-xs font-semibold rounded-lg transition-colors",
                    chatFilter === tab ? "bg-card text-primary shadow-sm" : "text-muted-foreground hover:text-foreground"
                  )}
                >
                  {tab}
                </button>
              ))}
            </div>
          </div>
          
          <div className="flex-1 overflow-y-auto px-3 pb-3 space-y-5">
            {loadingThreads ? (
              <div className="text-center text-muted-foreground text-sm mt-10">Loading chats...</div>
            ) : (
              <>
                {/* ACTIVE SECTION */}
                <div>
                  <div className="flex items-center gap-2 mb-3 px-1">
                    <span className="text-[11px] font-bold text-muted-foreground tracking-wider uppercase">Active</span>
                    <span className="bg-green-100 text-green-700 text-[10px] font-bold px-2 py-0.5 rounded-full">48</span>
                  </div>
                  <div className="space-y-2">
                    {activeThreads.map((chat) => (
                      <div 
                        key={chat.id} 
                        onClick={() => setSelectedThreadId(chat.id)}
                        className={cn(
                          "flex gap-2.5 p-2.5 rounded-2xl cursor-pointer transition-all border",
                          selectedThreadId === chat.id 
                            ? "bg-[#F3EFFF] border-[#6C47FF] shadow-sm" 
                            : "bg-card border-transparent hover:border-border shadow-sm"
                        )}
                      >
                        <Avatar className={cn("h-8 w-8 shrink-0", selectedThreadId === chat.id ? "border border-[#6C47FF]" : "")}>
                          <AvatarImage src={`https://i.pravatar.cc/150?u=${chat.contactId}`} />
                          <AvatarFallback className={cn("text-sm", selectedThreadId === chat.id ? "bg-[#6C47FF] text-white" : "bg-primary/10 text-primary")}>
                            {chat.contactName.split(' ').map(n => n[0]).join('')}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <div className="flex justify-between items-baseline mb-0.5">
                            <span className="font-bold text-[12px] text-foreground truncate">{chat.contactName}</span>
                            <span className="text-[10px] text-muted-foreground whitespace-nowrap ml-1">{chat.timestamp}</span>
                          </div>
                          <div className="flex items-center gap-1.5 mb-1.5">
                            <div className="w-3.5 h-3.5 bg-green-500 rounded-full flex items-center justify-center shrink-0">
                                <Phone className="w-2 h-2 text-white fill-white" />
                            </div>
                            <span className="text-[10px] text-muted-foreground truncate">{contact?.phone || "+91 98765 43210"}</span>
                          </div>
                          <p className="text-[11px] text-muted-foreground truncate mb-1.5">
                            {chat.lastMessage}
                          </p>
                          <div className="flex items-center justify-between">
                            <div className="flex flex-wrap gap-1">
                              {chat.tags?.map(tag => (
                                <span key={tag} className={cn(
                                  "text-[10px] font-medium px-2 py-0.5 rounded-md",
                                  tag === "Hot Lead" ? "bg-red-50 text-red-600" :
                                  tag === "Demo Requested" ? "bg-blue-50 text-blue-600" :
                                  "bg-muted text-muted-foreground"
                                )}>
                                  {tag}
                                </span>
                              ))}
                            </div>
                            {chat.unread && (
                              <div className="h-4 w-4 rounded-full bg-primary text-white text-[9px] font-bold flex items-center justify-center shrink-0">
                                3
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* REQUESTING SECTION */}
                <div>
                  <div className="flex items-center gap-2 mb-3 px-1 mt-6">
                    <span className="text-[11px] font-bold text-muted-foreground tracking-wider uppercase">Requesting</span>
                    <span className="bg-primary/10 text-primary text-[10px] font-bold px-2 py-0.5 rounded-full">17</span>
                  </div>
                  <div className="space-y-2">
                    {requestingThreads.map((chat) => (
                      <div 
                        key={chat.id} 
                        onClick={() => setSelectedThreadId(chat.id)}
                        className={cn(
                          "flex gap-2.5 p-2.5 rounded-2xl cursor-pointer transition-all border bg-card hover:border-border shadow-sm",
                          selectedThreadId === chat.id ? "bg-[#F3EFFF] border-[#6C47FF]" : "border-transparent"
                        )}
                      >
                        <Avatar className="h-8 w-8 shrink-0">
                          <AvatarFallback className="text-sm bg-orange-400 text-white">
                            {chat.contactName.split(' ').map(n => n[0]).join('')}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <div className="flex justify-between items-baseline mb-1">
                            <span className="font-bold text-[12px] text-foreground truncate">{chat.contactName}</span>
                            <span className="text-[10px] text-muted-foreground whitespace-nowrap ml-1">{chat.timestamp}</span>
                          </div>
                          <div className="flex items-center gap-1.5 mb-1.5">
                            <div className="w-3.5 h-3.5 bg-green-500 rounded-full flex items-center justify-center shrink-0">
                                <Phone className="w-2 h-2 text-white fill-white" />
                            </div>
                          </div>
                          <p className="text-[11px] text-muted-foreground truncate mb-1.5">
                            {chat.lastMessage}
                          </p>
                          <div className="flex items-center gap-1.5">
                            <User className="w-3 h-3 text-red-400" />
                            <span className="text-[10px] font-medium text-red-400">Human requested</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex justify-center gap-3 mt-6 pb-2">
                  <button className="flex flex-col items-center gap-1.5 text-muted-foreground hover:text-foreground">
                    <div className="w-10 h-10 rounded-2xl bg-card shadow-sm flex items-center justify-center border border-border">
                      <Plus className="h-4 w-4" />
                    </div>
                    <span className="text-[10px] font-medium">New Chat</span>
                  </button>
                  <button className="flex flex-col items-center gap-1.5 text-muted-foreground hover:text-foreground">
                    <div className="w-10 h-10 rounded-2xl bg-card shadow-sm flex items-center justify-center border border-border">
                      <Users className="h-4 w-4" />
                    </div>
                    <span className="text-[10px] font-medium">Bulk Actions</span>
                  </button>
                  <button className="flex flex-col items-center gap-2 text-muted-foreground hover:text-foreground">
                    <div className="w-12 h-12 rounded-2xl bg-card shadow-sm flex items-center justify-center border border-border">
                      <Filter className="h-5 w-5" />
                    </div>
                    <span className="text-[11px] font-medium">Advanced Filters</span>
                  </button>
                </div>
              </>
            )}
          </div>
        </div>

        {/* Middle Column: Chat Thread */}
        <div className="flex-1 flex flex-col min-w-0 bg-background">
          {activeThread ? (
            <>
              {/* Thread Header */}
              <div className="px-4 py-2.5 border-b border-border bg-card flex flex-col gap-1.5 shrink-0">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <Avatar className="h-9 w-9 bg-primary text-white font-bold text-sm">
                      <AvatarImage src={`https://i.pravatar.cc/150?u=${activeThread.contactId}`} />
                      <AvatarFallback>{activeThread.contactName.split(' ').map(n=>n[0]).join('')}</AvatarFallback>
                    </Avatar>
                    <div>
                      <h2 className="font-bold text-sm mb-0.5">{activeThread.contactName}</h2>
                      <div className="flex items-center gap-1 text-[11px] text-muted-foreground whitespace-nowrap">
                        <div className="w-3.5 h-3.5 bg-green-500 rounded-full flex items-center justify-center shrink-0">
                            <Phone className="w-2 h-2 text-white fill-white" />
                        </div>
                        WhatsApp • {contact?.phone || "+91 98765 43210"} • <span className="flex items-center gap-1"><div className="w-1 h-1 bg-green-500 rounded-full"/> Online</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 overflow-x-auto no-scrollbar">
                    <button className="p-1.5 border border-border rounded-lg text-muted-foreground hover:bg-muted transition-colors shrink-0"><Phone className="h-3.5 w-3.5" /></button>
                    <button className="p-1.5 border border-border rounded-lg text-muted-foreground hover:bg-muted transition-colors shrink-0"><Video className="h-3.5 w-3.5" /></button>
                    <button className="p-1.5 border border-border rounded-lg text-muted-foreground hover:bg-muted transition-colors shrink-0"><Search className="h-3.5 w-3.5" /></button>
                    <button className="flex items-center gap-1.5 h-8 px-3 text-xs font-semibold bg-card border border-border text-foreground rounded-lg hover:bg-muted transition-colors whitespace-nowrap shrink-0">
                      Assign to <ArrowRight className="h-3.5 w-3.5" />
                    </button>
                    <button className="p-1.5 text-muted-foreground hover:bg-muted rounded-lg transition-colors shrink-0"><MoreVertical className="h-3.5 w-3.5" /></button>
                  </div>
                </div>
                <div>
                  <div className="inline-flex items-center gap-1.5 bg-primary/5 px-3 py-1.5 rounded-full border border-primary/20">
                    <Bot className="w-3.5 h-3.5 text-primary" />
                    <span className="text-[11px] font-bold text-primary">AI Assistant Active</span>
                    <div className="w-3.5 h-3.5 rounded-full border border-primary/30 flex items-center justify-center ml-1 text-primary text-[9px]">i</div>
                  </div>
                </div>
              </div>

              {/* Message Area */}
              <div ref={chatScrollRef} className="flex-1 overflow-y-auto p-3 space-y-3">
                <div className="flex justify-center">
                  <span className="text-[11px] font-medium text-muted-foreground bg-card border border-border px-3 py-1 rounded-full shadow-sm">
                    Today
                  </span>
                </div>
                
                {loadingMessages ? (
                  <div className="text-center text-muted-foreground">Loading messages...</div>
                ) : messages.map(msg => (
                  <div key={msg.id} className={cn("flex flex-col gap-1 max-w-[70%]", msg.senderId !== "c1" ? "ml-auto items-end" : "items-start")}>
                    {msg.type === "pdf" ? (
                      <div className="bg-card border border-border p-3 rounded-2xl rounded-tr-sm shadow-sm flex items-center gap-3">
                        <div className="w-8 h-8 bg-red-50 text-red-500 rounded-lg flex items-center justify-center shrink-0">
                          <FileText className="h-4 w-4" />
                        </div>
                        <div>
                          <p className="text-xs font-semibold text-foreground mb-0.5">{msg.fileName}</p>
                          <p className="text-[10px] text-muted-foreground">{msg.fileSize} • PDF</p>
                        </div>
                      </div>
                    ) : (
                      <div className={cn(
                        "p-3 rounded-2xl text-[12px] shadow-sm relative whitespace-pre-wrap leading-relaxed",
                        msg.senderId !== "c1" 
                          ? "bg-primary/10 text-primary-foreground rounded-tr-sm" 
                          : "bg-card border border-border text-foreground rounded-tl-sm"
                      )}>
                        {msg.content}
                      </div>
                    )}
                    <span className="text-[10px] text-muted-foreground mt-1 flex items-center gap-1 px-2">
                      {format(new Date(msg.timestamp), 'h:mm a')}
                      {msg.senderId !== "c1" && <CheckCheck className="h-3 w-3 text-primary" />}
                    </span>
                  </div>
                ))}
                
                {/* Typing indicator */}
                <div className="flex gap-2 items-center text-muted-foreground">
                  <Avatar className="h-6 w-6">
                    <AvatarFallback className="text-[8px] bg-primary text-white">{activeThread.contactName.split(' ').map(n=>n[0]).join('')}</AvatarFallback>
                  </Avatar>
                  <div className="bg-card border border-border px-3 py-2 rounded-2xl rounded-tl-sm flex items-center gap-1 shadow-sm">
                    <span className="w-1.5 h-1.5 bg-muted-foreground rounded-full animate-bounce" />
                    <span className="w-1.5 h-1.5 bg-muted-foreground rounded-full animate-bounce delay-75" />
                    <span className="w-1.5 h-1.5 bg-muted-foreground rounded-full animate-bounce delay-150" />
                  </div>
                </div>
              </div>

              {/* Composer */}
              <div className="p-3 bg-card border-t border-border shrink-0">
                <div className="flex items-center gap-4 mb-2 px-1">
                  <button 
                    onClick={() => setComposerMode("Reply")}
                    className={cn("text-xs font-bold pb-1 border-b-2 transition-colors", composerMode === "Reply" ? "border-primary text-primary" : "border-transparent text-muted-foreground")}
                  >
                    Reply
                  </button>
                  <button 
                    onClick={() => setComposerMode("Note")}
                    className={cn("text-xs font-bold pb-1 border-b-2 transition-colors", composerMode === "Note" ? "border-amber-500 text-amber-600" : "border-transparent text-muted-foreground")}
                  >
                    Note
                  </button>
                </div>
                
                <div className={cn(
                  "border rounded-xl p-3 transition-all shadow-sm focus-within:ring-2 focus-within:ring-primary/20",
                  composerMode === "Note" ? "bg-amber-50/50 border-amber-200" : "bg-muted/30 border-border"
                )}>
                  <textarea 
                    className="w-full bg-transparent border-none focus:outline-none text-xs resize-none mb-2" 
                    rows={1}
                    placeholder={composerMode === "Note" ? "Type an internal note..." : "Type your message..."}
                    value={composerText}
                    onChange={handleComposerChange}
                    onKeyDown={e => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault()
                        handleSend()
                      }
                    }}
                  />
                  <div className="flex justify-between items-end">
                    <div className="flex gap-1.5 text-muted-foreground">
                      <button className="p-1.5 hover:bg-card hover:shadow-sm rounded-lg transition-all"><Smile className="h-3.5 w-3.5" /></button>
                      <button className="p-1.5 hover:bg-card hover:shadow-sm rounded-lg transition-all"><Paperclip className="h-3.5 w-3.5" /></button>
                      <button className="p-1.5 hover:bg-card hover:shadow-sm rounded-lg transition-all"><Zap className="h-3.5 w-3.5" /></button>
                      <button className="p-1.5 hover:bg-card hover:shadow-sm rounded-lg transition-all"><FileText className="h-3.5 w-3.5" /></button>
                      <button className="p-1.5 hover:bg-card hover:shadow-sm rounded-lg transition-all"><Grid className="h-3.5 w-3.5" /></button>
                      <button className="p-1.5 hover:bg-card hover:shadow-sm rounded-lg transition-all"><Mic className="h-3.5 w-3.5" /></button>
                    </div>
                    <div className="flex">
                      <button 
                        onClick={handleSend}
                        disabled={sendMessageMutation.isPending || !composerText.trim()}
                        className="h-8 px-4 bg-primary/10 text-primary hover:bg-primary/20 font-bold text-[11px] rounded-l-lg transition-colors disabled:opacity-50 flex items-center"
                      >
                        {sendMessageMutation.isPending ? "Sending..." : "Send"}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center text-muted-foreground">
              Select a conversation to start messaging
            </div>
          )}
        </div>

        {/* Right Column: Details */}
        <div className="w-[280px] xl:w-[280px] shrink-0 border-l border-border bg-card flex flex-col overflow-y-auto">
          <div className="p-3 border-b border-border flex items-center justify-between shrink-0">
            <h3 className="font-bold text-xs">Smart Cards</h3>
            <div className="flex gap-2">
              <button className="p-1 text-muted-foreground hover:bg-muted rounded-md"><ChevronDown className="h-3 w-3" /></button>
            </div>
          </div>
          <div className="p-3">
            {/* Lead Score */}
            <div className="mb-4 border-b border-border pb-4">
              <div 
                className="flex items-center justify-between mb-2.5 cursor-pointer group"
                onClick={() => toggleSection('leadScore')}
              >
                <div className="flex items-center gap-2">
                  <h4 className="font-bold text-xs">Lead Score</h4>
                  <div className="w-3 h-3 rounded-full border border-muted-foreground flex items-center justify-center text-muted-foreground text-[8px]">i</div>
                </div>
                <ChevronDown className={cn("w-3.5 h-3.5 text-muted-foreground transition-transform", collapsedSections.leadScore && "-rotate-90")} />
              </div>
              
              {!collapsedSections.leadScore && (
                <>
                  <div className="flex items-center gap-5">
                    <div className="relative w-[60px] h-[60px]">
                      {/* Mock Donut Chart SVG */}
                      <svg viewBox="0 0 100 100" className="w-full h-full transform -rotate-90">
                        <circle cx="50" cy="50" r="40" stroke="#f1f5f9" strokeWidth="10" fill="none" />
                        <circle cx="50" cy="50" r="40" stroke="url(#gradient)" strokeWidth="10" fill="none" strokeDasharray="251.2" strokeDashoffset={251.2 * (1 - (contact?.leadScore || 0)/100)} strokeLinecap="round" />
                        <defs>
                          <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                            <stop offset="0%" stopColor="#f59e0b" />
                            <stop offset="100%" stopColor="#8b5cf6" />
                          </linearGradient>
                        </defs>
                      </svg>
                      <div className="absolute inset-0 flex flex-col items-center justify-center">
                        <span className="text-lg font-black text-foreground leading-none">{contact?.leadScore || 0}</span>
                        <span className="text-[8px] font-bold text-red-500 uppercase mt-0.5">Hot Lead</span>
                      </div>
                    </div>
                    
                    <div className="flex-1 space-y-1.5">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] text-muted-foreground w-14">Engagement</span>
                        <div className="flex-1 h-1 bg-muted rounded-full overflow-hidden"><div className="h-full bg-green-500 rounded-full" style={{ width: `${contact?.engagement || 0}%` }}/></div>
                        <span className="text-[10px] font-bold text-foreground w-6 text-right">{contact?.engagement || 0}%</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] text-muted-foreground w-14">Intent</span>
                        <div className="flex-1 h-1 bg-muted rounded-full overflow-hidden"><div className="h-full bg-green-500 rounded-full" style={{ width: `${contact?.intent || 0}%` }}/></div>
                        <span className="text-[10px] font-bold text-foreground w-6 text-right">{contact?.intent || 0}%</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] text-muted-foreground w-14">Profile Fit</span>
                        <div className="flex-1 h-1 bg-muted rounded-full overflow-hidden"><div className="h-full bg-green-500 rounded-full" style={{ width: `${contact?.profileFit || 0}%` }}/></div>
                        <span className="text-[10px] font-bold text-foreground w-6 text-right">{contact?.profileFit || 0}%</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] text-muted-foreground w-14">Activity</span>
                        <div className="flex-1 h-1 bg-muted rounded-full overflow-hidden"><div className="h-full bg-green-500 rounded-full" style={{ width: "76%" }}/></div>
                        <span className="text-[10px] font-bold text-foreground w-6 text-right">76%</span>
                      </div>
                    </div>
                  </div>
                  <button className="text-[11px] font-semibold text-muted-foreground hover:text-foreground mt-3 flex items-center gap-1">
                    View full score breakdown <ArrowRight className="w-3 h-3" />
                  </button>
                </>
              )}
            </div>

            {/* Contact Details */}
            <div className="mb-4 border-b border-border pb-4">
              <div 
                className="flex items-center justify-between mb-2.5 cursor-pointer group"
                onClick={() => toggleSection('contactDetails')}
              >
                <h4 className="font-bold text-xs">Contact Details</h4>
                <div className="flex items-center gap-2">
                  <button className="p-1 text-muted-foreground hover:text-foreground"><Edit2 className="w-3 h-3" /></button>
                  <ChevronDown className={cn("w-3.5 h-3.5 text-muted-foreground transition-transform", collapsedSections.contactDetails && "-rotate-90")} />
                </div>
              </div>
              
              {!collapsedSections.contactDetails && (
                <>
                  <div className="space-y-3 text-xs">
                    <div className="flex items-center gap-2.5">
                      <Phone className="w-3.5 h-3.5 text-muted-foreground" />
                      <span className="text-foreground">{contact?.phone || "+91 98765 43210"}</span>
                      <div className="w-3.5 h-3.5 bg-green-500 rounded-full flex items-center justify-center shrink-0 ml-auto">
                          <Phone className="w-2 h-2 text-white fill-white" />
                      </div>
                    </div>
                    <div className="flex items-center gap-2.5">
                      <FileText className="w-3.5 h-3.5 text-muted-foreground" />
                      <span className="text-foreground">{contact?.email || "john.doe@email.com"}</span>
                    </div>
                    <div className="flex items-center gap-2.5">
                      <MapPin className="w-3.5 h-3.5 text-muted-foreground" />
                      <span className="text-foreground">{contact?.location || "Mumbai, India"}</span>
                    </div>
                    <div className="flex items-center gap-2.5">
                      <Clock className="w-3.5 h-3.5 text-muted-foreground" />
                      <span className="text-foreground">10:32 AM (UTC +5:30)</span>
                    </div>
                  </div>
                  <button className="text-[11px] font-semibold text-muted-foreground hover:text-foreground mt-3 flex items-center gap-1">
                    View more <ArrowRight className="w-3 h-3" />
                  </button>
                </>
              )}
            </div>

            {/* Tags */}
            <div className="mb-4 border-b border-border pb-4">
              <div 
                className="flex items-center justify-between mb-2.5 cursor-pointer group"
                onClick={() => toggleSection('tags')}
              >
                <h4 className="font-bold text-xs">Tags</h4>
                <div className="flex items-center gap-2">
                  <button className="text-[10px] font-bold text-muted-foreground hover:text-foreground flex items-center gap-1">
                    <Plus className="w-2.5 h-2.5" /> Add
                  </button>
                  <ChevronDown className={cn("w-3.5 h-3.5 text-muted-foreground transition-transform", collapsedSections.tags && "-rotate-90")} />
                </div>
              </div>
              
              {!collapsedSections.tags && (
                <div className="flex flex-wrap gap-1.5">
                  {activeThread?.tags?.length ? activeThread.tags.map(tag => (
                    <span key={tag} className={cn(
                      "px-2 py-0.5 rounded-lg text-[10px] font-semibold",
                      tag === "Hot Lead" ? "bg-red-50 text-red-600" :
                      tag === "Meeting Requested" ? "bg-blue-50 text-blue-600" :
                      "bg-primary/5 text-primary"
                    )}>{tag}</span>
                  )) : (
                    <span className="text-xs text-muted-foreground">No tags</span>
                  )}
                </div>
              )}
            </div>

            {/* Assigned To */}
            <div className="mb-4 border-b border-border pb-4">
              <div 
                className="flex items-center justify-between mb-2.5 cursor-pointer group"
                onClick={() => toggleSection('assignedTo')}
              >
                <h4 className="font-bold text-xs">Assigned To</h4>
                <ChevronDown className={cn("w-3.5 h-3.5 text-muted-foreground transition-transform", collapsedSections.assignedTo && "-rotate-90")} />
              </div>
              
              {!collapsedSections.assignedTo && (
                <div className="flex items-center justify-between p-2.5 border border-border rounded-xl cursor-pointer hover:bg-muted/50 transition-colors">
                  <div className="flex items-center gap-2.5">
                    <Avatar className={cn("h-7 w-7 text-white font-bold text-[10px]", activeThread?.assignedTo?.color || "bg-blue-500")}>
                      <AvatarFallback>{activeThread?.assignedTo?.initials || "RF"}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="text-xs font-bold text-foreground leading-none mb-1">{activeThread?.assignedTo?.name || "Riya Sharma"}</p>
                      <p className="text-[10px] text-muted-foreground">{activeThread?.assignedTo?.role || "Sales Executive"}</p>
                    </div>
                  </div>
                  <ChevronDown className="w-3.5 h-3.5 text-muted-foreground" />
                </div>
              )}
            </div>

            {/* Events Timeline */}
            <div>
              <div 
                className="flex items-center justify-between mb-2.5 cursor-pointer group"
                onClick={() => toggleSection('events')}
              >
                <h4 className="font-bold text-xs">Events Timeline</h4>
                <div className="flex items-center gap-2">
                  <button className="text-[10px] font-bold text-muted-foreground hover:text-foreground">View All</button>
                  <ChevronDown className={cn("w-3.5 h-3.5 text-muted-foreground transition-transform", collapsedSections.events && "-rotate-90")} />
                </div>
              </div>
              
              {!collapsedSections.events && (
                <div className="space-y-3">
                  {activeThread?.events ? activeThread.events.map((evt, idx) => (
                    <div key={idx} className="flex gap-3">
                      <div className="text-[10px] text-muted-foreground font-medium w-10 pt-1">{evt.time}</div>
                      <div className="flex items-start gap-2.5">
                        <div className={cn(
                          "w-5 h-5 rounded-full flex items-center justify-center shrink-0",
                          evt.icon === "start" ? "bg-green-100" :
                          evt.icon === "bot" ? "bg-primary/10" :
                          evt.icon === "user" ? "bg-gray-100" : "bg-blue-100"
                        )}>
                          {evt.icon === "start" && <Phone className="w-2.5 h-2.5 text-green-600 fill-green-600" />}
                          {evt.icon === "bot" && <Bot className="w-3 h-3 text-primary" />}
                          {evt.icon === "user" && <User className="w-3 h-3 text-gray-600" />}
                          {evt.icon === "doc" && <FileText className="w-3 h-3 text-blue-600" />}
                        </div>
                        <span className="text-[12px] text-foreground font-medium pt-0.5 leading-tight">{evt.label}</span>
                      </div>
                    </div>
                  )) : (
                    <div className="text-sm text-muted-foreground">No recent events</div>
                  )}
                </div>
              )}
            </div>

          </div>
        </div>
      </div>
    </div>
  )
}
function ArrowRight(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M5 12h14" />
      <path d="m12 5 7 7-7 7" />
    </svg>
  )
}
function Users(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
      <path d="M16 3.13a4 4 0 0 1 0 7.75" />
    </svg>
  )
}
