"use client"

import React, { useState } from "react"
import { Search, ChevronDown, UserPlus, Users, CircleDot, MessageCircle, Clock, ChevronsUpDown, Pencil, MoreHorizontal, RefreshCw, Check, X, Minus } from "lucide-react"
import { cn } from "@/lib/utils"

const stats = [
  { icon: Users, iconColor: "text-foreground", bg: "bg-muted", label: "Total Members", value: "12" },
  { icon: CircleDot, iconColor: "text-green-500", bg: "bg-green-100", label: "Online Now", value: "7", delta: "Live count", deltaColor: "text-green-600" },
  { icon: MessageCircle, iconColor: "text-foreground", bg: "bg-muted", label: "Avg Chats / Day", value: "48", delta: "+6% vs last week", deltaColor: "text-green-600" },
  { icon: Clock, iconColor: "text-foreground", bg: "bg-muted", label: "Avg Response Time", value: "2m 14s", delta: "-18s vs last week", deltaColor: "text-green-600" },
]

const tabs = [
  { label: "All Members", count: "12" },
  { label: "Admins", count: "2" },
  { label: "Managers", count: "3" },
  { label: "Agents", count: "7" },
  { label: "Inactive", count: "1" },
]

const members = [
  {
    initials: "RF", bg: "from-primary to-primary/80", name: "Robert Fox", email: "robert@acme.com", you: true,
    role: "Admin", roleBg: "bg-slate-900", roleText: "text-white",
    status: "Online", statusColor: "bg-green-500", statusText: "text-green-600",
    assigned: "12", handled: "1,482", avgResp: "1m 42s", creditVal: 62, creditText: "620 / 1000"
  },
  {
    initials: "SW", bg: "from-purple-300 to-purple-400", name: "Sarah Wilson", email: "sarah@acme.com",
    role: "Manager", roleBg: "bg-purple-100", roleText: "text-purple-700",
    status: "Online", statusColor: "bg-green-500", statusText: "text-green-600",
    assigned: "9", handled: "980", avgResp: "2m 05s", creditVal: 45, creditText: "450 / 1000"
  },
  {
    initials: "RS", bg: "from-blue-200 to-blue-400", name: "Rakesh Sharma", email: "rakesh@acme.com",
    role: "Agent", roleBg: "bg-green-100", roleText: "text-green-700",
    status: "Online", statusColor: "bg-green-500", statusText: "text-green-600",
    assigned: "14", handled: "623", avgResp: "3m 11s", creditVal: 30, creditText: "300 / 1000"
  },
  {
    initials: "PP", bg: "from-amber-200 to-red-300", name: "Priya Patel", email: "priya@acme.com",
    role: "Agent", roleBg: "bg-green-100", roleText: "text-green-700",
    status: "Away", statusColor: "bg-amber-500", statusText: "text-amber-500",
    assigned: "6", handled: "421", avgResp: "4m 30s", creditVal: 20, creditText: "200 / 1000"
  },
  {
    initials: "DL", initialsColor: "text-primary", bg: "from-slate-800 to-slate-700", name: "David Lee", email: "david@acme.com",
    role: "Manager", roleBg: "bg-purple-100", roleText: "text-purple-700",
    status: "Offline", statusColor: "bg-red-500", statusText: "text-muted-foreground",
    assigned: "0", handled: "312", avgResp: "—", creditVal: 15, creditText: "150 / 1000"
  },
  {
    initials: "CW", bg: "from-purple-300 to-indigo-400", name: "Camren Williamson", email: "camren@acme.com",
    role: "Agent", roleBg: "bg-green-100", roleText: "text-green-700",
    status: "Online", statusColor: "bg-green-500", statusText: "text-green-600",
    assigned: "11", handled: "825", avgResp: "1m 58s", creditVal: 55, creditText: "550 / 1000"
  },
  {
    initials: "BS", bg: "from-blue-200 to-sky-400", name: "Brooklyn Simmons", email: "brooklyn@acme.com",
    role: "Agent", roleBg: "bg-green-100", roleText: "text-green-700",
    status: "Online", statusColor: "bg-green-500", statusText: "text-green-600",
    assigned: "8", handled: "425", avgResp: "2m 44s", creditVal: 25, creditText: "250 / 1000"
  },
  {
    initials: "DS", bg: "from-amber-200 to-orange-500", name: "Darrell Steward", email: "darrell@acme.com", pending: true,
    role: "Agent", roleBg: "bg-green-100", roleText: "text-green-700",
    status: "Pending", statusColor: "bg-muted-foreground", statusText: "text-muted-foreground",
    assigned: "—", handled: "—", avgResp: "—", creditVal: 0, creditText: "0 / 1000"
  },
]

const matrix = [
  { p: "View Shared Inbox", a: "check", m: "check", ad: "check" },
  { p: "Assign Conversations", a: "x", m: "check", ad: "check" },
  { p: "Manage Campaigns", a: "x", m: "check", ad: "check" },
  { p: "Access Workflow Builder", a: "x", m: "check", ad: "check" },
  { p: "View Analytics", a: "dash", m: "check", ad: "check" },
  { p: "Manage Integrations", a: "x", m: "x", ad: "check" },
  { p: "Billing & Credits", a: "x", m: "x", ad: "check" },
  { p: "Invite Members", a: "x", m: "x", ad: "check" },
  { p: "Configure AI Chatbot", a: "x", m: "check", ad: "check" },
  { p: "Voice Agent Setup", a: "x", m: "x", ad: "check" },
]

export default function TeamAgentsPage() {
  const [activeTab, setActiveTab] = useState("All Members")

  const renderMatrixIcon = (val: string) => {
    if (val === "check") return <Check className="h-4 w-4 text-green-500 mx-auto" />
    if (val === "x") return <X className="h-4 w-4 text-red-500 mx-auto" />
    if (val === "dash") return <Minus className="h-4 w-4 text-amber-500 mx-auto" />
    return null
  }

  return (
    <div className="flex flex-col min-h-full flex-1  bg-background p-8">
      <div className="max-w-[1280px] mx-auto w-full space-y-6">
        
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <p className="text-[12px] text-muted-foreground mb-1">Settings / Team & Agents</p>
            <h1 className="text-2xl font-bold text-foreground mb-1">Team & Agents</h1>
            <p className="text-[14px] text-muted-foreground">Manage team members, assign roles, and monitor agent performance</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <input type="text" placeholder="Search team members..." className="w-[220px] pl-9 pr-3 py-2 border border-border rounded-lg bg-card text-[13px] focus:outline-none focus:ring-1 focus:ring-primary" />
            </div>
            <button className="flex items-center gap-2 px-4 py-2 border border-border rounded-lg bg-card text-[13px] font-medium text-foreground">
              All Roles <ChevronDown className="h-4 w-4 text-muted-foreground" />
            </button>
            <button className="flex items-center gap-2 px-5 py-2 bg-primary hover:bg-primary/90 text-primary-foreground font-semibold text-[14px] rounded-lg shadow-sm transition-colors">
              <UserPlus className="h-4 w-4" /> Invite Member
            </button>
          </div>
        </div>

        {/* Stats Strip */}
        <div className="grid grid-cols-4 gap-4">
          {stats.map((stat, i) => (
            <div key={i} className="bg-card border border-border rounded-xl p-5 shadow-sm">
              <div className="flex items-center gap-3 mb-3">
                <div className={cn("w-9 h-9 rounded-full flex items-center justify-center shrink-0", stat.bg)}>
                  <stat.icon className={cn("h-5 w-5", stat.iconColor)} />
                </div>
                <span className="text-[12px] font-medium text-muted-foreground">{stat.label}</span>
              </div>
              <div className="flex items-baseline gap-2">
                <span className="text-[28px] font-bold text-foreground leading-none">{stat.value}</span>
                {stat.delta && <span className={cn("text-[11px] font-medium", stat.deltaColor)}>{stat.delta}</span>}
              </div>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-6 border-b border-border">
          {tabs.map(tab => (
            <button
              key={tab.label}
              onClick={() => setActiveTab(tab.label)}
              className={cn(
                "pb-3 text-[14px] transition-colors relative flex items-center gap-2",
                activeTab === tab.label ? "text-foreground font-semibold" : "text-muted-foreground hover:text-foreground"
              )}
            >
              {tab.label}
              <span className={cn("text-[12px] px-1.5 py-0.5 rounded-full bg-muted", activeTab === tab.label ? "text-foreground" : "text-muted-foreground")}>{tab.count}</span>
              {activeTab === tab.label && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary" />
              )}
            </button>
          ))}
        </div>

        {/* Agent Table */}
        <div className="bg-card border border-border rounded-xl shadow-sm overflow-hidden">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-muted/30 border-b border-border">
                <th className="py-3 px-5 text-[11px] font-semibold text-muted-foreground uppercase tracking-wider w-[280px]">
                  <div className="flex items-center gap-1">Member <ChevronsUpDown className="h-3 w-3" /></div>
                </th>
                <th className="py-3 px-5 text-[11px] font-semibold text-muted-foreground uppercase tracking-wider w-[120px]">Role</th>
                <th className="py-3 px-5 text-[11px] font-semibold text-muted-foreground uppercase tracking-wider w-[100px]">Status</th>
                <th className="py-3 px-5 text-[11px] font-semibold text-muted-foreground uppercase tracking-wider w-[130px]">
                  <div className="flex items-center gap-1">Assigned Chats <ChevronsUpDown className="h-3 w-3" /></div>
                </th>
                <th className="py-3 px-5 text-[11px] font-semibold text-muted-foreground uppercase tracking-wider w-[130px]">
                  <div className="flex items-center gap-1">Chats Handled <ChevronsUpDown className="h-3 w-3" /></div>
                </th>
                <th className="py-3 px-5 text-[11px] font-semibold text-muted-foreground uppercase tracking-wider w-[120px]">Avg Response</th>
                <th className="py-3 px-5 text-[11px] font-semibold text-muted-foreground uppercase tracking-wider w-[130px]">Credit Usage</th>
                <th className="py-3 px-5 text-[11px] font-semibold text-muted-foreground uppercase tracking-wider w-[80px] text-center">Actions</th>
              </tr>
            </thead>
            <tbody>
              {members.map((m, i) => (
                <tr key={i} className="border-b border-border/50 hover:bg-muted/20 transition-colors last:border-0">
                  <td className="py-4 px-5">
                    <div className="flex items-center gap-3">
                      <div className={cn("w-10 h-10 rounded-full flex items-center justify-center bg-gradient-to-br shrink-0", m.bg, m.initialsColor || "text-white")}>
                        <span className="text-[14px] font-bold">{m.initials}</span>
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <p className="text-[14px] font-semibold text-foreground">{m.name}</p>
                          {m.you && <span className="bg-muted text-muted-foreground text-[11px] font-medium px-1.5 py-0.5 rounded">You</span>}
                          {m.pending && <span className="bg-amber-100 text-amber-700 text-[11px] font-medium px-1.5 py-0.5 rounded">Invite Pending</span>}
                        </div>
                        <p className="text-[12px] text-muted-foreground/70">{m.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="py-4 px-5">
                    <span className={cn("inline-block px-2.5 py-1 rounded-md text-[12px] font-semibold", m.roleBg, m.roleText)}>
                      {m.role}
                    </span>
                  </td>
                  <td className="py-4 px-5">
                    <div className="flex items-center gap-2">
                      <div className={cn("w-2 h-2 rounded-full", m.statusColor)} />
                      <span className={cn("text-[13px] font-medium", m.statusText)}>{m.status}</span>
                    </div>
                  </td>
                  <td className="py-4 px-5 text-[14px] font-medium text-foreground">{m.assigned}</td>
                  <td className="py-4 px-5 text-[14px] font-medium text-foreground">{m.handled}</td>
                  <td className="py-4 px-5 text-[14px] text-muted-foreground">{m.avgResp}</td>
                  <td className="py-4 px-5">
                    <div className="w-[80px] bg-muted h-1.5 rounded-full overflow-hidden mb-1">
                      <div className="bg-primary h-full" style={{ width: `${m.creditVal}%` }} />
                    </div>
                    <p className="text-[11px] text-muted-foreground/70">{m.creditText}</p>
                  </td>
                  <td className="py-4 px-5">
                    <div className="flex items-center justify-center gap-2 text-muted-foreground">
                      {m.pending ? (
                        <button className="hover:text-foreground"><RefreshCw className="h-4 w-4" /></button>
                      ) : (
                        <button className="hover:text-foreground"><Pencil className="h-4 w-4" /></button>
                      )}
                      <button className="hover:text-foreground"><MoreHorizontal className="h-4 w-4" /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="p-4 border-t border-border flex items-center justify-between">
            <span className="text-[12px] text-muted-foreground/70">Showing 1–8 of 12 members</span>
            <div className="flex items-center gap-1">
              <button className="px-2 py-1 border border-border rounded-md text-[12px] hover:bg-muted">&lt;</button>
              <button className="px-3 py-1 border border-primary bg-primary/10 rounded-md text-[12px] font-medium text-foreground">1</button>
              <button className="px-3 py-1 border border-border rounded-md text-[12px] hover:bg-muted">2</button>
              <button className="px-2 py-1 border border-border rounded-md text-[12px] hover:bg-muted">&gt;</button>
            </div>
          </div>
        </div>

        {/* Permissions Matrix */}
        <div className="mt-8">
          <h2 className="text-[16px] font-semibold text-foreground mb-1">Role Permissions Matrix</h2>
          <p className="text-[13px] text-muted-foreground mb-4">See what each role can access and do in Flowora</p>
          
          <div className="bg-card border border-border rounded-xl overflow-hidden">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-muted/30 border-b border-border">
                  <th className="py-3 px-5 text-[12px] font-semibold text-muted-foreground uppercase w-1/2">Permission</th>
                  <th className="py-3 px-5 text-[12px] font-semibold text-muted-foreground uppercase text-center w-1/6">Agent</th>
                  <th className="py-3 px-5 text-[12px] font-semibold text-muted-foreground uppercase text-center w-1/6">Manager</th>
                  <th className="py-3 px-5 text-[12px] font-semibold text-muted-foreground uppercase text-center w-1/6">Admin</th>
                </tr>
              </thead>
              <tbody>
                {matrix.map((row, i) => (
                  <tr key={i} className={cn("border-b border-border/50 last:border-0", i % 2 === 0 ? "bg-card" : "bg-muted/10")}>
                    <td className="py-3.5 px-5 text-[13px] text-foreground">{row.p}</td>
                    <td className="py-3.5 px-5 text-center">{renderMatrixIcon(row.a)}</td>
                    <td className="py-3.5 px-5 text-center">{renderMatrixIcon(row.m)}</td>
                    <td className="py-3.5 px-5 text-center">{renderMatrixIcon(row.ad)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </div>
  )
}
