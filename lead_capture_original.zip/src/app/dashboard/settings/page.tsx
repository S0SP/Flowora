"use client"

import React, { useState } from "react"
import { Building2, Shield, Bell, MessageCircle, Mail, Phone, CreditCard, Receipt, Key, Lock, FileText, Upload, Plus, MoreHorizontal } from "lucide-react"
import { cn } from "@/lib/utils"
import { toast } from "sonner"

const navGroups = [
  {
    group_label: "WORKSPACE",
    items: [
      { icon: Building2, label: "General" },
      { icon: Shield, label: "Roles & Permissions" },
      { icon: Bell, label: "Notifications" },
    ]
  },
  {
    group_label: "CHANNELS",
    items: [
      { icon: MessageCircle, label: "WhatsApp Business" },
      { icon: Mail, label: "Email (SMTP)" },
      { icon: Phone, label: "Voice & Calling" },
    ]
  },
  {
    group_label: "BILLING",
    items: [
      { icon: CreditCard, label: "Billing & Credits" },
      { icon: Receipt, label: "Invoices" },
    ]
  },
  {
    group_label: "DEVELOPER",
    items: [
      { icon: Key, label: "API Keys" },
    ]
  },
  {
    group_label: "SECURITY",
    items: [
      { icon: Lock, label: "Security" },
      { icon: FileText, label: "Audit Log" },
    ]
  }
]

export default function SettingsPage() {
  const [activeItem, setActiveItem] = useState("General")

  const [businessDays, setBusinessDays] = useState([
    { day: "Monday", enabled: true, open: "09:00", close: "18:00" },
    { day: "Tuesday", enabled: true, open: "09:00", close: "18:00" },
    { day: "Wednesday", enabled: true, open: "09:00", close: "18:00" },
    { day: "Thursday", enabled: true, open: "09:00", close: "18:00" },
    { day: "Friday", enabled: true, open: "09:00", close: "18:00" },
    { day: "Saturday", enabled: false, open: "09:00", close: "18:00" },
    { day: "Sunday", enabled: false, open: "09:00", close: "18:00" },
  ])

  const [isSaving, setIsSaving] = useState(false)

  const handleSave = () => {
    setIsSaving(true)
    setTimeout(() => {
      setIsSaving(false)
      toast.success("Settings saved successfully!")
    }, 600)
  }

  const renderContent = () => {
    switch (activeItem) {
      case "General":
        return (
          <div className="max-w-[800px]">
            <h1 className="text-[22px] font-bold text-foreground mb-1">General Settings</h1>
            <p className="text-[14px] text-muted-foreground mb-7">Configure your workspace name, timezone, and preferences</p>
            
            <div className="space-y-6">
              
              {/* Workspace Identity */}
              <div>
                <h3 className="text-[15px] font-semibold text-foreground mb-3">Workspace Identity</h3>
                <div className="bg-white border border-border rounded-xl p-6 shadow-sm space-y-5">
                  
                  <div className="space-y-1.5">
                    <label className="text-[13px] font-semibold text-foreground">Workspace Name</label>
                    <input 
                      type="text" 
                      defaultValue="Acme Corp"
                      className="w-full border border-border rounded-lg px-3.5 py-2.5 text-[14px] text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[13px] font-semibold text-foreground">Workspace Logo</label>
                    <div className="border-2 border-dashed border-border rounded-lg p-6 bg-muted/30 flex flex-col items-center justify-center text-center cursor-pointer hover:border-[#FFE27C] transition-colors">
                      <Upload className="h-6 w-6 text-muted-foreground mb-2" />
                      <p className="text-[13px] text-muted-foreground mb-1">Drop logo here or click to upload</p>
                      <p className="text-[11px] text-muted-foreground">PNG, JPG up to 2MB. Recommended 200x200px</p>
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[13px] font-semibold text-foreground">Website URL</label>
                    <input 
                      type="url" 
                      defaultValue="https://acme.com"
                      className="w-full border border-border rounded-lg px-3.5 py-2.5 text-[14px] text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[13px] font-semibold text-foreground">Industry</label>
                    <select className="w-full border border-border rounded-lg px-3.5 py-2.5 text-[14px] text-foreground focus:outline-none focus:ring-1 focus:ring-primary appearance-none bg-white">
                      <option>SaaS</option>
                      <option>E-commerce</option>
                      <option>Real Estate</option>
                      <option>Healthcare</option>
                      <option>Education</option>
                      <option>Fintech</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Localization */}
              <div>
                <h3 className="text-[15px] font-semibold text-foreground mb-3">Localization</h3>
                <div className="bg-white border border-border rounded-xl p-6 shadow-sm space-y-5">
                  <div className="space-y-1.5">
                    <label className="text-[13px] font-semibold text-foreground">Timezone</label>
                    <select className="w-full border border-border rounded-lg px-3.5 py-2.5 text-[14px] text-foreground focus:outline-none focus:ring-1 focus:ring-primary appearance-none bg-white">
                      <option>Asia/Kolkata (UTC +5:30)</option>
                      <option>America/New_York (UTC -5:00)</option>
                      <option>Europe/London (UTC +0:00)</option>
                    </select>
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[13px] font-semibold text-foreground">Date Format</label>
                    <select className="w-full border border-border rounded-lg px-3.5 py-2.5 text-[14px] text-foreground focus:outline-none focus:ring-1 focus:ring-primary appearance-none bg-white">
                      <option>DD/MM/YYYY</option>
                      <option>MM/DD/YYYY</option>
                      <option>YYYY-MM-DD</option>
                    </select>
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[13px] font-semibold text-foreground">Language</label>
                    <select className="w-full border border-border rounded-lg px-3.5 py-2.5 text-[14px] text-foreground focus:outline-none focus:ring-1 focus:ring-primary appearance-none bg-white">
                      <option>English (US)</option>
                      <option>Hindi</option>
                      <option>Arabic</option>
                      <option>Spanish</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Business Hours */}
              <div>
                <h3 className="text-[15px] font-semibold text-foreground mb-1">Business Hours</h3>
                <p className="text-[13px] text-muted-foreground mb-3">Set your business hours so the AI chatbot knows when to route to a human agent</p>
                
                <div className="bg-white border border-border rounded-xl p-6 shadow-sm">
                  {businessDays.map((d, i) => (
                    <div key={d.day} className="flex items-center gap-4 py-3 border-b border-border last:border-0">
                      <div className="w-[100px] flex items-center gap-3">
                        <button
                          onClick={() => {
                            const nd = [...businessDays]
                            nd[i].enabled = !nd[i].enabled
                            setBusinessDays(nd)
                          }}
                          className={cn(
                            "w-9 h-5 rounded-full relative transition-colors shrink-0",
                            d.enabled ? "bg-primary" : "bg-border"
                          )}
                        >
                          <div className={cn(
                            "absolute top-0.5 w-4 h-4 rounded-full bg-white transition-all shadow-sm",
                            d.enabled ? "left-[18px]" : "left-0.5"
                          )} />
                        </button>
                        <span className="text-[13px] font-medium text-foreground">{d.day}</span>
                      </div>

                      {d.enabled ? (
                        <div className="flex items-center gap-2">
                          <input
                            type="time"
                            value={d.open}
                            onChange={(e) => {
                              const nd = [...businessDays]
                              nd[i].open = e.target.value
                              setBusinessDays(nd)
                            }}
                            className="border border-border rounded-md px-2.5 py-1.5 text-[13px] focus:outline-none"
                          />
                          <span className="text-muted-foreground text-[13px]">-</span>
                          <input
                            type="time"
                            value={d.close}
                            onChange={(e) => {
                              const nd = [...businessDays]
                              nd[i].close = e.target.value
                              setBusinessDays(nd)
                            }}
                            className="border border-border rounded-md px-2.5 py-1.5 text-[13px] focus:outline-none"
                          />
                        </div>
                      ) : (
                        <span className="text-[13px] text-muted-foreground">Closed</span>
                      )}
                    </div>
                  ))}
                </div>
              </div>

            </div>
          </div>
        )
      case "Roles & Permissions":
        return (
          <div className="max-w-[800px]">
            <div className="flex items-center justify-between mb-7">
              <div>
                <h1 className="text-[22px] font-bold text-foreground mb-1">Roles & Permissions</h1>
                <p className="text-[14px] text-muted-foreground">Manage team roles and their access levels across the workspace.</p>
              </div>
              <button className="flex items-center gap-2 bg-foreground text-white px-4 py-2 rounded-lg text-[13px] font-medium hover:bg-foreground/90 transition-colors">
                <Plus className="h-4 w-4" /> Add Custom Role
              </button>
            </div>
            
            <div className="bg-white border border-border rounded-xl overflow-hidden shadow-sm">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-muted/30 border-b border-border">
                    <th className="px-5 py-3 text-[12px] font-bold text-muted-foreground uppercase tracking-wider">Role Name</th>
                    <th className="px-5 py-3 text-[12px] font-bold text-muted-foreground uppercase tracking-wider">Access Level</th>
                    <th className="px-5 py-3 text-[12px] font-bold text-muted-foreground uppercase tracking-wider text-center">Team Members</th>
                    <th className="px-5 py-3 text-[12px] font-bold text-muted-foreground uppercase tracking-wider text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E8E8E4]">
                  {[
                    { role: "Owner", access: "Full Workspace Access", members: 1, isSystem: true },
                    { role: "Admin", access: "Can manage billing, settings, and team", members: 2, isSystem: true },
                    { role: "Agent", access: "Can reply to inbox and view leads", members: 8, isSystem: true },
                    { role: "Viewer", access: "Read-only access to analytics and leads", members: 3, isSystem: true },
                    { role: "Marketing", access: "Custom access: Campaigns only", members: 2, isSystem: false },
                  ].map((role) => (
                    <tr key={role.role} className="hover:bg-muted/30/50 transition-colors">
                      <td className="px-5 py-4">
                        <div className="flex items-center gap-2">
                          <span className="text-[14px] font-semibold text-foreground">{role.role}</span>
                          {role.isSystem && (
                            <span className="text-[10px] font-bold text-muted-foreground bg-border px-1.5 py-0.5 rounded">SYSTEM</span>
                          )}
                        </div>
                      </td>
                      <td className="px-5 py-4 text-[13px] text-muted-foreground">{role.access}</td>
                      <td className="px-5 py-4 text-center">
                        <div className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-muted/50 text-[12px] font-bold text-foreground">
                          {role.members}
                        </div>
                      </td>
                      <td className="px-5 py-4 text-right">
                        <button className="text-muted-foreground hover:text-foreground transition-colors p-1 rounded hover:bg-border">
                          <MoreHorizontal className="h-4 w-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )
      case "Notifications":
        return (
          <div className="max-w-[800px]">
            <h1 className="text-[22px] font-bold text-foreground mb-1">Notifications</h1>
            <p className="text-[14px] text-muted-foreground mb-7">Manage how you receive alerts and workflow updates</p>
            <div className="space-y-4 bg-white border border-border rounded-xl p-6 shadow-sm">
              {[
                { label: "New Lead Created", email: true, inApp: true },
                { label: "Lead Stage Changed", email: false, inApp: true },
                { label: "Workflow Failed", email: true, inApp: true },
                { label: "Weekly Report", email: true, inApp: false },
              ].map(notif => (
                <div key={notif.label} className="flex items-center justify-between py-3 border-b border-border last:border-0">
                  <span className="text-[14px] font-medium text-foreground">{notif.label}</span>
                  <div className="flex gap-6">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input type="checkbox" defaultChecked={notif.email} className="rounded border-gray-300 text-primary focus:ring-primary" />
                      <span className="text-[13px] text-muted-foreground">Email</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input type="checkbox" defaultChecked={notif.inApp} className="rounded border-gray-300 text-primary focus:ring-primary" />
                      <span className="text-[13px] text-muted-foreground">In-App</span>
                    </label>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )
      case "WhatsApp Business":
        return (
          <div className="max-w-[800px]">
            <div className="flex items-center justify-between mb-7">
              <div>
                <h1 className="text-[22px] font-bold text-foreground mb-1">WhatsApp Business API</h1>
                <p className="text-[14px] text-muted-foreground">Connect your Meta developer app to send WhatsApp messages.</p>
              </div>
              <span className="bg-green-100 text-green-700 px-3 py-1 text-xs font-bold rounded-full">Connected</span>
            </div>
            <div className="bg-white border border-border rounded-xl p-6 shadow-sm space-y-5">
              <div>
                <label className="block text-[13px] font-semibold text-foreground mb-1.5">Phone Number ID</label>
                <input type="text" defaultValue="1045981295" className="w-full border border-border rounded-lg px-3.5 py-2.5 text-[14px] bg-muted/30" />
              </div>
              <div>
                <label className="block text-[13px] font-semibold text-foreground mb-1.5">WhatsApp Business Account ID</label>
                <input type="text" defaultValue="103498194" className="w-full border border-border rounded-lg px-3.5 py-2.5 text-[14px] bg-muted/30" />
              </div>
              <div>
                <label className="block text-[13px] font-semibold text-foreground mb-1.5">Access Token</label>
                <input type="password" defaultValue="EAAGm0PX..." className="w-full border border-border rounded-lg px-3.5 py-2.5 text-[14px] bg-muted/30" />
              </div>
              <button className="text-[13px] text-red-600 font-medium hover:underline">Disconnect Meta Account</button>
            </div>
          </div>
        )
      case "Email (SMTP)":
        return (
          <div className="max-w-[800px]">
            <h1 className="text-[22px] font-bold text-foreground mb-1">Email Integration</h1>
            <p className="text-[14px] text-muted-foreground mb-7">Configure SMTP to send emails directly from workflows.</p>
            <div className="bg-white border border-border rounded-xl p-6 shadow-sm space-y-5">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[13px] font-semibold text-foreground mb-1.5">SMTP Host</label>
                  <input type="text" defaultValue="smtp.sendgrid.net" className="w-full border border-border rounded-lg px-3.5 py-2.5 text-[14px]" />
                </div>
                <div>
                  <label className="block text-[13px] font-semibold text-foreground mb-1.5">Port</label>
                  <input type="text" defaultValue="587" className="w-full border border-border rounded-lg px-3.5 py-2.5 text-[14px]" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[13px] font-semibold text-foreground mb-1.5">Username</label>
                  <input type="text" defaultValue="apikey" className="w-full border border-border rounded-lg px-3.5 py-2.5 text-[14px]" />
                </div>
                <div>
                  <label className="block text-[13px] font-semibold text-foreground mb-1.5">Password</label>
                  <input type="password" defaultValue="*********" className="w-full border border-border rounded-lg px-3.5 py-2.5 text-[14px]" />
                </div>
              </div>
              <button className="px-4 py-2 bg-gray-100 rounded-lg text-sm font-medium hover:bg-gray-200">Test Connection</button>
            </div>
          </div>
        )
      case "Voice & Calling":
        return (
          <div className="max-w-[800px]">
            <h1 className="text-[22px] font-bold text-foreground mb-1">Voice & Calling Configuration</h1>
            <p className="text-[14px] text-muted-foreground mb-7">Manage Twilio or internal AI voice infrastructure settings.</p>
            <div className="bg-white border border-border rounded-xl p-6 shadow-sm space-y-5">
              <div>
                <label className="block text-[13px] font-semibold text-foreground mb-1.5">Twilio Account SID</label>
                <input type="text" placeholder="AC..." className="w-full border border-border rounded-lg px-3.5 py-2.5 text-[14px]" />
              </div>
              <div>
                <label className="block text-[13px] font-semibold text-foreground mb-1.5">Auth Token</label>
                <input type="password" placeholder="••••••••••••" className="w-full border border-border rounded-lg px-3.5 py-2.5 text-[14px]" />
              </div>
              <div>
                <label className="block text-[13px] font-semibold text-foreground mb-1.5">Default Caller ID</label>
                <input type="text" placeholder="+1 (555) 000-0000" className="w-full border border-border rounded-lg px-3.5 py-2.5 text-[14px]" />
              </div>
            </div>
          </div>
        )
      case "Billing & Credits":
        return (
          <div className="max-w-[800px]">
            <h1 className="text-[22px] font-bold text-foreground mb-1">Billing & Credits</h1>
            <p className="text-[14px] text-muted-foreground mb-7">Manage your subscription and AI usage credits.</p>
            <div className="grid grid-cols-2 gap-6 mb-8">
              <div className="bg-white border border-border rounded-xl p-6 shadow-sm">
                <h3 className="text-[13px] font-bold text-muted-foreground uppercase tracking-wider mb-2">Current Plan</h3>
                <div className="text-[28px] font-bold text-foreground mb-1">Pro Tier</div>
                <p className="text-[13px] text-muted-foreground mb-4">$99 / month</p>
                <button className="w-full py-2 bg-muted/50 font-medium text-[13px] rounded-lg hover:bg-border">Change Plan</button>
              </div>
              <div className="bg-white border border-border rounded-xl p-6 shadow-sm">
                <h3 className="text-[13px] font-bold text-muted-foreground uppercase tracking-wider mb-2">AI Credits</h3>
                <div className="text-[28px] font-bold text-foreground mb-1">12,500 <span className="text-[14px] font-normal text-muted-foreground">remaining</span></div>
                <div className="w-full bg-gray-200 rounded-full h-2 mt-2 mb-4">
                  <div className="bg-primary h-2 rounded-full" style={{ width: '45%' }}></div>
                </div>
                <button className="w-full py-2 bg-primary font-bold text-foreground text-[13px] rounded-lg shadow-sm hover:bg-primary/90">Buy Credits</button>
              </div>
            </div>
          </div>
        )
      case "Invoices":
        return (
          <div className="max-w-[800px]">
            <h1 className="text-[22px] font-bold text-foreground mb-1">Invoices</h1>
            <p className="text-[14px] text-muted-foreground mb-7">View and download previous billing statements.</p>
            <div className="bg-white border border-border rounded-xl overflow-hidden shadow-sm">
              <table className="w-full text-left">
                <thead className="bg-muted/30 border-b border-border">
                  <tr>
                    <th className="px-5 py-3 text-[12px] font-bold text-muted-foreground">Date</th>
                    <th className="px-5 py-3 text-[12px] font-bold text-muted-foreground">Amount</th>
                    <th className="px-5 py-3 text-[12px] font-bold text-muted-foreground">Status</th>
                    <th className="px-5 py-3 text-[12px] font-bold text-muted-foreground text-right">Invoice</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E8E8E4]">
                  {[
                    { date: "Jan 1, 2026", amount: "$99.00", status: "Paid" },
                    { date: "Dec 1, 2025", amount: "$99.00", status: "Paid" },
                    { date: "Nov 1, 2025", amount: "$99.00", status: "Paid" },
                  ].map((inv, i) => (
                    <tr key={i}>
                      <td className="px-5 py-4 text-[14px]">{inv.date}</td>
                      <td className="px-5 py-4 text-[14px] font-medium">{inv.amount}</td>
                      <td className="px-5 py-4"><span className="bg-green-100 text-green-700 px-2 py-0.5 rounded text-xs">Paid</span></td>
                      <td className="px-5 py-4 text-right"><button className="text-primary hover:underline text-[13px]">Download PDF</button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )
      case "API Keys":
        return (
          <div className="max-w-[800px]">
            <div className="flex items-center justify-between mb-7">
              <div>
                <h1 className="text-[22px] font-bold text-foreground mb-1">API Keys</h1>
                <p className="text-[14px] text-muted-foreground">Manage developer keys for programmatic access.</p>
              </div>
              <button className="flex items-center gap-2 bg-foreground text-white px-4 py-2 rounded-lg text-[13px] font-medium hover:bg-foreground/90 transition-colors">
                <Plus className="h-4 w-4" /> Generate Key
              </button>
            </div>
            <div className="bg-white border border-border rounded-xl overflow-hidden shadow-sm">
              <div className="p-5 flex items-center justify-between border-b border-border">
                <div>
                  <h4 className="font-bold text-[14px] text-foreground">Production Key</h4>
                  <p className="text-[12px] text-muted-foreground">Created on Jan 10, 2026</p>
                </div>
                <div className="flex items-center gap-3">
                  <code className="bg-muted/50 px-3 py-1.5 rounded text-[13px]">sk_live_***********89f2</code>
                  <button className="text-muted-foreground hover:text-foreground text-[13px] underline">Revoke</button>
                </div>
              </div>
            </div>
          </div>
        )
      case "Security":
      case "Audit Log":
      default:
        return (
          <div className="max-w-[800px] h-full flex flex-col items-center justify-center text-center">
            <div className="w-16 h-16 bg-muted/50 rounded-full flex items-center justify-center mb-4">
              <Shield className="h-8 w-8 text-muted-foreground" />
            </div>
            <h2 className="text-[20px] font-bold text-foreground mb-2">{activeItem}</h2>
            <p className="text-[14px] text-muted-foreground max-w-[400px]">
              This section is currently under development. Configure your {activeItem.toLowerCase()} settings here soon.
            </p>
          </div>
        )
    }
  }

  return (
    <div className="flex h-full flex-1 bg-muted/30 overflow-hidden">
      
      {/* Settings Subnav */}
      <div className="w-[220px] bg-white border-r border-border py-6 flex-shrink-0 h-full overflow-y-auto">
        <h2 className="text-[16px] font-bold text-foreground px-5 mb-4">Settings</h2>
        
        <div className="space-y-6">
          {navGroups.map(group => (
            <div key={group.group_label}>
              <h3 className="text-[10px] font-semibold text-muted-foreground uppercase px-5 mb-2 tracking-wider">
                {group.group_label}
              </h3>
              <div className="space-y-0.5">
                {group.items.map(item => (
                  <button
                    key={item.label}
                    onClick={() => setActiveItem(item.label)}
                    className={cn(
                      "w-full flex items-center gap-2.5 px-5 py-2.5 text-[14px] transition-colors relative",
                      activeItem === item.label
                        ? "bg-primary/10 text-foreground font-medium"
                        : "text-muted-foreground hover:bg-muted"
                    )}
                  >
                    <item.icon className="h-4 w-4 shrink-0" />
                    <span>{item.label}</span>
                    {activeItem === item.label && (
                      <div className="absolute left-0 top-0 bottom-0 w-[3px] bg-primary" />
                    )}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex flex-col flex-1 h-full min-w-0">
        <div className="flex-1 overflow-y-auto p-8 relative">
          {renderContent()}
        </div>
        
        {/* Sticky Save Bar */}
        <div className="bg-white border-t border-border p-4 flex justify-end gap-3 shrink-0">
          <button className="px-5 py-2 border border-border rounded-lg text-[14px] font-medium text-foreground hover:bg-muted">
            Cancel
          </button>
          <button 
            onClick={handleSave}
            disabled={isSaving}
            className="px-6 py-2 bg-primary hover:bg-primary/90 text-foreground font-semibold text-[14px] rounded-lg shadow-sm shadow-primary/20 disabled:opacity-50 transition-all"
          >
            {isSaving ? "Saving..." : "Save Changes"}
          </button>
        </div>
      </div>
    </div>
  )
}
