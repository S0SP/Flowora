"use client"

import React from "react"
import { Users, Megaphone, Bot, MessageCircle, RefreshCw, FileText, CreditCard } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/atoms/Card"
import { Badge } from "@/components/atoms/Badge"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer } from "recharts"

const engagementData = [
  { name: "Day 1", sent: 1200, replies: 400 },
  { name: "Day 5", sent: 2100, replies: 600 },
  { name: "Day 10", sent: 1800, replies: 550 },
  { name: "Day 15", sent: 2400, replies: 800 },
  { name: "Day 20", sent: 3200, replies: 1200 },
  { name: "Day 25", sent: 2800, replies: 1100 },
  { name: "Day 30", sent: 4500, replies: 1800 },
]

const recentActivity = [
  { id: 1, title: "Summer Sale Campaign started", time: "10 mins ago", type: "campaign" },
  { id: 2, title: "New lead captured via AI Voice", time: "1 hour ago", type: "lead" },
  { id: 3, title: "150 Contacts synced from Google Sheets", time: "3 hours ago", type: "sync" },
  { id: 4, title: "Bot handled 45 inquiries automatically", time: "5 hours ago", type: "bot" },
]

export default function DashboardPage() {
  return (
    <div className="flex flex-col gap-8">
      {/* Hero Greeting */}
      <section className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Good morning, Alex!</h1>
          <p className="text-muted-foreground mt-1 text-lg">
            Here is what is happening with your campaigns today.
          </p>
        </div>
        <button className="h-10 rounded-md bg-primary px-4 py-2 font-medium text-primary-foreground hover:bg-primary/90 transition-colors shadow-sm">
          Create New Campaign
        </button>
      </section>

      {/* Metrics Overview */}
      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Contacts</CardTitle>
            <div className="rounded-full accent-sky p-2 flex items-center justify-center">
              <Users className="h-4 w-4" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">12,450</div>
            <div className="mt-1 flex items-center text-xs text-chart-4">
              <span className="font-medium">+12%</span>
              <span className="text-muted-foreground ml-1">from last month</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Active Campaigns</CardTitle>
            <div className="rounded-full accent-lavender p-2 flex items-center justify-center">
              <Megaphone className="h-4 w-4" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">8</div>
            <div className="mt-1 flex items-center text-xs text-chart-4">
              <span className="font-medium">+2</span>
              <span className="text-muted-foreground ml-1">from last week</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">AI Bot Conversations</CardTitle>
            <div className="rounded-full accent-lemon p-2 flex items-center justify-center">
              <Bot className="h-4 w-4" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1,204</div>
            <div className="mt-1 flex items-center text-xs text-chart-4">
              <span className="font-medium">+18%</span>
              <span className="text-muted-foreground ml-1">from yesterday</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Messages Sent</CardTitle>
            <div className="rounded-full bg-muted p-2 text-muted-foreground">
              <MessageCircle className="h-4 w-4" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">45,210</div>
            <div className="mt-1 flex items-center text-xs text-destructive">
              <span className="font-medium">-5%</span>
              <span className="text-muted-foreground ml-1">from last month</span>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Main Charts Row */}
      <section className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Engagement Overview</CardTitle>
            <CardDescription>Messages Sent vs Replies Received over 30 days</CardDescription>
          </CardHeader>
          <CardContent className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={engagementData} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#6B7280' }} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#6B7280' }} />
                <RechartsTooltip 
                  contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                />
                <Line type="monotone" dataKey="sent" stroke="#FFE27C" strokeWidth={3} dot={false} activeDot={{ r: 6 }} name="Messages Sent" />
                <Line type="monotone" dataKey="replies" stroke="#B1D8FC" strokeWidth={3} dot={false} activeDot={{ r: 6 }} name="Replies Received" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <CardDescription>Latest events across your workspace</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-5">
              {recentActivity.map((activity) => (
                <div key={activity.id} className="flex gap-4 items-start">
                  <div className="mt-0.5 h-2 w-2 rounded-full bg-primary shrink-0" />
                  <div className="flex flex-col gap-1">
                    <p className="text-sm font-medium leading-none">{activity.title}</p>
                    <p className="text-xs text-muted-foreground">{activity.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Quick Actions */}
      <section className="flex flex-wrap items-center gap-4 mt-2">
        <button className="inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80 h-9 px-4 py-2 gap-2">
          <RefreshCw className="h-4 w-4" />
          Sync Contacts
        </button>
        <button className="inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80 h-9 px-4 py-2 gap-2">
          <FileText className="h-4 w-4" />
          Review AI Transcripts
        </button>
        <button className="inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring hover:bg-accent hover:text-accent-foreground h-9 px-4 py-2 gap-2">
          <CreditCard className="h-4 w-4" />
          Manage Billing
        </button>
      </section>
    </div>
  )
}
