"use client"

import React, { useState } from "react"
import { useRouter } from "next/navigation"
import {
  ArrowLeft, Pencil, Play, Zap, Search, Globe, Database, 
  GitBranch, Bell, ZoomIn, ZoomOut, Maximize, CheckCircle, 
  X, Mail, Phone, Clock, MessageSquare, Plus, Trash2, Calendar,
  GripVertical, Settings
} from "lucide-react"
import { cn } from "@/lib/utils"
import { WorkflowCanvas, initialNodes, initialEdges } from "@/components/organisms/WorkflowCanvas"
import { ReactFlowProvider, useNodesState, useEdgesState, addEdge, Connection, Edge } from "@xyflow/react"
import { toast } from "sonner"

// Node Library Data
const nodeLibrary = [
  {
    category: "TRIGGERS",
    nodes: [
      { id: "google_sheet", icon: Database, color: "text-green-500", label: "Google Sheet", sublabel: "New Row Added", bg: "bg-green-50", border: "border-green-200" },
      { id: "webhook", icon: Globe, color: "text-foreground", label: "Webhook", sublabel: "HTTP POST Trigger", bg: "bg-muted", border: "border-transparent" },
      { id: "form", icon: MessageSquare, color: "text-foreground", label: "Form Submission", sublabel: "Any form", bg: "bg-muted", border: "border-transparent" },
    ]
  },
  {
    category: "ACTIONS",
    nodes: [
      { id: "whatsapp", icon: MessageSquare, color: "text-green-500", label: "WhatsApp", sublabel: "Send Template Message", bg: "bg-green-50", border: "border-green-200" },
      { id: "email", icon: Mail, color: "text-blue-500", label: "Email", sublabel: "Send Email", bg: "bg-blue-50", border: "border-blue-200" },
      { id: "voice", icon: Phone, color: "text-purple-500", label: "Voice Call", sublabel: "AI Voice Agent", bg: "bg-purple-50", border: "border-purple-200" },
      { id: "crm", icon: Database, color: "text-foreground", label: "Update CRM", sublabel: "Update Lead Stage", bg: "bg-muted", border: "border-transparent" },
    ]
  },
  {
    category: "FLOW CONTROL",
    nodes: [
      { id: "delay", icon: Clock, color: "text-amber-500", label: "Delay", sublabel: "Wait before next step", bg: "bg-amber-50", border: "border-amber-200" },
      { id: "condition", icon: GitBranch, color: "text-foreground", label: "Condition", sublabel: "If / Else branching", bg: "bg-muted", border: "border-transparent" },
      { id: "reminder", icon: Bell, color: "text-yellow-500", label: "Reminder", sublabel: "Scheduled reminder", bg: "bg-yellow-50", border: "border-yellow-200" },
    ]
  }
]

export default function WorkflowBuilderPage() {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("Builder")
  const [activeRightPanel, setActiveRightPanel] = useState<string | null>("1")

  // Inject onClick into initial nodes
  const nodesWithClick = initialNodes.map(node => ({
    ...node,
    data: {
      ...node.data,
      onClick: setActiveRightPanel
    }
  }))

  const [nodes, setNodes, onNodesChange] = useNodesState(nodesWithClick)
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges)

  const onConnect = React.useCallback(
    (params: Connection | Edge) => setEdges((eds) => addEdge({ ...params, type: "smoothstep" }, eds)),
    [setEdges]
  )

  const activeNode = nodes.find(n => n.id === activeRightPanel)
  const activeNodeType = activeNode?.data?.id // e.g. 'google_sheet', 'whatsapp', 'email', 'delay'

  const updateNodeData = (newData: any) => {
    if (!activeRightPanel) return;
    setNodes((nds) => 
      nds.map((n) => {
        if (n.id === activeRightPanel) {
          return {
            ...n,
            data: {
              ...n.data,
              ...newData
            }
          };
        }
        return n;
      })
    );
    toast.success("Node configuration saved");
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-background">
      {/* Topbar - Dark */}
      <div className="h-[52px] bg-foreground px-5 flex items-center justify-between shrink-0 text-white z-20">
        <div className="flex items-center gap-4">
          <button
            onClick={() => router.push("/dashboard/workflows")}
            className="flex items-center text-[13px] text-white/60 hover:text-white transition-colors"
          >
            <ArrowLeft className="h-4 w-4 mr-1" /> Workflows
          </button>
          <div className="flex items-center gap-2">
            <span className="text-[16px] font-semibold font-inter">Webinar Lead Funnel</span>
            <Pencil className="h-3 w-3 text-white/40 cursor-pointer hover:text-white" />
          </div>
          <span className="bg-white/10 text-white/70 text-[12px] px-2.5 py-1 rounded-md">Draft</span>
        </div>
        
        <div className="flex h-full">
          {["Builder", "Logs", "Analytics"].map((tab) => (
            <button 
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={cn(
                "h-full px-4 text-sm transition-colors border-b-2",
                activeTab === tab ? "border-primary text-white font-medium" : "border-transparent text-white/60 hover:text-white"
              )}
            >
              {tab}
            </button>
          ))}
        </div>
        
        <div className="flex items-center gap-3">
          <button className="px-3.5 py-1.5 text-[13px] border border-white/20 text-white/70 hover:bg-white/10 rounded-lg transition-colors">
            Save Draft
          </button>
          <button className="flex items-center gap-1.5 px-3.5 py-1.5 text-[13px] bg-white text-foreground font-medium rounded-lg hover:bg-white/90 transition-colors">
            <Play className="h-3.5 w-3.5" /> Test Run
          </button>
          <button className="flex items-center gap-1.5 px-4 py-1.5 text-[13px] bg-primary text-foreground font-bold rounded-lg shadow-sm shadow-primary/20 hover:bg-primary/90 transition-colors">
            <Zap className="h-3.5 w-3.5" /> Activate
          </button>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Left Panel: Node Library */}
        <div className="w-[260px] bg-white border-r border-border flex flex-col shrink-0 z-10">
          <div className="p-4 border-b border-border">
            <h3 className="text-[14px] font-bold text-foreground mb-3">Nodes</h3>
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <input 
                type="text" 
                placeholder="Search nodes..." 
                className="w-full bg-muted rounded-lg h-[34px] pl-9 pr-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
              />
            </div>
          </div>
          
          <div className="flex-1 overflow-y-auto p-4 space-y-6">
            {nodeLibrary.map((category) => (
              <div key={category.category}>
                <h4 className="text-[11px] text-muted-foreground uppercase tracking-wider font-semibold mb-3">{category.category}</h4>
                <div className="space-y-2">
                  {category.nodes.map((node, i) => (
                    <div 
                      key={i} 
                      draggable
                      onDragStart={(e) => {
                        e.dataTransfer.setData("application/reactflow", node.id)
                        e.dataTransfer.effectAllowed = "move"
                      }}
                      className={cn(
                        "flex items-center gap-3 p-2.5 rounded-lg border cursor-grab active:cursor-grabbing hover:shadow-sm transition-all",
                        node.bg, node.border
                      )}
                    >
                      <node.icon className={cn("h-5 w-5 shrink-0", node.color)} />
                      <div>
                        <p className="text-[13px] font-medium text-foreground leading-tight">{node.label}</p>
                        <p className="text-[11px] text-muted-foreground mt-0.5 leading-tight">{node.sublabel}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Center: Canvas (Mock React Flow) */}
        <div className="flex-1 relative overflow-hidden bg-background">
          <ReactFlowProvider>
            <WorkflowCanvas 
              nodes={nodes}
              edges={edges}
              onNodesChange={onNodesChange}
              onEdgesChange={onEdgesChange}
              onConnect={onConnect}
              setNodes={setNodes}
              setActiveRightPanel={setActiveRightPanel}
            />
          </ReactFlowProvider>
        </div>

        {/* Right Panel: Node Configuration */}
        {activeRightPanel && (
          <div className="w-[300px] bg-white border-l border-border flex flex-col shrink-0 z-10 shadow-[-8px_0_24px_rgba(0,0,0,0.03)]">
            
            {/* Google Sheet Config */}
            {activeNodeType === "google_sheet" && (
              <>
                <div className="p-4 border-b border-border">
                  <div className="flex items-start justify-between mb-1">
                    <div className="flex items-center gap-2">
                      <Database className="h-4 w-4 text-green-500" />
                      <h3 className="text-[16px] font-bold text-foreground">Google Sheet Trigger</h3>
                    </div>
                    <button onClick={() => setActiveRightPanel(null)} className="text-muted-foreground hover:text-foreground"><X className="h-4 w-4" /></button>
                  </div>
                  <p className="text-[13px] text-muted-foreground ml-6">Configure your data source</p>
                </div>
                
                <form className="flex flex-col h-full overflow-hidden" onSubmit={(e) => {
                  e.preventDefault();
                  const formData = new FormData(e.currentTarget);
                  updateNodeData({
                    fields: [
                      { label: "Sheet", value: formData.get("sheetName") || "Webinar Leads" },
                      { label: "Interval", value: formData.get("interval") || "60 sec" }
                    ]
                  });
                }}>
                  <div className="flex-1 overflow-y-auto p-5 space-y-6">
                    <div>
                      <label className="block text-[13px] font-medium text-foreground mb-2">Sheet URL</label>
                      <div className="flex rounded-md shadow-sm">
                        <input type="text" name="url" className="flex-1 min-w-0 block w-full px-3 py-2 rounded-none rounded-l-md text-[13px] border border-border focus:ring-primary focus:border-primary bg-muted/30" defaultValue="https://docs.google.com/spreadsheets/d/1BxiM..." />
                        <button type="button" className="inline-flex items-center px-3 py-2 border border-l-0 border-border rounded-r-md bg-primary text-foreground text-[13px] font-medium hover:bg-primary/90">
                          Connect
                        </button>
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-[13px] font-medium text-foreground mb-2">Sheet Name / Tab</label>
                      <select name="sheetName" className="block w-full px-3 py-2 rounded-md text-[13px] border border-border focus:ring-primary focus:border-primary bg-white">
                        <option value="Leads 2026">Sheet1 — Leads 2026</option>
                        <option value="Archive">Sheet2 — Archive</option>
                      </select>
                    </div>
                    
                    <div>
                      <label className="block text-[13px] font-medium text-foreground mb-2">Trigger On</label>
                      <div className="space-y-2">
                        <label className="flex items-center gap-2 cursor-pointer">
                          <input type="radio" name="trigger" value="new" className="text-primary focus:ring-primary h-4 w-4 border-gray-300" defaultChecked />
                          <span className="text-[13px]">New Row Added</span>
                        </label>
                        <label className="flex items-center gap-2 cursor-pointer">
                          <input type="radio" name="trigger" value="updated" className="text-primary focus:ring-primary h-4 w-4 border-gray-300" />
                          <span className="text-[13px]">Row Updated</span>
                        </label>
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-[13px] font-medium text-foreground mb-2">Polling Interval</label>
                      <select name="interval" className="block w-full px-3 py-2 rounded-md text-[13px] border border-border focus:ring-primary focus:border-primary bg-white">
                        <option value="60 sec">60 Seconds</option>
                        <option value="5 min">5 Minutes</option>
                        <option value="15 min">15 Minutes</option>
                      </select>
                    </div>
                  </div>
                  
                  <div className="p-4 border-t border-border bg-muted/30">
                    <div className="flex items-center gap-2 mb-3">
                      <CheckCircle className="h-4 w-4 text-[#22C55E]" />
                      <span className="text-[13px] text-[#22C55E] font-medium">Sheet connected successfully</span>
                    </div>
                    <button type="submit" className="w-full py-2 bg-primary text-foreground font-bold rounded-lg hover:bg-primary/90 shadow-sm transition-colors text-sm">
                      Save Configuration
                    </button>
                  </div>
                </form>
              </>
            )}

            {/* Voice Config */}
            {activeNodeType === "voice" && (
              <>
                <div className="p-4 border-b border-border">
                  <div className="flex items-start justify-between mb-1">
                    <div className="flex items-center gap-2">
                      <Phone className="h-4 w-4 text-[#C4B1F9]" />
                      <h3 className="text-[16px] font-bold text-foreground">Voice Call Node</h3>
                    </div>
                    <button onClick={() => setActiveRightPanel(null)} className="text-muted-foreground hover:text-foreground"><X className="h-4 w-4" /></button>
                  </div>
                  <p className="text-[13px] text-muted-foreground ml-6">AI Voice Agent call configuration</p>
                </div>
                
                <form className="flex flex-col h-full overflow-hidden" onSubmit={(e) => {
                  e.preventDefault();
                  const formData = new FormData(e.currentTarget);
                  updateNodeData({
                    fields: [
                      { label: "Voice", value: formData.get("agent") || "Sophia" }
                    ]
                  });
                }}>
                  <div className="flex-1 overflow-y-auto p-5 space-y-6">
                    <div>
                      <label className="block text-[13px] font-medium text-foreground mb-2">Voice Agent</label>
                      <select name="agent" className="block w-full px-3 py-2 rounded-md text-[13px] border border-border focus:ring-primary focus:border-primary bg-white">
                        <option value="Sophia">Sophia (Female · English)</option>
                        <option value="Marcus">Marcus (Male · English)</option>
                        <option value="Elena">Elena (Female · Spanish)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[13px] font-medium text-foreground mb-2">Call Objective</label>
                      <textarea 
                        name="objective"
                        className="w-full px-3 py-2 rounded-md text-[13px] border border-border focus:ring-primary focus:border-primary"
                        rows={3}
                        defaultValue="Introduce the webinar, confirm registration, answer questions, and book a demo if interested."
                      />
                    </div>

                    <div className="bg-primary/10 border border-primary rounded-lg p-3 flex gap-2">
                      <span className="text-[#F59E0B] shrink-0">ℹ️</span>
                      <p className="text-[12px] text-muted-foreground leading-tight">
                        ~15 credits per minute · Avg call 3 min = ~45 credits
                      </p>
                    </div>
                  </div>

                  <div className="p-4 border-t border-border bg-muted/30">
                    <button type="submit" className="w-full py-2 bg-primary text-foreground font-bold rounded-lg hover:bg-primary/90 shadow-sm transition-colors text-sm">
                      Save Voice Node
                    </button>
                  </div>
                </form>
              </>
            )}

            {/* WhatsApp / Email Config */}
            {(activeNodeType === "whatsapp" || activeNodeType === "email") && (
              <>
                <div className="p-4 border-b border-border">
                  <div className="flex items-start justify-between mb-1">
                    <div className="flex items-center gap-2">
                      {activeNodeType === "whatsapp" ? <MessageSquare className="h-4 w-4 text-[#22C55E]" /> : <Mail className="h-4 w-4 text-[#B1D8FC]" />}
                      <h3 className="text-[16px] font-bold text-foreground capitalize">{activeNodeType} Message</h3>
                    </div>
                    <button onClick={() => setActiveRightPanel(null)} className="text-muted-foreground hover:text-foreground"><X className="h-4 w-4" /></button>
                  </div>
                  <p className="text-[13px] text-muted-foreground ml-6">Configure outbound message</p>
                </div>
                
                <form className="flex flex-col h-full overflow-hidden" onSubmit={(e) => {
                  e.preventDefault();
                  const formData = new FormData(e.currentTarget);
                  updateNodeData({
                    fields: [
                      { label: "Template", value: formData.get("template") || "Standard" }
                    ]
                  });
                }}>
                  <div className="flex-1 overflow-y-auto p-5 space-y-6">
                    <div>
                      <label className="block text-[13px] font-medium text-foreground mb-2">Message Template</label>
                      <select name="template" className="block w-full px-3 py-2 rounded-md text-[13px] border border-border focus:ring-primary focus:border-primary bg-white">
                        <option value="webinar_invite">Webinar Invite Template</option>
                        <option value="follow_up_1">Follow-up Template 1</option>
                        <option value="reminder">Event Reminder</option>
                      </select>
                    </div>
                  </div>

                  <div className="p-4 border-t border-border bg-muted/30">
                    <button type="submit" className="w-full py-2 bg-primary text-foreground font-bold rounded-lg hover:bg-primary/90 shadow-sm transition-colors text-sm">
                      Save Template
                    </button>
                  </div>
                </form>
              </>
            )}

            {/* Delay Config */}
            {activeNodeType === "delay" && (
              <>
                <div className="p-4 border-b border-border">
                  <div className="flex items-start justify-between mb-1">
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-amber-500" />
                      <h3 className="text-[16px] font-bold text-foreground">Time Delay</h3>
                    </div>
                    <button onClick={() => setActiveRightPanel(null)} className="text-muted-foreground hover:text-foreground"><X className="h-4 w-4" /></button>
                  </div>
                  <p className="text-[13px] text-muted-foreground ml-6">Pause workflow execution</p>
                </div>
                
                <form className="flex flex-col h-full overflow-hidden" onSubmit={(e) => {
                  e.preventDefault();
                  const formData = new FormData(e.currentTarget);
                  updateNodeData({
                    fields: [
                      { label: "Wait", value: `${formData.get("amount")} ${formData.get("unit")}` }
                    ]
                  });
                }}>
                  <div className="flex-1 overflow-y-auto p-5 space-y-6">
                    <div>
                      <label className="block text-[13px] font-medium text-foreground mb-2">Delay Duration</label>
                      <div className="flex gap-2">
                        <input type="number" name="amount" defaultValue={1} min={1} className="w-20 px-3 py-2 rounded-md text-[13px] border border-border focus:ring-primary bg-white" />
                        <select name="unit" className="flex-1 px-3 py-2 rounded-md text-[13px] border border-border focus:ring-primary bg-white">
                          <option value="Minutes">Minutes</option>
                          <option value="Hours">Hours</option>
                          <option value="Days">Days</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  <div className="p-4 border-t border-border bg-muted/30">
                    <button type="submit" className="w-full py-2 bg-primary text-foreground font-bold rounded-lg hover:bg-primary/90 shadow-sm transition-colors text-sm">
                      Save Delay
                    </button>
                  </div>
                </form>
              </>
            )}

            {/* Other Configs Fallback */}
            {activeNodeType !== "google_sheet" && activeNodeType !== "voice" && activeNodeType !== "whatsapp" && activeNodeType !== "email" && activeNodeType !== "delay" && (
               <div className="flex-1 flex flex-col items-center justify-center text-muted-foreground text-sm p-4 text-center">
                 <Settings className="h-8 w-8 text-muted-foreground/30 mb-3" />
                 <p>Configuration panel for <b>{activeNodeType}</b> is coming soon.</p>
               </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
