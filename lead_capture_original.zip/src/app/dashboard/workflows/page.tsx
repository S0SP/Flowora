"use client"

import React, { useState } from "react"
import Link from "next/link"
import {
  Plus, Search, Filter, Workflow, Play, Pause, MoreVertical,
  Zap, Clock, CheckCircle2, XCircle, Copy, Trash2, Edit3,
  MessageSquare, Mail, Phone, Database, GitBranch, Bell, Globe,
  TrendingUp, Users, ArrowUpRight
} from "lucide-react"
import { cn } from "@/lib/utils"
import { toast } from "sonner"
import { motion, AnimatePresence } from "framer-motion"

// ─── Mock data ─────────────────────────────────────────────────────────────
const MOCK_WORKFLOWS = [
  {
    id: "wf1",
    name: "Webinar Lead Funnel",
    status: "active",
    trigger: { type: "google_sheet", label: "Google Sheet" },
    steps: ["WhatsApp", "Delay 1h", "Email", "Voice Call"],
    runs: 284,
    successRate: 94,
    lastRun: "2 min ago",
    nodes: [
      { icon: Database, color: "text-green-500", bg: "bg-green-50" },
      { icon: MessageSquare, color: "text-green-500", bg: "bg-green-50" },
      { icon: Clock, color: "text-amber-500", bg: "bg-amber-50" },
      { icon: Mail, color: "text-blue-500", bg: "bg-blue-50" },
    ],
  },
  {
    id: "wf2",
    name: "Demo Booking Sequence",
    status: "active",
    trigger: { type: "webhook", label: "Webhook" },
    steps: ["WhatsApp Template", "If No Reply → Delay 24h → WhatsApp Reminder"],
    runs: 127,
    successRate: 88,
    lastRun: "15 min ago",
    nodes: [
      { icon: Globe, color: "text-foreground", bg: "bg-muted" },
      { icon: MessageSquare, color: "text-green-500", bg: "bg-green-50" },
      { icon: GitBranch, color: "text-foreground", bg: "bg-muted" },
      { icon: Bell, color: "text-yellow-500", bg: "bg-yellow-50" },
    ],
  },
  {
    id: "wf3",
    name: "Post-Purchase Follow-up",
    status: "paused",
    trigger: { type: "webhook", label: "Webhook" },
    steps: ["Email Welcome", "Delay 3d", "WhatsApp Check-in", "WhatsApp Review Request"],
    runs: 56,
    successRate: 97,
    lastRun: "3 days ago",
    nodes: [
      { icon: Globe, color: "text-foreground", bg: "bg-muted" },
      { icon: Mail, color: "text-blue-500", bg: "bg-blue-50" },
      { icon: Clock, color: "text-amber-500", bg: "bg-amber-50" },
      { icon: MessageSquare, color: "text-green-500", bg: "bg-green-50" },
    ],
  },
  {
    id: "wf4",
    name: "High-Value Lead Alert",
    status: "active",
    trigger: { type: "condition", label: "Lead Score > 80" },
    steps: ["Notify Agent", "WhatsApp Priority"],
    runs: 18,
    successRate: 100,
    lastRun: "1 hour ago",
    nodes: [
      { icon: GitBranch, color: "text-foreground", bg: "bg-muted" },
      { icon: Bell, color: "text-yellow-500", bg: "bg-yellow-50" },
      { icon: Phone, color: "text-[#C4B1F9]", bg: "bg-purple-50" },
    ],
  },
  {
    id: "wf5",
    name: "AI Voice Outreach",
    status: "draft",
    trigger: { type: "google_sheet", label: "Google Sheet" },
    steps: ["Filter Leads", "Voice Call AI", "Update CRM"],
    runs: 0,
    successRate: 0,
    lastRun: "Never",
    nodes: [
      { icon: Database, color: "text-green-500", bg: "bg-green-50" },
      { icon: Phone, color: "text-[#C4B1F9]", bg: "bg-purple-50" },
      { icon: Database, color: "text-foreground", bg: "bg-muted" },
    ],
  },
]

const TEMPLATES = [
  { name: "Lead Qualification", icon: MessageSquare, color: "#22C55E", desc: "AI qualifies WhatsApp leads automatically" },
  { name: "Demo Booking", icon: Phone, color: "#C4B1F9", desc: "Book demos via WhatsApp without agents" },
  { name: "Follow-up Sequence", icon: Mail, color: "#B1D8FC", desc: "5-day nurture via WhatsApp + Email" },
  { name: "Sheet → WhatsApp", icon: Database, color: "#FFE27C", desc: "Auto-message new Google Sheet rows" },
]

// ─── Status badge ──────────────────────────────────────────────────────────
function StatusBadge({ status }: { status: string }) {
  const cfg = {
    active: { label: "Active", dot: "bg-green-400", text: "text-green-700", bg: "bg-green-50 border-green-200" },
    paused: { label: "Paused", dot: "bg-amber-400", text: "text-amber-700", bg: "bg-amber-50 border-amber-200" },
    draft:  { label: "Draft",  dot: "bg-[#9B9B9B]", text: "text-[#6B6B6B]", bg: "bg-[#F4F4F2] border-[#E8E8E4]" },
  }[status] ?? { label: status, dot: "bg-gray-400", text: "text-gray-700", bg: "bg-gray-50 border-gray-200" }

  return (
    <span className={cn("inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full border text-[11px] font-semibold", cfg.bg, cfg.text)}>
      <span className={cn("w-1.5 h-1.5 rounded-full", cfg.dot, status === "active" && "animate-pulse")} />
      {cfg.label}
    </span>
  )
}

// ─── Workflow card ─────────────────────────────────────────────────────────
function WorkflowCard({ wf, onStatusToggle, onDelete }: {
  wf: typeof MOCK_WORKFLOWS[0]
  onStatusToggle: (id: string) => void
  onDelete: (id: string) => void
}) {
  const [menuOpen, setMenuOpen] = React.useState(false)

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.97 }}
      className="bg-white border border-[#E8E8E4] rounded-2xl p-5 hover:border-[#C4B1F9]/40 hover:shadow-md transition-all group"
    >
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1.5">
            <StatusBadge status={wf.status} />
            <span className="text-[11px] text-[#9B9B9B]">{wf.lastRun}</span>
          </div>
          <h3 className="font-bold text-[15px] text-[#1B1B1B] leading-tight">{wf.name}</h3>
          <p className="text-[12px] text-[#9B9B9B] mt-0.5">Trigger: {wf.trigger.label}</p>
        </div>
        <div className="relative flex-shrink-0 ml-3">
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="p-1.5 rounded-lg text-[#9B9B9B] hover:bg-[#F4F4F2] hover:text-[#1B1B1B] transition-colors opacity-0 group-hover:opacity-100"
          >
            <MoreVertical className="h-4 w-4" />
          </button>
          <AnimatePresence>
            {menuOpen && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95, y: -4 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="absolute right-0 top-full mt-1 w-44 bg-white border border-[#E8E8E4] rounded-xl shadow-xl z-20 overflow-hidden"
              >
                {[
                  { icon: Edit3, label: "Edit workflow", href: `/dashboard/workflows/builder?id=${wf.id}` },
                  { icon: Copy, label: "Duplicate" },
                  { icon: wf.status === "active" ? Pause : Play, label: wf.status === "active" ? "Pause" : "Activate" },
                  { icon: Trash2, label: "Delete", danger: true },
                ].map((m) => (
                  <div key={m.label}>
                    {m.href ? (
                      <Link href={m.href} className="flex items-center gap-2.5 px-3 py-2.5 text-[13px] hover:bg-[#FAFAF8] transition-colors text-[#1B1B1B]">
                        <m.icon className="w-3.5 h-3.5 text-[#6B6B6B]" />
                        {m.label}
                      </Link>
                    ) : (
                      <button
                        onClick={() => {
                          setMenuOpen(false)
                          if (m.label === "Delete") onDelete(wf.id)
                          else if (m.label === "Activate" || m.label === "Pause") onStatusToggle(wf.id)
                        }}
                        className={cn(
                          "w-full flex items-center gap-2.5 px-3 py-2.5 text-[13px] hover:bg-[#FAFAF8] transition-colors",
                          m.danger ? "text-red-600" : "text-[#1B1B1B]"
                        )}
                      >
                        <m.icon className={cn("w-3.5 h-3.5", m.danger ? "text-red-400" : "text-[#6B6B6B]")} />
                        {m.label}
                      </button>
                    )}
                  </div>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Node flow preview */}
      <div className="flex items-center gap-1.5 mb-4">
        {wf.nodes.map((n, i) => (
          <React.Fragment key={i}>
            <div className={cn("w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0", n.bg)}>
              <n.icon className={cn("w-3.5 h-3.5", n.color)} />
            </div>
            {i < wf.nodes.length - 1 && (
              <div className="flex-1 h-px bg-[#E8E8E4] max-w-[20px]" />
            )}
          </React.Fragment>
        ))}
        {wf.nodes.length > 0 && (
          <span className="text-[10px] text-[#9B9B9B] ml-1">+{Math.max(0, wf.steps.length - wf.nodes.length)} more</span>
        )}
      </div>

      {/* Stats row */}
      <div className="flex items-center gap-4 pt-3 border-t border-[#F4F4F2]">
        <div className="flex items-center gap-1.5">
          <TrendingUp className="w-3.5 h-3.5 text-[#9B9B9B]" />
          <span className="text-[12px] font-semibold text-[#1B1B1B]">{wf.runs.toLocaleString()}</span>
          <span className="text-[11px] text-[#9B9B9B]">runs</span>
        </div>
        {wf.runs > 0 && (
          <div className="flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-green-500" />
            <span className="text-[12px] font-semibold text-[#1B1B1B]">{wf.successRate}%</span>
            <span className="text-[11px] text-[#9B9B9B]">success</span>
          </div>
        )}
        <div className="ml-auto">
          <Link
            href={`/dashboard/workflows/builder?id=${wf.id}`}
            className="flex items-center gap-1 text-[12px] font-semibold text-[#6B6B6B] hover:text-[#1B1B1B] transition-colors group/link"
          >
            Edit <ArrowUpRight className="w-3.5 h-3.5 group-hover/link:translate-x-0.5 group-hover/link:-translate-y-0.5 transition-transform" />
          </Link>
        </div>
      </div>
    </motion.div>
  )
}

// ─── Main page ─────────────────────────────────────────────────────────────
export default function WorkflowsPage() {
  const [workflows, setWorkflows] = useState(MOCK_WORKFLOWS)
  const [search, setSearch] = useState("")
  const [filter, setFilter] = useState<"all" | "active" | "paused" | "draft">("all")
  const [showTemplates, setShowTemplates] = useState(false)

  const filtered = workflows.filter(wf => {
    const matchSearch = wf.name.toLowerCase().includes(search.toLowerCase())
    const matchFilter = filter === "all" || wf.status === filter
    return matchSearch && matchFilter
  })

  const handleToggle = (id: string) => {
    setWorkflows(ws => ws.map(w => {
      if (w.id !== id) return w
      const next = w.status === "active" ? "paused" : "active"
      toast.success(`Workflow ${next === "active" ? "activated" : "paused"}`)
      return { ...w, status: next }
    }))
  }

  const handleDelete = (id: string) => {
    setWorkflows(ws => ws.filter(w => w.id !== id))
    toast.success("Workflow deleted")
  }

  const stats = {
    total: workflows.length,
    active: workflows.filter(w => w.status === "active").length,
    totalRuns: workflows.reduce((a, w) => a + w.runs, 0),
    avgSuccess: Math.round(workflows.filter(w => w.runs > 0).reduce((a, w) => a + w.successRate, 0) / Math.max(1, workflows.filter(w => w.runs > 0).length)),
  }

  return (
    <div className="h-full flex flex-col overflow-hidden bg-[#FAFAF8]">
      {/* Header */}
      <div className="flex-shrink-0 bg-white border-b border-[#E8E8E4] px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-[#1B1B1B]">Workflows</h1>
            <p className="text-sm text-[#9B9B9B] mt-0.5">Automate your lead engagement across every channel</p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowTemplates(!showTemplates)}
              className="flex items-center gap-2 px-3.5 py-2 border border-[#E8E8E4] rounded-xl text-sm font-semibold text-[#6B6B6B] hover:bg-[#F4F4F2] transition-colors"
            >
              <Zap className="w-4 h-4" />
              Templates
            </button>
            <Link
              href="/dashboard/workflows/builder"
              className="flex items-center gap-2 px-3.5 py-2 bg-[#FFE27C] hover:bg-[#FFD84A] text-[#1B1B1B] rounded-xl text-sm font-bold transition-colors shadow-[0_2px_8px_rgba(255,226,124,0.3)]"
            >
              <Plus className="w-4 h-4" />
              New Workflow
            </Link>
          </div>
        </div>

        {/* Stats row */}
        <div className="flex items-center gap-6 mt-4 pt-4 border-t border-[#F4F4F2]">
          {[
            { label: "Total", value: stats.total, icon: Workflow },
            { label: "Active", value: stats.active, icon: Play, color: "text-green-600" },
            { label: "Total runs", value: stats.totalRuns.toLocaleString(), icon: TrendingUp },
            { label: "Avg success", value: `${stats.avgSuccess}%`, icon: CheckCircle2, color: "text-green-600" },
          ].map(s => (
            <div key={s.label} className="flex items-center gap-2">
              <s.icon className={cn("w-4 h-4 text-[#9B9B9B]", s.color)} />
              <span className="text-sm font-bold text-[#1B1B1B]">{s.value}</span>
              <span className="text-sm text-[#9B9B9B]">{s.label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Template picker banner */}
      <AnimatePresence>
        {showTemplates && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="border-b border-[#E8E8E4] bg-[#FEFCE8] overflow-hidden flex-shrink-0"
          >
            <div className="px-6 py-4">
              <h3 className="text-sm font-bold text-[#1B1B1B] mb-3">Start from a template</h3>
              <div className="grid grid-cols-4 gap-3">
                {TEMPLATES.map(t => (
                  <button
                    key={t.name}
                    onClick={() => {
                      toast.success(`"${t.name}" template loaded in builder`)
                      setShowTemplates(false)
                    }}
                    className="flex items-start gap-3 p-3 bg-white rounded-xl border border-[#E8E8E4] hover:border-[#FFE27C] hover:shadow-sm transition-all text-left"
                  >
                    <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0" style={{ backgroundColor: t.color + "20" }}>
                      <t.icon className="w-4 h-4" style={{ color: t.color }} />
                    </div>
                    <div>
                      <p className="text-[12px] font-bold text-[#1B1B1B] leading-tight">{t.name}</p>
                      <p className="text-[11px] text-[#9B9B9B] mt-0.5 leading-tight">{t.desc}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Filters row */}
      <div className="flex-shrink-0 px-6 py-3 border-b border-[#F4F4F2] bg-white flex items-center gap-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[#9B9B9B]" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search workflows..."
            className="pl-9 pr-4 py-2 bg-[#F4F4F2] border border-transparent rounded-xl text-sm focus:outline-none focus:border-[#FFE27C] focus:bg-white transition-all w-56"
          />
        </div>
        <div className="flex items-center gap-1 bg-[#F4F4F2] p-1 rounded-xl">
          {(["all", "active", "paused", "draft"] as const).map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={cn(
                "px-3 py-1.5 text-[12px] font-semibold rounded-lg capitalize transition-all",
                filter === f ? "bg-white text-[#1B1B1B] shadow-sm" : "text-[#9B9B9B] hover:text-[#6B6B6B]"
              )}
            >
              {f}
            </button>
          ))}
        </div>
        <span className="ml-auto text-[12px] text-[#9B9B9B]">{filtered.length} workflow{filtered.length !== 1 ? "s" : ""}</span>
      </div>

      {/* Workflow grid */}
      <div className="flex-1 overflow-y-auto p-6">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-64 text-center">
            <Workflow className="w-12 h-12 text-[#E8E8E4] mb-4" />
            <h3 className="text-[#1B1B1B] font-semibold mb-1">No workflows found</h3>
            <p className="text-[#9B9B9B] text-sm">Try adjusting your search or filter</p>
          </div>
        ) : (
          <motion.div layout className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            <AnimatePresence mode="popLayout">
              {filtered.map(wf => (
                <WorkflowCard
                  key={wf.id}
                  wf={wf}
                  onStatusToggle={handleToggle}
                  onDelete={handleDelete}
                />
              ))}
            </AnimatePresence>

            {/* Add new card */}
            <Link
              href="/dashboard/workflows/builder"
              className="bg-white border-2 border-dashed border-[#E8E8E4] rounded-2xl p-5 flex flex-col items-center justify-center gap-3 hover:border-[#FFE27C] hover:bg-[#FEFCE8] transition-all group min-h-[200px]"
            >
              <div className="w-12 h-12 rounded-2xl bg-[#F4F4F2] group-hover:bg-[#FFE27C]/20 flex items-center justify-center transition-colors">
                <Plus className="w-6 h-6 text-[#9B9B9B] group-hover:text-[#1B1B1B] transition-colors" />
              </div>
              <div className="text-center">
                <p className="font-bold text-sm text-[#6B6B6B] group-hover:text-[#1B1B1B] transition-colors">Create new workflow</p>
                <p className="text-xs text-[#9B9B9B] mt-0.5">Start from scratch or use a template</p>
              </div>
            </Link>
          </motion.div>
        )}
      </div>
    </div>
  )
}
