"use client"

import { Sidebar } from "@/components/organisms/Sidebar"
import { Topbar } from "@/components/organisms/Topbar"
import { useUIStore } from "@/lib/store/useUiStore"
import { cn } from "@/lib/utils"

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const { isSidebarOpen } = useUIStore()

  return (
    <div className="relative flex h-screen w-screen overflow-hidden bg-[#FAFAF8] text-foreground">
      <Sidebar />
      {/* Main content shifts right based on sidebar width */}
      <div
        className="flex flex-1 flex-col min-w-0 overflow-hidden transition-all duration-[250ms] ease-[cubic-bezier(0.4,0,0.2,1)]"
        style={{ marginLeft: isSidebarOpen ? 240 : 72 }}
      >
        <Topbar />
        <main className="flex-1 overflow-y-auto no-scrollbar min-h-0">
          {children}
        </main>
      </div>
    </div>
  )
}
