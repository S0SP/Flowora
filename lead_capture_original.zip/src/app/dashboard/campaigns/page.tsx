"use client"

import React, { useState } from "react"
import { Check, CheckCircle2, BadgeCheck, ChevronRight, ArrowRight, ArrowLeft } from "lucide-react"
import { cn } from "@/lib/utils"

const steps = [
  { number: 1, label: "Recipients", state: "completed" },
  { number: 2, label: "Message", state: "active" },
  { number: 3, label: "Preview", state: "pending" },
  { number: 4, label: "Schedule", state: "pending" },
  { number: 5, label: "Review & Launch", state: "pending" }
]

export default function CampaignBuilderPage() {
  const [activeStep, setActiveStep] = useState(2)

  return (
    <div className="flex flex-col h-full flex-1  bg-muted/30 relative">
      
      {/* Header Area */}
      <div className="flex-shrink-0 p-6 border-b border-border bg-card">
        <div className="text-[13px] text-muted-foreground flex items-center gap-1.5 mb-2">
          <span>Campaigns</span> <ChevronRight className="h-3.5 w-3.5" /> <span className="font-medium text-foreground">New Campaign</span>
        </div>
        <h1 className="text-2xl font-bold text-foreground mb-8">New WhatsApp Campaign</h1>
        
        {/* Stepper */}
        <div className="flex items-center justify-between relative max-w-3xl">
          <div className="absolute left-0 top-1/2 -translate-y-1/2 w-full h-[2px] bg-border -z-10" />
          {/* Progress bar */}
          <div className="absolute left-0 top-1/2 -translate-y-1/2 h-[2px] bg-primary -z-10" style={{ width: "25%" }} />
          
          {steps.map((step, idx) => (
            <div key={idx} className="flex flex-col items-center gap-2 bg-card px-2">
              <div className={cn(
                "w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold border-2 z-10 transition-colors",
                step.state === "completed" ? "bg-primary border-primary text-primary-foreground" :
                step.state === "active" ? "bg-primary/10 border-primary text-primary" :
                "bg-muted border-border text-muted-foreground"
              )}>
                {step.state === "completed" ? <Check className="h-4 w-4" /> : step.number}
              </div>
              <span className={cn(
                "text-[12px] font-medium absolute top-10 whitespace-nowrap",
                step.state === "active" ? "text-primary" : "text-muted-foreground"
              )}>
                {step.label}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-auto flex pb-[80px]">
        {/* Left Form */}
        <div className="w-[55%] p-8 overflow-y-auto">
          <div className="max-w-xl space-y-8">
            
            {/* Account Selector */}
            <div>
              <label className="block text-[14px] font-bold text-foreground mb-3">WhatsApp Business Account</label>
              <div className="border border-border bg-card rounded-lg p-4 flex items-center justify-between cursor-pointer hover:border-primary transition-colors">
                <div className="flex flex-col">
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-[14px] text-foreground">Flowora — Acme Corp</span>
                    <BadgeCheck className="h-4 w-4 text-blue-500" />
                  </div>
                  <span className="text-[13px] text-muted-foreground">+1 415 555 0100</span>
                </div>
                <div className="w-4 h-4 rounded-full border-4 border-primary bg-background" />
              </div>
            </div>

            {/* Template Selection */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <label className="block text-[14px] font-bold text-foreground">Select Template</label>
                <button className="text-[13px] font-medium text-primary hover:underline">Manage Templates</button>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                {/* Template 1 (Selected) */}
                <div className="bg-primary/5 border-2 border-primary rounded-lg p-4 cursor-pointer relative shadow-sm">
                  <div className="absolute -top-2 -right-2 w-6 h-6 bg-primary rounded-full flex items-center justify-center text-primary-foreground shadow-sm">
                    <Check className="h-4 w-4" />
                  </div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="font-semibold text-[14px] text-foreground truncate">webinar_invite_v2</span>
                    <span className="text-[10px] font-medium bg-green-100 text-green-700 px-1.5 py-0.5 rounded">Marketing</span>
                  </div>
                  <p className="text-[12px] text-muted-foreground line-clamp-2 leading-relaxed">
                    Hi {"{{1}}"}! 👋 Join our exclusive webinar...
                  </p>
                  <div className="mt-3 flex items-center gap-1 text-[11px] font-medium text-muted-foreground">
                    <CheckCircle2 className="h-3 w-3 text-green-500" /> Approved
                  </div>
                </div>

                {/* Template 2 */}
                <div className="bg-card border border-border rounded-lg p-4 cursor-pointer hover:border-primary/50 transition-colors">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="font-semibold text-[14px] text-foreground truncate">demo_confirmation</span>
                    <span className="text-[10px] font-medium bg-muted text-muted-foreground px-1.5 py-0.5 rounded">Utility</span>
                  </div>
                  <p className="text-[12px] text-muted-foreground line-clamp-2 leading-relaxed">
                    Your demo is confirmed for {"{{date}}"}...
                  </p>
                  <div className="mt-3 flex items-center gap-1 text-[11px] font-medium text-muted-foreground">
                    <CheckCircle2 className="h-3 w-3 text-green-500" /> Approved
                  </div>
                </div>
              </div>
            </div>

            {/* Variable Mapping */}
            <div>
              <label className="block text-[14px] font-bold text-foreground mb-3">Map Variables</label>
              <div className="bg-card border border-border rounded-lg p-1">
                <div className="grid grid-cols-[120px_auto_1fr] items-center gap-3 p-3 border-b border-border">
                  <div className="bg-muted px-2 py-1.5 rounded text-[13px] font-medium text-muted-foreground">{"{{1}}"} Name</div>
                  <ArrowRight className="h-4 w-4 text-muted-foreground/50" />
                  <select className="border border-input rounded-md px-3 py-1.5 bg-background text-[13px] w-full focus:ring-1 focus:ring-primary focus:border-primary text-foreground">
                    <option>Contact List: contact_name</option>
                  </select>
                </div>
                <div className="grid grid-cols-[120px_auto_1fr] items-center gap-3 p-3">
                  <div className="bg-muted px-2 py-1.5 rounded text-[13px] font-medium text-muted-foreground">{"{{2}}"} Date</div>
                  <ArrowRight className="h-4 w-4 text-muted-foreground/50" />
                  <input type="text" defaultValue="Jan 20, 2026" className="border border-input rounded-md px-3 py-1.5 bg-background text-[13px] w-full focus:ring-1 focus:ring-primary focus:border-primary text-foreground" />
                </div>
              </div>
            </div>

          </div>
        </div>

        {/* Right Preview */}
        <div className="w-[45%] bg-muted/50 border-l border-border p-8 flex flex-col items-center">
          <div className="w-full max-w-[280px]">
            <h3 className="text-[14px] font-bold text-foreground mb-4">Live Preview</h3>
            
            {/* Phone Mockup */}
            <div className="bg-white rounded-[24px] shadow-xl border-4 border-[#1B1B1B] overflow-hidden w-full h-[580px] flex flex-col relative">
              {/* Status Bar */}
              <div className="h-6 bg-white w-full flex justify-between items-center px-4 text-[10px] font-medium">
                <span>9:41</span>
                <div className="flex items-center gap-1">
                  <span>📶</span>
                  <span>🔋</span>
                </div>
              </div>
              
              {/* WhatsApp Header */}
              <div className="bg-[#075E54] text-white p-3 flex items-center gap-3 shadow-sm z-10">
                <ArrowLeft className="h-5 w-5" />
                <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center shrink-0">
                  <span className="text-[10px] text-black font-bold">FL</span>
                </div>
                <div>
                  <div className="flex items-center gap-1">
                    <span className="font-semibold text-[14px]">Flowora</span>
                    <BadgeCheck className="h-3 w-3 text-blue-400" />
                  </div>
                  <span className="text-[10px] text-white/80">Business Account</span>
                </div>
              </div>
              
              {/* Chat Area */}
              <div className="flex-1 bg-[#E5DDD5] p-3 overflow-y-auto relative" style={{ backgroundImage: "url('https://w0.peakpx.com/wallpaper/818/148/HD-wallpaper-whatsapp-background-cool-dark-green-new-theme-whatsapp.jpg')", backgroundSize: "cover", backgroundBlendMode: "overlay" }}>
                
                {/* Date Badge */}
                <div className="flex justify-center mb-4">
                  <span className="bg-[#E1F3FB] text-[#4A5568] text-[10px] px-2 py-0.5 rounded-lg shadow-sm">Today</span>
                </div>

                {/* Message Bubble */}
                <div className="bg-[#FFFFFF] rounded-lg p-2.5 shadow-sm max-w-[90%] relative">
                  <p className="text-[13px] text-foreground leading-relaxed whitespace-pre-wrap font-sans">
                    Hi Sarah! 👋
                    {"\n\n"}
                    Join our exclusive webinar on
                    'AI for Business Growth'
                    {"\n\n"}
                    📅 Date: Jan 20, 2026
                    📍 Online (Zoom)
                    {"\n\n"}
                    Reserve your spot now!
                    https://flowora.com/webinar
                  </p>
                  <div className="flex justify-end items-center gap-1 mt-1">
                    <span className="text-[9px] text-muted-foreground">10:32 AM</span>
                  </div>
                  
                  {/* CTA Button */}
                  <div className="mt-2 border-t border-gray-100 pt-2">
                    <div className="w-full py-2 bg-transparent text-[#00A884] text-[13px] font-medium text-center flex items-center justify-center gap-1">
                      Register Now
                    </div>
                  </div>
                </div>

              </div>
              
              {/* Input Area */}
              <div className="bg-[#F0F0F0] p-2 flex items-center gap-2">
                <div className="bg-white rounded-full flex-1 h-9 px-3 flex items-center text-[13px] text-muted-foreground">
                  Type a message...
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Navigation */}
      <div className="absolute bottom-0 left-0 right-0 bg-card border-t border-border px-6 py-4 flex items-center justify-between shadow-[0_-4px_16px_rgba(0,0,0,0.02)] z-20">
        <button className="px-6 py-2.5 text-[14px] font-medium text-muted-foreground hover:text-foreground hover:bg-muted rounded-lg transition-colors flex items-center gap-2">
          <ArrowLeft className="h-4 w-4" /> Back
        </button>
        <button className="px-6 py-2.5 text-[14px] font-bold text-primary-foreground bg-primary hover:bg-primary/90 shadow-sm rounded-lg transition-colors flex items-center gap-2">
          Next <ArrowRight className="h-4 w-4" />
        </button>
      </div>

    </div>
  )
}
