"use client"

import React, { useState } from "react"
import { CheckCircle2, RefreshCw, Plus, Globe, FileSpreadsheet, FileText, Send, ZoomIn, ZoomOut, Maximize, Search } from "lucide-react"
import { ReactFlow, Background, Controls, Node, Edge, MarkerType } from "@xyflow/react"
import "@xyflow/react/dist/style.css"
import { cn } from "@/lib/utils"

const sources = [
  { id: 1, icon: Globe, iconColor: "text-blue-500", name: "acme.com", type: "Website", meta: "42 pages", statusDot: "bg-green-500", progress: 70 },
  { id: 2, icon: FileSpreadsheet, iconColor: "text-green-600", name: "Pricing Sheet", type: "Google Sheet", meta: "128 rows", statusDot: "bg-green-500" },
  { id: 3, icon: FileText, iconColor: "text-amber-500", name: "FAQ.pdf", type: "Document", meta: "84 chunks", statusDot: "bg-green-500" },
  { id: 4, icon: FileText, iconColor: "text-slate-500", name: "product_catalog.pdf", type: "Document", meta: "210 chunks", statusDot: "bg-green-500" },
  { id: 5, icon: Globe, iconColor: "text-slate-500", name: "docs.acme.com", type: "Documentation", meta: "18 pages", statusDot: "bg-amber-500", statusLabel: "Processing..." },
]

const initialNodes: Node[] = [
  {
    id: "center",
    type: "default",
    data: { label: "Acme Corp" },
    position: { x: 400, y: 300 },
    style: {
      background: "#6C47FF",
      color: "white",
      fontWeight: "bold",
      fontSize: "14px",
      borderRadius: "50%",
      width: 64,
      height: 64,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      boxShadow: "0 0 15px rgba(108,71,255,0.5)",
      border: "none"
    }
  },
  { id: "products", data: { label: "Products" }, position: { x: 400, y: 150 }, style: { background: "#F3EFFF", color: "#6C47FF", borderRadius: "50%", width: 48, height: 48, display: "flex", alignItems: "center", justifyContent: "center", border: "1px solid #6C47FF" } },
  { id: "pricing", data: { label: "Pricing" }, position: { x: 550, y: 200 }, style: { background: "#E1F3FB", color: "#0284C7", borderRadius: "50%", width: 44, height: 44, display: "flex", alignItems: "center", justifyContent: "center", border: "1px solid #0284C7" } },
  { id: "policies", data: { label: "Policies" }, position: { x: 600, y: 300 }, style: { background: "#F3EFFF", color: "#6C47FF", borderRadius: "50%", width: 40, height: 40, display: "flex", alignItems: "center", justifyContent: "center", border: "1px solid #6C47FF" } },
  { id: "faq", data: { label: "FAQ" }, position: { x: 550, y: 400 }, style: { background: "#E6F4EA", color: "#137333", border: "1px solid #137333", borderRadius: "50%", width: 44, height: 44, display: "flex", alignItems: "center", justifyContent: "center" } },
  { id: "integrations", data: { label: "Integrations" }, position: { x: 400, y: 450 }, style: { background: "#FEF9C3", color: "#854D0E", border: "1px solid #854D0E", borderRadius: "50%", width: 40, height: 40, display: "flex", alignItems: "center", justifyContent: "center" } },
  { id: "shipping", data: { label: "Shipping" }, position: { x: 250, y: 400 }, style: { background: "#F1F5F9", color: "#334155", borderRadius: "50%", width: 38, height: 38, display: "flex", alignItems: "center", justifyContent: "center", border: "1px solid #475569" } },
  { id: "refund", data: { label: "Refund" }, position: { x: 200, y: 300 }, style: { background: "#FEF2F2", color: "#991B1B", border: "1px solid #DC2626", borderRadius: "50%", width: 36, height: 36, display: "flex", alignItems: "center", justifyContent: "center" } },
  
  // Tertiary
  { id: "pricing-1", data: { label: "Business Plan" }, position: { x: 650, y: 150 }, style: { background: "white", fontSize: 10, borderRadius: 16, padding: "4px 8px" } },
  { id: "pricing-2", data: { label: "Enterprise" }, position: { x: 650, y: 100 }, style: { background: "white", fontSize: 10, borderRadius: 16, padding: "4px 8px" } },
  { id: "pricing-3", data: { label: "Starter" }, position: { x: 550, y: 100 }, style: { background: "white", fontSize: 10, borderRadius: 16, padding: "4px 8px" } },
]

const initialEdges: Edge[] = [
  { id: "e-center-products", source: "center", target: "products", label: "has", style: { stroke: "#E2E8F0" }, labelStyle: { fill: "#64748B", fontSize: 10, fontWeight: 500 }, labelBgStyle: { fill: "white" } },
  { id: "e-center-pricing", source: "center", target: "pricing", label: "has pricing", style: { stroke: "#E2E8F0" }, labelStyle: { fill: "#64748B", fontSize: 10, fontWeight: 500 }, labelBgStyle: { fill: "white" } },
  { id: "e-center-policies", source: "center", target: "policies", label: "covers", style: { stroke: "#E2E8F0" }, labelStyle: { fill: "#64748B", fontSize: 10, fontWeight: 500 }, labelBgStyle: { fill: "white" } },
  { id: "e-center-faq", source: "center", target: "faq", label: "answers", style: { stroke: "#E2E8F0" }, labelStyle: { fill: "#64748B", fontSize: 10, fontWeight: 500 }, labelBgStyle: { fill: "white" } },
  { id: "e-center-integrations", source: "center", target: "integrations", label: "connects to", style: { stroke: "#E2E8F0" }, labelStyle: { fill: "#64748B", fontSize: 10, fontWeight: 500 }, labelBgStyle: { fill: "white" } },
  { id: "e-center-shipping", source: "center", target: "shipping", label: "includes", style: { stroke: "#E2E8F0" }, labelStyle: { fill: "#64748B", fontSize: 10, fontWeight: 500 }, labelBgStyle: { fill: "white" } },
  { id: "e-center-refund", source: "center", target: "refund", style: { stroke: "#E2E8F0" } },
  
  { id: "e-pricing-1", source: "pricing", target: "pricing-1", style: { stroke: "#E2E8F0" } },
  { id: "e-pricing-2", source: "pricing", target: "pricing-2", style: { stroke: "#E2E8F0" } },
  { id: "e-pricing-3", source: "pricing", target: "pricing-3", style: { stroke: "#E2E8F0" } },
]

export default function KnowledgeHubPage() {
  const [nodes, setNodes] = useState<Node[]>(initialNodes)
  const [edges, setEdges] = useState<Edge[]>(initialEdges)
  const [query, setQuery] = useState("What is the price for 100 users?")
  const [isTesting, setIsTesting] = useState(false)
  const [showResponse, setShowResponse] = useState(false)

  const handleTest = () => {
    setIsTesting(true)
    setShowResponse(false)
    setTimeout(() => {
      setIsTesting(false)
      setShowResponse(true)
    }, 1500)
  }

  return (
    <div className="flex flex-col h-full flex-1  bg-white relative">
      
      {/* Header */}
      <div className="flex-shrink-0 p-6 border-b border-border flex items-center justify-between z-10 bg-white">
        <div>
          <h1 className="text-2xl font-bold text-foreground mb-1">Knowledge Hub</h1>
          <p className="text-[14px] text-muted-foreground">
            Your AI chatbot and voice agent use this knowledge graph to answer questions accurately.
          </p>
          <div className="flex items-center gap-1.5 mt-2">
            <CheckCircle2 className="h-4 w-4 text-green-500" />
            <span className="text-[13px] text-green-600">All sources synced</span>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          <span className="text-[13px] text-muted-foreground">Last synced: 2 min ago</span>
          <button className="flex items-center gap-2 px-4 py-2 border border-border rounded-lg text-[14px] font-medium text-foreground hover:bg-muted transition-colors">
            <RefreshCw className="h-4 w-4" /> Resync All
          </button>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        
        {/* Left Panel: Sources */}
        <div className="w-[280px] bg-white border-r border-border p-4 flex flex-col shrink-0 overflow-y-auto">
          <h2 className="text-[14px] font-bold text-foreground mb-4">Data Sources</h2>
          <button className="w-full bg-primary hover:bg-primary/90 text-white font-bold text-[14px] py-2 rounded-lg transition-colors flex items-center justify-center gap-2 mb-6 shadow-sm">
            <Plus className="h-4 w-4" /> Add Source
          </button>

          <div className="space-y-4 flex-1">
            {sources.map(source => (
              <div key={source.id} className="group border border-border rounded-lg p-3 hover:border-primary transition-colors">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <source.icon className={cn("h-4 w-4", source.iconColor)} />
                    <div>
                      <p className="text-[13px] font-medium text-foreground truncate max-w-[150px]">{source.name}</p>
                      <p className="text-[11px] text-muted-foreground">{source.type} · {source.meta}</p>
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-1">
                    <div className={cn("w-2 h-2 rounded-full", source.statusDot)} />
                  </div>
                </div>
                {source.progress && (
                  <div className="w-full bg-muted h-1.5 rounded-full overflow-hidden">
                    <div className="bg-blue-400 h-full" style={{ width: `${source.progress}%` }} />
                  </div>
                )}
                {source.statusLabel && (
                  <p className="text-[11px] text-amber-500 mt-1">{source.statusLabel}</p>
                )}
              </div>
            ))}
          </div>

          <div className="pt-4 border-t border-border mt-4">
            <p className="text-[12px] text-muted-foreground">Total: 464 knowledge chunks</p>
            <p className="text-[12px] text-muted-foreground">1,284 graph nodes</p>
          </div>
        </div>

        {/* Center Panel: Graph RAG */}
        <div className="flex-1 bg-muted/30 relative">
          <ReactFlow 
            nodes={nodes} 
            edges={edges}
            fitView
            attributionPosition="bottom-right"
          >
            <Background color="#E2E8F0" gap={16} />
            <Controls className="!bg-white !border-border !rounded-lg !shadow-sm" />
          </ReactFlow>
          
          <div className="absolute top-4 right-4 flex items-center gap-2">
            <div className="relative">
              <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input type="text" placeholder="Search nodes..." className="pl-9 pr-4 py-2 text-[13px] border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary bg-white/90 backdrop-blur" />
            </div>
          </div>
        </div>

        {/* Right Panel: Query Testing */}
        <div className="w-[320px] bg-white border-l border-border p-4 flex flex-col shrink-0">
          <h2 className="text-[14px] font-bold text-foreground mb-4">Test Knowledge Query</h2>
          
          <div className="mb-6">
            <textarea
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Ask a question as your customer would..."
              className="w-full bg-muted border-none rounded-lg p-3 text-[13px] resize-none focus:ring-1 focus:ring-primary mb-3"
              rows={3}
            />
            <button 
              onClick={handleTest}
              disabled={isTesting || !query.trim()}
              className="w-full bg-primary/10 hover:bg-primary/10/80 text-primary font-bold text-[13px] py-2 rounded-lg transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {isTesting ? "Querying Graph..." : <><Send className="h-4 w-4" /> Test Query</>}
            </button>
          </div>

          {showResponse && (
            <div className="flex-1 flex flex-col animate-in fade-in slide-in-from-bottom-2 duration-300">
              <p className="text-[12px] text-muted-foreground mb-2 font-medium">AI Response</p>
              
              <div className="bg-primary/10 border border-primary/20 rounded-[10px] p-[14px] mb-4">
                <p className="text-[13px] text-primary-foreground leading-relaxed">
                  For 100 users, we recommend our <span className="font-bold">Business Plan</span> at $149/month (billed annually). This includes Shared Inbox, AI Chatbot, Workflow Builder, Voice Agent, and Analytics. For enterprise pricing, please contact our team.
                </p>
              </div>

              <div className="mb-4">
                <p className="text-[12px] text-muted-foreground mb-2 font-medium">Sources used:</p>
                <div className="flex flex-wrap gap-2">
                  <div className="flex items-center gap-1.5 bg-white border border-border px-2 py-1 rounded text-[11px] font-medium text-muted-foreground shadow-sm">
                    <FileSpreadsheet className="h-3 w-3 text-green-600" /> pricing_2026.xlsx
                  </div>
                  <div className="flex items-center gap-1.5 bg-white border border-border px-2 py-1 rounded text-[11px] font-medium text-muted-foreground shadow-sm">
                    <FileText className="h-3 w-3 text-amber-500" /> FAQ.pdf
                  </div>
                </div>
              </div>

              <div>
                <p className="text-[12px] text-green-600 mb-1 font-medium">Confidence: 94%</p>
                <div className="w-full bg-green-50 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-green-500 h-full" style={{ width: '94%' }} />
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
