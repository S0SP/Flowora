"use client"

import React, { useState, useRef, useEffect } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { z } from "zod"
import { BookOpen, Sliders, GitBranch, Radio, FlaskConical, BarChart3, Globe, FileText, FileSpreadsheet, Plus, MessageSquare, Mic, ArrowRight } from "lucide-react"
import { cn } from "@/lib/utils"
import { toast } from "sonner"

const navItems = [
  { icon: BookOpen, label: "Knowledge", active: false },
  { icon: Sliders, label: "Behavior", active: true },
  { icon: GitBranch, label: "Escalation", active: false },
  { icon: Radio, label: "Channels", active: false },
  { icon: FlaskConical, label: "Testing", active: false },
  { icon: BarChart3, label: "Analytics", active: false },
]

const behaviorSchema = z.object({
  botName: z.string().min(2, "Bot name must be at least 2 characters"),
  persona: z.string().min(10, "Persona must be at least 10 characters"),
  language: z.string(),
  responseLength: z.number().min(0).max(100),
  fallback: z.string().min(5, "Fallback message required")
})

type BehaviorFormValues = z.infer<typeof behaviorSchema>

type TestMessage = {
  id: string
  text: string
  sender: "user" | "ai"
}

export default function ChatbotPage() {
  const [activeTab, setActiveTab] = useState("Behavior")
  
  // Form setup
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<BehaviorFormValues>({
    resolver: zodResolver(behaviorSchema),
    defaultValues: {
      botName: "Aria from Acme Corp",
      persona: "You are Aria, a friendly and professional AI assistant for Acme Corp. You help customers with product inquiries, pricing, demos, and support. Always be concise, warm, and solution-focused.",
      language: "English (auto-detect others)",
      responseLength: 65,
      fallback: "I'm sorry, I can't help with that right now. Let me connect you with a human agent."
    }
  })

  const onSave = async (data: BehaviorFormValues) => {
    // simulate save
    await new Promise(r => setTimeout(r, 500))
    toast.success("Bot settings saved successfully!")
    console.log(data)
  }

  // Test chat setup
  const [testMessages, setTestMessages] = useState<TestMessage[]>([
    { id: "1", text: "Hello, what are your pricing plans?", sender: "user" },
    { id: "2", text: "Hi there! 👋 We offer 3 plans:\n\n🌱 Starter — $49/mo\n💼 Business — $149/mo\n🏢 Enterprise — Custom\n\nWould you like to schedule a demo?", sender: "ai" }
  ])
  const [testInput, setTestInput] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const chatScrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight
    }
  }, [testMessages, isTyping])

  const handleTestSend = () => {
    if (!testInput.trim()) return
    const newMsg: TestMessage = { id: Date.now().toString(), text: testInput, sender: "user" }
    setTestMessages(prev => [...prev, newMsg])
    setTestInput("")
    setIsTyping(true)
    
    // simulate AI reply
    setTimeout(() => {
      setIsTyping(false)
      setTestMessages(prev => [...prev, {
        id: (Date.now()+1).toString(),
        text: "This is a simulated response based on your current knowledge and behavior settings.",
        sender: "ai"
      }])
    }, 1500)
  }

  return (
    <div className="flex flex-col h-full flex-1  bg-white relative">
      
      {/* Header Area */}
      <div className="flex-shrink-0 p-6 border-b border-border flex items-center justify-between">
        <div>
          <div className="flex items-center gap-3 mb-1">
            <h1 className="text-2xl font-bold text-foreground">AI Chatbot</h1>
            <div className="flex items-center gap-1.5 bg-[#F0FDF4] border border-[#BBF7D0] px-2 py-0.5 rounded-full">
              <div className="w-2 h-2 rounded-full bg-[#22C55E]" />
              <span className="text-[12px] font-medium text-[#22C55E]">Active</span>
            </div>
          </div>
          <p className="text-[14px] text-muted-foreground">
            Configure your WhatsApp AI assistant. Powered by Flowora AI — no technical setup required.
          </p>
        </div>
        <button 
          onClick={handleSubmit(onSave)}
          disabled={isSubmitting}
          className="px-5 py-2.5 text-[14px] font-bold text-foreground bg-primary hover:bg-primary/90 shadow-sm rounded-lg transition-colors disabled:opacity-50"
        >
          {isSubmitting ? "Saving..." : "Save Changes"}
        </button>
      </div>

      <div className="flex flex-1 overflow-hidden">
        
        {/* Left Navigation */}
        <div className="w-[200px] border-r border-border p-4 flex flex-col gap-1 shrink-0">
          {navItems.map((item) => (
            <button
              key={item.label}
              onClick={() => setActiveTab(item.label)}
              className={cn(
                "flex items-center gap-2.5 px-3 py-2 rounded-lg text-[14px] font-medium transition-colors w-full",
                activeTab === item.label
                  ? "bg-primary/10 text-foreground"
                  : "text-muted-foreground hover:bg-muted hover:text-foreground"
              )}
            >
              <item.icon className={cn("h-4 w-4", activeTab === item.label ? "text-[#F59E0B]" : "text-muted-foreground")} />
              {item.label}
            </button>
          ))}
        </div>

        {/* Center Content Area */}
        <div className="flex-1 overflow-y-auto p-8 bg-white">
          <form className="max-w-2xl space-y-12" onSubmit={e => e.preventDefault()}>
            
            {/* Knowledge Sources Section */}
            <section className={cn(activeTab !== "Knowledge" && activeTab !== "Behavior" ? "hidden" : "block")}>
              <div className="mb-4">
                <h2 className="text-[18px] font-bold text-foreground mb-1">Knowledge Sources</h2>
                <p className="text-[13px] text-muted-foreground">
                  These sources train your AI chatbot. The AI uses Graph RAG to answer questions accurately from your company data.
                </p>
              </div>
              
              <div className="space-y-3 mb-4">
                {/* Source 1 */}
                <div className="border border-border rounded-lg p-3 flex items-center justify-between hover:border-[#C4B1F9] transition-colors group">
                  <div className="flex items-center gap-3">
                    <Globe className="h-5 w-5 text-[#3B82F6]" />
                    <div>
                      <p className="text-[14px] font-medium text-foreground">Website</p>
                      <p className="text-[12px] text-muted-foreground">https://acme.com</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-1.5">
                      <div className="w-1.5 h-1.5 rounded-full bg-[#22C55E]" />
                      <span className="text-[12px] text-[#22C55E] font-medium">Synced</span>
                    </div>
                    <span className="text-[12px] text-muted-foreground">2 min ago</span>
                    <div className="hidden group-hover:flex items-center gap-2">
                      <button type="button" className="text-[12px] font-medium text-primary hover:underline">Edit</button>
                      <button type="button" className="text-[12px] font-medium text-primary hover:underline">Resync</button>
                      <button type="button" className="text-[12px] font-medium text-destructive hover:underline">Delete</button>
                    </div>
                  </div>
                </div>

                {/* Source 2 */}
                <div className="border border-border rounded-lg p-3 flex items-center justify-between hover:border-[#C4B1F9] transition-colors">
                  <div className="flex items-center gap-3">
                    <FileSpreadsheet className="h-5 w-5 text-[#22C55E]" />
                    <div>
                      <p className="text-[14px] font-medium text-foreground">Product Data</p>
                      <p className="text-[12px] text-muted-foreground">Google Drive — product_catalog.xlsx</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[12px] text-[#22C55E] font-medium">Synced</span>
                  </div>
                </div>

                {/* Source 3 */}
                <div className="border border-border rounded-lg p-3 flex items-center justify-between hover:border-[#C4B1F9] transition-colors">
                  <div className="flex items-center gap-3">
                    <FileText className="h-5 w-5 text-[#F59E0B]" />
                    <div>
                      <p className="text-[14px] font-medium text-foreground">FAQ.pdf</p>
                      <p className="text-[12px] text-muted-foreground">Documents — 2.4 MB</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[12px] text-[#22C55E] font-medium">Synced</span>
                  </div>
                </div>
              </div>

              <button type="button" className="w-full border-2 border-dashed border-border rounded-lg py-3.5 flex items-center justify-center gap-2 text-[14px] text-muted-foreground hover:bg-muted hover:text-foreground transition-colors mb-3">
                <Plus className="h-4 w-4" /> Add Source
              </button>
              <p className="text-[12px] text-muted-foreground text-center">
                Supported: Website URL · PDF · DOCX · Google Sheet · Google Drive · CSV · Notion
              </p>
            </section>

            {activeTab === "Behavior" && <div className="w-full h-px bg-[#E8E8E4]" />}

            {/* Behavior Section */}
            <section className={cn(activeTab !== "Behavior" ? "hidden" : "block")}>
              <h2 className="text-[18px] font-bold text-foreground mb-4">Chatbot Behavior</h2>
              
              <div className="space-y-5">
                <div>
                  <label className="block text-[13px] font-medium text-foreground mb-1.5">Bot Name (shown to customers)</label>
                  <input 
                    type="text" 
                    {...register("botName")}
                    className={cn("w-full border rounded-md px-3 py-2 text-[13px] focus:ring-1 focus:ring-primary focus:border-primary", errors.botName ? "border-destructive" : "border-border")}
                  />
                  {errors.botName && <p className="text-destructive text-xs mt-1">{errors.botName.message}</p>}
                </div>
                
                <div>
                  <label className="block text-[13px] font-medium text-foreground mb-1.5">Bot Persona / Tone</label>
                  <textarea 
                    rows={4}
                    {...register("persona")}
                    className={cn("w-full border rounded-md px-3 py-2 text-[13px] focus:ring-1 focus:ring-primary focus:border-primary", errors.persona ? "border-destructive" : "border-border")}
                  />
                  {errors.persona && <p className="text-destructive text-xs mt-1">{errors.persona.message}</p>}
                </div>

                <div>
                  <label className="block text-[13px] font-medium text-foreground mb-1.5">Language</label>
                  <select 
                    {...register("language")}
                    className="w-full border border-border rounded-md px-3 py-2 text-[13px] focus:ring-1 focus:ring-primary focus:border-primary bg-white"
                  >
                    <option>English (auto-detect others)</option>
                    <option>Spanish (auto-detect others)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[13px] font-medium text-foreground mb-1.5">Response Length</label>
                  <div className="flex items-center gap-4">
                    <span className="text-[12px] text-muted-foreground">Concise</span>
                    <input type="range" {...register("responseLength", { valueAsNumber: true })} className="flex-1 accent-primary" />
                    <span className="text-[12px] text-muted-foreground">Detailed</span>
                  </div>
                </div>
                
                <div>
                  <label className="block text-[13px] font-medium text-foreground mb-1.5">Out-of-Scope Fallback</label>
                  <textarea 
                    rows={2}
                    {...register("fallback")}
                    className={cn("w-full border rounded-md px-3 py-2 text-[13px] focus:ring-1 focus:ring-primary focus:border-primary", errors.fallback ? "border-destructive" : "border-border")}
                  />
                  {errors.fallback && <p className="text-destructive text-xs mt-1">{errors.fallback.message}</p>}
                </div>
              </div>
            </section>

            {activeTab === "Channels" && <div className="w-full h-px bg-[#E8E8E4]" />}

            {/* Channels Section */}
            <section className={cn(activeTab !== "Channels" && activeTab !== "Behavior" ? "hidden" : "block")}>
              <h2 className="text-[18px] font-bold text-foreground mb-4">Active Channels</h2>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="border border-border rounded-lg p-4 flex items-center justify-between bg-muted/30">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-[#F0FDF4] flex items-center justify-center">
                      <MessageSquare className="h-5 w-5 text-[#22C55E]" />
                    </div>
                    <div>
                      <p className="text-[14px] font-bold text-foreground">WhatsApp Business</p>
                      <p className="text-[12px] text-muted-foreground">+1 415 555 0100</p>
                    </div>
                  </div>
                  <div className="bg-[#22C55E] w-10 h-6 rounded-full flex items-center p-1 cursor-pointer">
                    <div className="bg-white w-4 h-4 rounded-full ml-auto shadow-sm" />
                  </div>
                </div>

                <div className="border border-border rounded-lg p-4 flex items-center justify-between bg-muted/30">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center">
                      <MessageSquare className="h-5 w-5 text-foreground" />
                    </div>
                    <div>
                      <p className="text-[14px] font-bold text-foreground">Web Widget</p>
                      <p className="text-[12px] text-muted-foreground">acme.com</p>
                    </div>
                  </div>
                  <div className="bg-[#22C55E] w-10 h-6 rounded-full flex items-center p-1 cursor-pointer">
                    <div className="bg-white w-4 h-4 rounded-full ml-auto shadow-sm" />
                  </div>
                </div>
              </div>
            </section>
            
          </form>
        </div>

        {/* Right Live Test Panel */}
        <div className="w-[320px] bg-white border-l border-border flex flex-col shrink-0">
          <div className="p-4 border-b border-border">
            <h3 className="text-[14px] font-bold text-foreground">Test Chat</h3>
          </div>
          
          <div className="flex-1 bg-muted/50 flex flex-col">
            {/* Chat Header */}
            <div className="bg-white p-3 border-b border-border flex items-center gap-2 shadow-sm">
              <div className="w-8 h-8 rounded-full bg-[#C4B1F9] flex items-center justify-center text-white">
                <MessageSquare className="h-4 w-4" />
              </div>
              <div>
                <p className="text-[13px] font-bold text-foreground">Aria — Acme Corp</p>
                <p className="text-[11px] text-muted-foreground">AI Bot · Online</p>
              </div>
            </div>
            
            {/* Chat Messages Area */}
            <div 
              ref={chatScrollRef}
              className="flex-1 p-4 overflow-y-auto flex flex-col gap-3 scroll-smooth" 
              style={{ backgroundImage: "url('https://w0.peakpx.com/wallpaper/818/148/HD-wallpaper-whatsapp-background-cool-dark-green-new-theme-whatsapp.jpg')", backgroundSize: "cover", backgroundBlendMode: "overlay" }}
            >
              {testMessages.map(msg => (
                <div key={msg.id} className={cn(
                  "p-2.5 rounded-lg shadow-sm max-w-[85%] relative",
                  msg.sender === "user" ? "self-end bg-green-100 rounded-tr-none" : "self-start bg-white rounded-tl-none"
                )}>
                  {msg.sender === "ai" && (
                    <div className="absolute -top-2 -left-2 bg-[#C4B1F9] text-white text-[9px] font-bold px-1.5 py-0.5 rounded shadow-sm">AI</div>
                  )}
                  <p className="text-[13px] text-foreground whitespace-pre-wrap">{msg.text}</p>
                </div>
              ))}
              
              {/* Typing indicator */}
              {isTyping && (
                <div className="self-start bg-white px-3 py-2 rounded-lg rounded-tl-none shadow-sm max-w-[85%] flex gap-1 mt-1">
                  <div className="w-1.5 h-1.5 bg-[#9B9B9B] rounded-full animate-bounce" />
                  <div className="w-1.5 h-1.5 bg-[#9B9B9B] rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                  <div className="w-1.5 h-1.5 bg-[#9B9B9B] rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
                </div>
              )}
            </div>
            
            {/* Composer */}
            <div className="bg-[#F0F0F0] p-2 flex items-center gap-2 border-t border-border">
              <input 
                type="text" 
                value={testInput}
                onChange={e => setTestInput(e.target.value)}
                onKeyDown={e => e.key === "Enter" && handleTestSend()}
                placeholder="Type a test message..." 
                className="bg-white rounded-full flex-1 h-9 px-4 text-[13px] outline-none"
              />
              <button onClick={handleTestSend} className="w-9 h-9 bg-primary rounded-full flex items-center justify-center shrink-0 hover:bg-primary/90 shadow-sm transition-colors">
                <ArrowRight className="h-4 w-4 text-foreground" />
              </button>
            </div>
            
          </div>
        </div>
      </div>
    </div>
  )
}
