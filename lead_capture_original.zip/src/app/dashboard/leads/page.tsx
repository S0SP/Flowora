"use client"

import React, { useState } from "react"
import { Kanban, Table2, BarChart3, Upload, Plus, Filter, Settings2, X } from "lucide-react"
import { KanbanBoard } from "@/components/organisms/KanbanBoard"
import { mockDb, Lead } from "@/lib/api/mock-db"
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query"
import { toast } from "sonner"

export default function LeadsKanbanPage() {
  const queryClient = useQueryClient()
  const [isAddModalOpen, setIsAddModalOpen] = useState(false)
  const [isEditModalOpen, setIsEditModalOpen] = useState(false)
  const [editingLeadId, setEditingLeadId] = useState<string | null>(null)
  const [formData, setFormData] = useState<Partial<Lead>>({ name: "", company: "", value: "", status: "new" })

  const { data: leads = [] } = useQuery({
    queryKey: ["leads"],
    queryFn: () => mockDb.getLeads()
  })

  const addLeadMutation = useMutation({
    mutationFn: (newLead: Omit<Lead, "id">) => mockDb.addLead(newLead),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["leads"] })
      toast.success("Lead added successfully")
      setIsAddModalOpen(false)
    }
  })

  const editLeadMutation = useMutation({
    mutationFn: ({ id, updates }: { id: string, updates: Partial<Lead> }) => mockDb.updateLead(id, updates),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["leads"] })
      toast.success("Lead updated successfully")
      setIsEditModalOpen(false)
    }
  })

  const handleOpenAdd = () => {
    setFormData({ name: "", company: "", value: "", status: "new" })
    setIsAddModalOpen(true)
  }

  const handleOpenEdit = (id: string) => {
    const lead = leads.find(l => l.id === id)
    if (lead) {
      setFormData(lead)
      setEditingLeadId(id)
      setIsEditModalOpen(true)
    }
  }

  const handleSaveAdd = (e: React.FormEvent) => {
    e.preventDefault()
    if (!formData.name) return
    addLeadMutation.mutate(formData as Omit<Lead, "id">)
  }

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!editingLeadId) return
    editLeadMutation.mutate({ id: editingLeadId, updates: formData })
  }

  return (
    <div className=" h-full flex-1 flex flex-col bg-muted/30 overflow-hidden relative">
      {/* Header Area */}
      <div className="flex-shrink-0 p-6 border-b bg-background">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-6">
            <h1 className="text-2xl font-bold text-foreground">Leads CRM</h1>
            <div className="flex items-center bg-muted/50 p-1 rounded-lg">
              <button className="flex items-center gap-2 px-3 py-1.5 text-sm font-medium rounded-md bg-primary text-primary-foreground shadow-sm">
                <Kanban className="h-4 w-4" /> Kanban
              </button>
              <button className="flex items-center gap-2 px-3 py-1.5 text-sm font-medium rounded-md text-muted-foreground hover:text-foreground hover:bg-muted transition-colors">
                <Table2 className="h-4 w-4" /> Table
              </button>
              <button className="flex items-center gap-2 px-3 py-1.5 text-sm font-medium rounded-md text-muted-foreground hover:text-foreground hover:bg-muted transition-colors">
                <BarChart3 className="h-4 w-4" /> Analytics
              </button>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <button className="inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors border bg-card hover:bg-muted h-9 px-4 py-2 gap-2 text-muted-foreground shadow-sm">
              <Upload className="h-4 w-4" /> Import Leads
            </button>
            <button onClick={handleOpenAdd} className="inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors bg-primary text-foreground shadow hover:bg-primary/90 h-9 px-4 py-2 gap-2">
              <Plus className="h-4 w-4" /> Add Lead
            </button>
            <div className="w-px h-6 bg-border mx-1" />
            <button className="p-2 text-muted-foreground hover:text-foreground hover:bg-muted rounded-md transition-colors"><Filter className="h-4 w-4" /></button>
            <button className="p-2 text-muted-foreground hover:text-foreground hover:bg-muted rounded-md transition-colors"><Settings2 className="h-4 w-4" /></button>
          </div>
        </div>

        {/* Analytics Strip */}
        <div className="bg-card border rounded-lg p-3 shadow-subtle flex items-center justify-between overflow-x-auto hide-scrollbar gap-4">
          <div className="flex flex-col px-4 min-w-[120px]">
            <span className="text-xs text-muted-foreground font-medium mb-1">Total Leads</span>
            <span className="text-lg font-bold">{leads.length}</span>
          </div>
          <div className="w-px h-8 bg-border" />
          <div className="flex flex-col px-4 min-w-[120px]">
            <span className="text-xs text-muted-foreground font-medium mb-1">This Week</span>
            <span className="text-lg font-bold text-chart-4">+2</span>
          </div>
          <div className="w-px h-8 bg-border" />
          <div className="flex flex-col px-4 min-w-[120px]">
            <span className="text-xs text-muted-foreground font-medium mb-1">Conversion Rate</span>
            <span className="text-lg font-bold text-chart-4">18.4%</span>
          </div>
          <div className="w-px h-8 bg-border" />
          <div className="flex flex-col px-4 min-w-[120px]">
            <span className="text-xs text-muted-foreground font-medium mb-1">Avg Deal Value</span>
            <span className="text-lg font-bold">$2,400</span>
          </div>
          <div className="w-px h-8 bg-border" />
          <div className="flex flex-col px-4 min-w-[120px]">
            <span className="text-xs text-muted-foreground font-medium mb-1">Pipeline Value</span>
            <span className="text-lg font-bold text-lavender-foreground">$1.2M</span>
          </div>
        </div>
      </div>

      {/* Kanban Board */}
      <KanbanBoard onOpenAdd={handleOpenAdd} onEditLead={handleOpenEdit} />

      {/* Add Lead Modal */}
      {isAddModalOpen && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/30 backdrop-blur-sm">
          <div className="bg-white w-[400px] rounded-xl shadow-xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between p-4 border-b">
              <h2 className="text-lg font-bold">Add New Lead</h2>
              <button onClick={() => setIsAddModalOpen(false)} className="p-1 hover:bg-gray-100 rounded-full"><X className="h-5 w-5 text-gray-500" /></button>
            </div>
            <form onSubmit={handleSaveAdd} className="p-4 space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Name</label>
                <input required type="text" value={formData.name || ""} onChange={e => setFormData({ ...formData, name: e.target.value })} className="w-full border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20" placeholder="John Doe" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Company</label>
                <input type="text" value={formData.company || ""} onChange={e => setFormData({ ...formData, company: e.target.value })} className="w-full border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20" placeholder="Acme Corp" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Estimated Value</label>
                <input type="text" value={formData.value || ""} onChange={e => setFormData({ ...formData, value: e.target.value })} className="w-full border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20" placeholder="$5,000" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Status</label>
                <select value={formData.status || "new"} onChange={e => setFormData({ ...formData, status: e.target.value as Lead["status"] })} className="w-full border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 bg-white">
                  <option value="new">New Lead</option>
                  <option value="contacted">Contacted</option>
                  <option value="qualified">Qualified</option>
                  <option value="proposal">Proposal</option>
                  <option value="won">Won</option>
                  <option value="lost">Lost</option>
                </select>
              </div>
              <div className="pt-2 flex justify-end gap-2">
                <button type="button" onClick={() => setIsAddModalOpen(false)} className="px-4 py-2 border rounded-lg text-sm font-medium hover:bg-gray-50">Cancel</button>
                <button type="submit" disabled={addLeadMutation.isPending} className="px-4 py-2 bg-foreground text-white rounded-lg text-sm font-medium hover:bg-foreground/90">
                  {addLeadMutation.isPending ? "Saving..." : "Save Lead"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Lead Modal */}
      {isEditModalOpen && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/30 backdrop-blur-sm">
          <div className="bg-white w-[400px] rounded-xl shadow-xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between p-4 border-b">
              <h2 className="text-lg font-bold">Edit Lead</h2>
              <button onClick={() => setIsEditModalOpen(false)} className="p-1 hover:bg-gray-100 rounded-full"><X className="h-5 w-5 text-gray-500" /></button>
            </div>
            <form onSubmit={handleSaveEdit} className="p-4 space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Name</label>
                <input required type="text" value={formData.name || ""} onChange={e => setFormData({ ...formData, name: e.target.value })} className="w-full border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Company</label>
                <input type="text" value={formData.company || ""} onChange={e => setFormData({ ...formData, company: e.target.value })} className="w-full border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Estimated Value</label>
                <input type="text" value={formData.value || ""} onChange={e => setFormData({ ...formData, value: e.target.value })} className="w-full border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Status</label>
                <select value={formData.status || "new"} onChange={e => setFormData({ ...formData, status: e.target.value as Lead["status"] })} className="w-full border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 bg-white">
                  <option value="new">New Lead</option>
                  <option value="contacted">Contacted</option>
                  <option value="qualified">Qualified</option>
                  <option value="proposal">Proposal</option>
                  <option value="won">Won</option>
                  <option value="lost">Lost</option>
                </select>
              </div>
              <div className="pt-2 flex justify-end gap-2">
                <button type="button" onClick={() => setIsEditModalOpen(false)} className="px-4 py-2 border rounded-lg text-sm font-medium hover:bg-gray-50">Cancel</button>
                <button type="submit" disabled={editLeadMutation.isPending} className="px-4 py-2 bg-foreground text-white rounded-lg text-sm font-medium hover:bg-foreground/90">
                  {editLeadMutation.isPending ? "Saving..." : "Update Lead"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
