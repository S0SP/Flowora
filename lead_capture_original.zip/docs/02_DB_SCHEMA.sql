-- ============================================================================
-- FLOWORA — COMPLETE DATABASE SCHEMA (Supabase / Postgres)
-- Multi-tenant AI Communication OS: WhatsApp · Email · Voice
-- ----------------------------------------------------------------------------
-- Design rules:
--   * Every domain row carries workspace_id (the tenant) and is RLS-guarded.
--   * auth.users is Supabase-managed; profiles mirrors it 1:1.
--   * Service role (webhooks/cron/voice worker) bypasses RLS and MUST scope by
--     workspace_id explicitly.
--   * Money/credits are append-only ledgers with a materialized balance.
--   * This file supersedes database/schema.sql. Apply as ordered migrations.
-- ============================================================================
-- Clean reset: drop public schema and recreate it
drop schema if exists public cascade;
create schema public;

-- Re-establish default Supabase roles and permissions
grant all on schema public to postgres, service_role;
grant usage on schema public to anon, authenticated;

alter default privileges in schema public grant all on tables to postgres, service_role;
alter default privileges in schema public grant all on functions to postgres, service_role;
alter default privileges in schema public grant all on sequences to postgres, service_role;

alter default privileges in schema public grant select, insert, update, delete on tables to authenticated;
alter default privileges in schema public grant select on tables to anon;

create extension if not exists "uuid-ossp";
create extension if not exists "pg_trgm";
create extension if not exists "vector";        -- pgvector for RAG
create extension if not exists "pgcrypto";      -- secret encryption + gen_random_uuid

-- ============================================================================
-- 1. IDENTITY & TENANCY
-- ============================================================================

-- 1.1 Profile: public mirror of auth.users (created by trigger on signup)
create table profiles (
  id            uuid primary key references auth.users(id) on delete cascade,
  email         text not null,
  full_name     text,
  avatar_url    text,
  phone         text,
  timezone      text default 'Asia/Kolkata',
  locale        text default 'en',
  onboarding_completed boolean not null default false,
  last_seen_at  timestamptz,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

-- 1.2 Workspace = the tenant
create table workspaces (
  id            uuid primary key default gen_random_uuid(),
  name          text not null,
  slug          text unique not null,
  logo_url      text,
  industry      text,
  timezone      text default 'Asia/Kolkata',
  owner_id      uuid not null references profiles(id),
  onboarding_completed boolean not null default false,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

-- 1.3 Membership + role + granular permissions + per-agent credit cap
create type member_role as enum ('owner','admin','manager','agent');
create type member_status as enum ('active','invited','suspended');

create table workspace_members (
  id            uuid primary key default gen_random_uuid(),
  workspace_id  uuid not null references workspaces(id) on delete cascade,
  user_id       uuid not null references profiles(id) on delete cascade,
  role          member_role not null default 'agent',
  status        member_status not null default 'active',
  -- permission matrix (screen 11): {"inbox":{"read":true,"write":true}, "billing":{"read":false}, ...}
  permissions   jsonb not null default '{}'::jsonb,
  credit_limit  integer,                       -- null = unlimited, else monthly cap
  credits_used  integer not null default 0,    -- rolling monthly usage
  created_at    timestamptz not null default now(),
  unique (workspace_id, user_id)
);
create index on workspace_members (workspace_id);
create index on workspace_members (user_id);

-- 1.4 Invitations (email invite → accept → member)
create table invitations (
  id            uuid primary key default gen_random_uuid(),
  workspace_id  uuid not null references workspaces(id) on delete cascade,
  email         text not null,
  role          member_role not null default 'agent',
  permissions   jsonb not null default '{}'::jsonb,
  credit_limit  integer,
  token         text unique not null default encode(gen_random_bytes(24),'hex'),
  invited_by    uuid references profiles(id),
  accepted_at   timestamptz,
  expires_at    timestamptz not null default (now() + interval '7 days'),
  created_at    timestamptz not null default now(),
  unique (workspace_id, email)
);
create index on invitations (token);

-- 1.5 Per-workspace settings (branding, business hours, defaults)
create table workspace_settings (
  workspace_id  uuid primary key references workspaces(id) on delete cascade,
  business_hours    jsonb default '{}'::jsonb,
  default_language  text default 'en',
  auto_assign       boolean default true,
  notification_prefs jsonb default '{}'::jsonb,
  updated_at    timestamptz not null default now()
);

-- ============================================================================
-- 2. CHANNELS & CREDENTIALS  (was: global chatbot_settings singleton)
-- ============================================================================
-- Encrypted BYOK creds per workspace. Secrets stored with pgcrypto; never
-- selected raw by anon/authenticated clients (use masked views / API).

create type channel_type as enum ('whatsapp','email','voice','sms');

create table channel_connections (
  id            uuid primary key default gen_random_uuid(),
  workspace_id  uuid not null references workspaces(id) on delete cascade,
  type          channel_type not null,
  label         text,
  is_active     boolean not null default true,
  -- non-secret config (phone number id, waba id, from-email, smtp host/port...)
  config        jsonb not null default '{}'::jsonb,
  -- secret blob, encrypted (access tokens, smtp password, api keys)
  secrets_enc   bytea,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index on channel_connections (workspace_id, type);

-- ============================================================================
-- 3. CONTACTS / CRM
-- ============================================================================

create type contact_status as enum ('active','inactive','blocked');

create table contacts (
  id            uuid primary key default gen_random_uuid(),
  workspace_id  uuid not null references workspaces(id) on delete cascade,
  phone         text,
  name          text,
  email         text,
  company       text,
  avatar_url    text,
  status        contact_status not null default 'active',
  owner_id      uuid references profiles(id),      -- assigned agent
  lead_score    integer default 0,
  tags          text[] default '{}',
  custom_fields jsonb default '{}'::jsonb,
  source        text,                              -- 'sheet','csv','inbound','manual','api'
  message_count integer not null default 0,
  last_message_at timestamptz,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (workspace_id, phone)
);
create index on contacts (workspace_id, last_message_at desc nulls last);
create index on contacts (workspace_id, owner_id);
create index on contacts using gin (name gin_trgm_ops);
create index on contacts using gin (tags);

-- 3.1 Sales pipeline (kanban — screen 04)
create table pipelines (
  id            uuid primary key default gen_random_uuid(),
  workspace_id  uuid not null references workspaces(id) on delete cascade,
  name          text not null,
  is_default    boolean default false,
  created_at    timestamptz not null default now()
);

create table pipeline_stages (
  id            uuid primary key default gen_random_uuid(),
  workspace_id  uuid not null references workspaces(id) on delete cascade,
  pipeline_id   uuid not null references pipelines(id) on delete cascade,
  name          text not null,
  color         text default '#C4B1F9',
  position      integer not null default 0
);
create index on pipeline_stages (pipeline_id, position);

create table leads (
  id            uuid primary key default gen_random_uuid(),
  workspace_id  uuid not null references workspaces(id) on delete cascade,
  contact_id    uuid not null references contacts(id) on delete cascade,
  pipeline_id   uuid not null references pipelines(id) on delete cascade,
  stage_id      uuid not null references pipeline_stages(id),
  owner_id      uuid references profiles(id),
  value         numeric(12,2) default 0,
  position      integer not null default 0,        -- order within stage column
  status        text default 'open',               -- open/won/lost
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index on leads (workspace_id, stage_id, position);
create index on leads (workspace_id, contact_id);

-- 3.2 Activity timeline (events on a contact/lead — screen 02 "Events")
create table activities (
  id            uuid primary key default gen_random_uuid(),
  workspace_id  uuid not null references workspaces(id) on delete cascade,
  contact_id    uuid references contacts(id) on delete cascade,
  actor_id      uuid references profiles(id),
  type          text not null,   -- 'note','stage_change','message','call','workflow','click','tag'
  payload       jsonb default '{}'::jsonb,
  created_at    timestamptz not null default now()
);
create index on activities (workspace_id, contact_id, created_at desc);

-- ============================================================================
-- 4. SHARED INBOX (conversations + messages)
-- ============================================================================

create type conversation_state as enum ('open','pending','resolved','closed','bot');
create type msg_direction as enum ('inbound','outbound');
create type msg_status    as enum ('queued','sent','delivered','read','failed');
create type msg_sender    as enum ('contact','agent','ai','system');

-- 4.1 Conversation = a thread with one contact on one channel
create table conversations (
  id            uuid primary key default gen_random_uuid(),
  workspace_id  uuid not null references workspaces(id) on delete cascade,
  contact_id    uuid not null references contacts(id) on delete cascade,
  channel       channel_type not null default 'whatsapp',
  state         conversation_state not null default 'open',
  assigned_to   uuid references profiles(id),      -- current human agent
  is_bot_active boolean not null default true,     -- AI handling vs intervened
  human_requested boolean not null default false,
  tags          text[] default '{}',
  last_message_at timestamptz,
  last_message_preview text,
  unread_count  integer not null default 0,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (workspace_id, contact_id, channel)
);
create index on conversations (workspace_id, state, last_message_at desc);
create index on conversations (workspace_id, assigned_to);

-- 4.2 Messages (extends the existing table with tenancy + threading)
create table messages (
  id            uuid primary key default gen_random_uuid(),
  workspace_id  uuid not null references workspaces(id) on delete cascade,
  conversation_id uuid references conversations(id) on delete cascade,
  contact_id    uuid not null references contacts(id) on delete cascade,
  campaign_id   uuid,                              -- fk added after campaigns
  wamid         text,                              -- provider message id
  direction     msg_direction not null,
  sender        msg_sender not null default 'contact',
  sender_id     uuid references profiles(id),      -- agent who sent (if human)
  content       text,
  media_url     text,
  media_type    text,                              -- image/video/audio/document
  reply_to      uuid references messages(id),
  status        msg_status not null default 'sent',
  is_ai         boolean not null default false,
  meta          jsonb default '{}'::jsonb,         -- buttons, template vars, etc
  sent_at       timestamptz not null default now(),
  delivered_at  timestamptz,
  read_at       timestamptz,
  created_at    timestamptz not null default now(),
  unique (workspace_id, wamid)
);
create index on messages (workspace_id, conversation_id, sent_at desc);
create index on messages (workspace_id, contact_id, sent_at desc);
create index on messages (wamid);

-- 4.3 Internal notes on a conversation (@mentions — not sent to contact)
create table conversation_notes (
  id            uuid primary key default gen_random_uuid(),
  workspace_id  uuid not null references workspaces(id) on delete cascade,
  conversation_id uuid not null references conversations(id) on delete cascade,
  author_id     uuid not null references profiles(id),
  body          text not null,
  mentions      uuid[] default '{}',
  created_at    timestamptz not null default now()
);
create index on conversation_notes (conversation_id, created_at);

-- 4.4 Canned replies / quick replies (screen 02 "/ quick replies")
create table canned_replies (
  id            uuid primary key default gen_random_uuid(),
  workspace_id  uuid not null references workspaces(id) on delete cascade,
  shortcut      text not null,
  title         text,
  body          text not null,
  created_by    uuid references profiles(id),
  created_at    timestamptz not null default now(),
  unique (workspace_id, shortcut)
);

-- ============================================================================
-- 5. CAMPAIGNS (broadcast)
-- ============================================================================

create type campaign_status as enum ('draft','scheduled','running','completed','failed','paused');

create table campaigns (
  id            uuid primary key default gen_random_uuid(),
  workspace_id  uuid not null references workspaces(id) on delete cascade,
  name          text not null,
  channel       channel_type not null default 'whatsapp',
  template_name text,
  template_language text default 'en',
  content       jsonb default '{}'::jsonb,         -- template vars / email html / subject
  audience      jsonb default '{}'::jsonb,         -- filter definition or contact list ref
  status        campaign_status not null default 'draft',
  total_contacts   integer not null default 0,
  sent_count       integer not null default 0,
  delivered_count  integer not null default 0,
  read_count       integer not null default 0,
  failed_count     integer not null default 0,
  click_count      integer not null default 0,
  estimated_credits integer default 0,
  created_by    uuid references profiles(id),
  scheduled_at  timestamptz,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  completed_at  timestamptz
);
create index on campaigns (workspace_id, status, created_at desc);

alter table messages
  add constraint messages_campaign_fk
  foreign key (campaign_id) references campaigns(id) on delete set null;

-- 5.1 Per-recipient queue/log (replaces campaign_logs; drives fan-out workers)
create type recipient_status as enum ('pending','sent','delivered','read','failed','skipped');

create table campaign_recipients (
  id            uuid primary key default gen_random_uuid(),
  workspace_id  uuid not null references workspaces(id) on delete cascade,
  campaign_id   uuid not null references campaigns(id) on delete cascade,
  contact_id    uuid not null references contacts(id) on delete cascade,
  wamid         text,
  status        recipient_status not null default 'pending',
  error_message text,
  sent_at       timestamptz,
  delivered_at  timestamptz,
  read_at       timestamptz,
  created_at    timestamptz not null default now()
);
create index on campaign_recipients (campaign_id, status);
create index on campaign_recipients (wamid);

-- ============================================================================
-- 6. WORKFLOWS (React-Flow builder → persisted + engine)
-- ============================================================================

create type workflow_status as enum ('draft','active','paused','archived');

create table workflows (
  id            uuid primary key default gen_random_uuid(),
  workspace_id  uuid not null references workspaces(id) on delete cascade,
  name          text not null,
  description   text,
  status        workflow_status not null default 'draft',
  trigger_type  text,                              -- 'sheet_new_row','inbound_msg','manual','schedule','webhook'
  trigger_config jsonb default '{}'::jsonb,
  -- React Flow graph: { nodes:[...], edges:[...] }
  graph         jsonb not null default '{"nodes":[],"edges":[]}'::jsonb,
  version       integer not null default 1,
  created_by    uuid references profiles(id),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index on workflows (workspace_id, status);

-- 6.1 A single execution of a workflow
create type run_status as enum ('running','completed','failed','cancelled','waiting');

create table workflow_runs (
  id            uuid primary key default gen_random_uuid(),
  workspace_id  uuid not null references workspaces(id) on delete cascade,
  workflow_id   uuid not null references workflows(id) on delete cascade,
  contact_id    uuid references contacts(id) on delete set null,
  status        run_status not null default 'running',
  context       jsonb default '{}'::jsonb,         -- variables passed between nodes
  current_node  text,
  wake_at       timestamptz,                       -- for delay nodes (QStash mirror)
  started_at    timestamptz not null default now(),
  finished_at   timestamptz
);
create index on workflow_runs (workspace_id, workflow_id, status);
create index on workflow_runs (status, wake_at);

-- 6.2 Step-by-step run log (screen 05 live logs)
create table workflow_run_steps (
  id            uuid primary key default gen_random_uuid(),
  workspace_id  uuid not null references workspaces(id) on delete cascade,
  run_id        uuid not null references workflow_runs(id) on delete cascade,
  node_id       text not null,
  node_type     text not null,
  status        text not null,                     -- 'ok','failed','skipped'
  input         jsonb,
  output        jsonb,
  credits_used  integer default 0,
  created_at    timestamptz not null default now()
);
create index on workflow_run_steps (workspace_id);
create index on workflow_run_steps (run_id, created_at);

-- 6.3 Template library (onboarding step 4)
create table workflow_templates (
  id            uuid primary key default gen_random_uuid(),
  name          text not null,
  description   text,
  category      text,
  graph         jsonb not null,
  is_public     boolean default true
);

-- ============================================================================
-- 7. AI CHATBOT (was: chatbot_settings singleton → per-workspace agents)
-- ============================================================================

create table chatbots (
  id            uuid primary key default gen_random_uuid(),
  workspace_id  uuid not null references workspaces(id) on delete cascade,
  name          text not null default 'Default Assistant',
  is_enabled    boolean not null default true,
  system_prompt text,
  model         text default 'gemini-2.5-flash',  -- fallback groq llama-3.3-70b
  temperature   numeric(3,2) default 0.7,
  max_tokens    integer default 1024,
  -- BYOK keys resolved from channel_connections/vault; ids kept here
  knowledge_base_id uuid,                          -- fk added after knowledge_bases
  -- tool flags (mirrors current is_lead_tool_enabled / is_store_tool_enabled)
  tools_config  jsonb default '{}'::jsonb,
  -- Gemini prompt cache handle (from gemini-cache.ts)
  prompt_cache_name text,
  prompt_cache_expires_at timestamptz,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index on chatbots (workspace_id);

-- 7.1 Prompt version history (existing chatbot_prompt_history)
create table chatbot_prompt_history (
  id            uuid primary key default gen_random_uuid(),
  workspace_id  uuid not null references workspaces(id) on delete cascade,
  chatbot_id    uuid not null references chatbots(id) on delete cascade,
  system_prompt text not null,
  created_by    uuid references profiles(id),
  created_at    timestamptz not null default now()
);
create index on chatbot_prompt_history (chatbot_id, created_at desc);

-- ============================================================================
-- 8. VOICE AGENT + VOICE CLONING  (Railway worker owns runtime; DB owns state)
-- ============================================================================

create type voice_agent_type as enum ('livekit','gemini','vapi');
create type call_status as enum ('queued','ringing','in-progress','completed','failed','no-answer','busy');
create type clone_status as enum ('processing','ready','failed');

-- 8.1 Cloned voices (new) — user-uploaded sample → provider voice id
create table cloned_voices (
  id            uuid primary key default gen_random_uuid(),
  workspace_id  uuid not null references workspaces(id) on delete cascade,
  name          text not null,
  status        clone_status not null default 'processing',
  provider      text default 'sarvam',             -- sarvam/elevenlabs/custom
  provider_voice_id text,                          -- set on completion
  sample_url    text,                              -- voice-samples bucket
  preview_url   text,
  created_by    uuid references profiles(id),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index on cloned_voices (workspace_id, status);

-- 8.2 Voice agent config (was: voice_agent_settings singleton)
create table voice_agents (
  id            uuid primary key default gen_random_uuid(),
  workspace_id  uuid not null references workspaces(id) on delete cascade,
  name          text not null default 'Default Voice Agent',
  is_enabled    boolean not null default true,
  agent_type    voice_agent_type not null default 'livekit',
  -- built-in voice id (lib/voices.ts) OR a cloned voice
  voice_id      text default 'anushka',
  cloned_voice_id uuid references cloned_voices(id) on delete set null,
  system_prompt text,
  knowledge_base_id uuid,                           -- fk after knowledge_bases
  first_message text,
  -- legacy passthrough for vapi path
  vapi_assistant_id text,
  config        jsonb default '{}'::jsonb,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index on voice_agents (workspace_id);

-- 8.3 Call records (extends existing voice_calls)
create table voice_calls (
  id            uuid primary key default gen_random_uuid(),
  workspace_id  uuid not null references workspaces(id) on delete cascade,
  voice_agent_id uuid references voice_agents(id) on delete set null,
  contact_id    uuid references contacts(id) on delete set null,
  user_id       uuid references profiles(id),      -- initiator (kept from current)
  to_number     text not null,
  from_number   text,
  direction     msg_direction not null default 'outbound',
  agent_type    voice_agent_type,
  voice_id      text,
  status        call_status not null default 'queued',
  duration_secs integer default 0,
  recording_url text,
  livekit_room_name  text,
  livekit_sip_call_id text,
  credits_used  integer default 0,
  outcome       text,                              -- 'converted','callback','not-interested'...
  error_message text,
  started_at    timestamptz,
  ended_at      timestamptz,
  created_at    timestamptz not null default now()
);
create index on voice_calls (workspace_id, created_at desc);
create index on voice_calls (status);

-- 8.4 Transcripts (existing /api/voice/transcript)
create table voice_transcripts (
  id            uuid primary key default gen_random_uuid(),
  workspace_id  uuid not null references workspaces(id) on delete cascade,
  call_id       uuid not null references voice_calls(id) on delete cascade,
  role          text not null,                     -- 'agent','user'
  text          text not null,
  ts_ms         integer,                           -- offset from call start
  created_at    timestamptz not null default now()
);
create index on voice_transcripts (call_id, ts_ms);

-- ============================================================================
-- 9. LEAD CAPTURE (Google Sheet → WhatsApp/Email/Voice — reuse, add tenancy)
-- ============================================================================

create table lead_capture_settings (
  id            uuid primary key default gen_random_uuid(),
  workspace_id  uuid not null references workspaces(id) on delete cascade,
  name          text,
  is_active     boolean not null default true,
  sheet_url     text not null,
  phone_column  text not null,
  name_column   text,
  email_column  text,
  delay_minutes integer not null default 0,
  -- channel toggles
  whatsapp_enabled boolean default true,
  template_name text,
  template_language text default 'en',
  email_enabled boolean default false,
  email_template_id text,
  email_subject text,
  email_brand_name text,
  email_logo_url text,
  email_title   text,
  email_body    text,
  email_button_text text,
  email_button_url text,
  email_footer  text,
  email_from    text,
  email_from_name text,
  -- smtp creds should move to channel_connections; kept nullable for migration
  smtp_host     text,
  smtp_port     integer,
  smtp_user     text,
  smtp_password text,
  voice_enabled boolean default false,
  voice_agent_type voice_agent_type default 'livekit',
  voice_id      text default 'anushka',
  voice_prompt  text,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index on lead_capture_settings (workspace_id, is_active);

create type lead_run_status as enum ('pending','processing','sent','failed');

create table lead_capture_leads (
  id            uuid primary key default gen_random_uuid(),
  workspace_id  uuid not null references workspaces(id) on delete cascade,
  lead_capture_settings_id uuid not null references lead_capture_settings(id) on delete cascade,
  phone         text not null,
  name          text,
  email         text,
  row_hash      text not null unique,              -- dedupe (kept from current)
  status        lead_run_status not null default 'pending',
  channel_status jsonb,                            -- per-channel breakdown (migration existed)
  scheduled_for timestamptz,
  processed_at  timestamptz,
  error_message text,
  created_at    timestamptz not null default now()
);
create index on lead_capture_leads (status, scheduled_for);
create index on lead_capture_leads (lead_capture_settings_id);

-- ============================================================================
-- 10. KNOWLEDGE HUB / GRAPH RAG (pgvector)
-- ============================================================================

create table knowledge_bases (
  id            uuid primary key default gen_random_uuid(),
  workspace_id  uuid not null references workspaces(id) on delete cascade,
  name          text not null,
  description   text,
  embedding_model text default 'text-embedding-004',
  created_at    timestamptz not null default now()
);
create index on knowledge_bases (workspace_id);

-- backfill fks that referenced knowledge_bases
alter table chatbots       add constraint chatbots_kb_fk       foreign key (knowledge_base_id) references knowledge_bases(id) on delete set null;
alter table voice_agents   add constraint voice_agents_kb_fk   foreign key (knowledge_base_id) references knowledge_bases(id) on delete set null;

create type kb_doc_status as enum ('pending','processing','ready','failed');

create table knowledge_documents (
  id            uuid primary key default gen_random_uuid(),
  workspace_id  uuid not null references workspaces(id) on delete cascade,
  knowledge_base_id uuid not null references knowledge_bases(id) on delete cascade,
  title         text,
  source_type   text not null,                     -- 'upload','url','sheet','site','text'
  source_url    text,
  storage_path  text,                              -- knowledge bucket
  status        kb_doc_status not null default 'pending',
  error_message text,
  created_at    timestamptz not null default now()
);
create index on knowledge_documents (knowledge_base_id, status);

create table knowledge_chunks (
  id            uuid primary key default gen_random_uuid(),
  workspace_id  uuid not null references workspaces(id) on delete cascade,
  knowledge_base_id uuid not null references knowledge_bases(id) on delete cascade,
  document_id   uuid not null references knowledge_documents(id) on delete cascade,
  content       text not null,
  embedding     vector(768),                       -- match embedding_model dim
  token_count   integer,
  created_at    timestamptz not null default now()
);
-- ANN index (tune lists/m for scale)
create index on knowledge_chunks using hnsw (embedding vector_cosine_ops);
create index on knowledge_chunks (knowledge_base_id);

-- 10.1 Graph RAG entities/relations (screen 09 visualization)
create table kg_nodes (
  id            uuid primary key default gen_random_uuid(),
  workspace_id  uuid not null references workspaces(id) on delete cascade,
  knowledge_base_id uuid not null references knowledge_bases(id) on delete cascade,
  label         text not null,
  type          text,                              -- entity type
  properties    jsonb default '{}'::jsonb
);
create index on kg_nodes (knowledge_base_id);

create table kg_edges (
  id            uuid primary key default gen_random_uuid(),
  workspace_id  uuid not null references workspaces(id) on delete cascade,
  knowledge_base_id uuid not null references knowledge_bases(id) on delete cascade,
  source_id     uuid not null references kg_nodes(id) on delete cascade,
  target_id     uuid not null references kg_nodes(id) on delete cascade,
  relation      text not null,
  weight        numeric default 1
);
create index on kg_edges (knowledge_base_id);

-- ============================================================================
-- 11. CREDITS & BILLING
-- ============================================================================

create table plans (
  id            text primary key,                  -- 'free','pro','business'
  name          text not null,
  monthly_credits integer not null default 0,
  price_cents   integer not null default 0,
  features      jsonb default '{}'::jsonb,
  stripe_price_id text
);

create type sub_status as enum ('trialing','active','past_due','canceled');

create table subscriptions (
  id            uuid primary key default gen_random_uuid(),
  workspace_id  uuid not null references workspaces(id) on delete cascade,
  plan_id       text not null references plans(id),
  status        sub_status not null default 'trialing',
  stripe_customer_id     text,
  stripe_subscription_id text,
  current_period_end     timestamptz,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (workspace_id)
);

-- 11.1 Wallet = materialized balance (fast read, cached in Redis)
create table credit_wallets (
  workspace_id  uuid primary key references workspaces(id) on delete cascade,
  balance       integer not null default 0,
  monthly_grant integer not null default 0,
  period_start  timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

-- 11.2 Ledger = append-only source of truth
create type ledger_reason as enum ('grant','debit','refund','topup','adjustment');

create table credit_ledger (
  id            uuid primary key default gen_random_uuid(),
  workspace_id  uuid not null references workspaces(id) on delete cascade,
  amount        integer not null,                  -- +grant/topup/refund, -debit
  reason        ledger_reason not null,
  feature       text,                              -- 'chatbot','voice','campaign','workflow'
  ref_type      text,                              -- 'voice_call','message','campaign','run'
  ref_id        uuid,
  member_id     uuid references workspace_members(id),
  balance_after integer,
  created_at    timestamptz not null default now()
);
create index on credit_ledger (workspace_id, created_at desc);
create index on credit_ledger (ref_type, ref_id);

create table invoices (
  id            uuid primary key default gen_random_uuid(),
  workspace_id  uuid not null references workspaces(id) on delete cascade,
  stripe_invoice_id text,
  amount_cents  integer not null,
  currency      text default 'usd',
  status        text,
  pdf_url       text,
  period_start  timestamptz,
  period_end    timestamptz,
  created_at    timestamptz not null default now()
);
create index on invoices (workspace_id, created_at desc);

-- ============================================================================
-- 12. INTEGRATIONS · API KEYS · WEBHOOKS · NOTIFICATIONS · AUDIT
-- ============================================================================

create table integrations (
  id            uuid primary key default gen_random_uuid(),
  workspace_id  uuid not null references workspaces(id) on delete cascade,
  provider      text not null,                     -- 'google_sheets','slack','hubspot','salesforce'
  status        text not null default 'connected',
  account_label text,
  scopes        text[],
  secrets_enc   bytea,                             -- oauth tokens, encrypted
  config        jsonb default '{}'::jsonb,
  created_by    uuid references profiles(id),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index on integrations (workspace_id, provider);

create table api_keys (
  id            uuid primary key default gen_random_uuid(),
  workspace_id  uuid not null references workspaces(id) on delete cascade,
  name          text not null,
  key_prefix    text not null,                     -- shown in UI (fw_live_ab12…)
  key_hash      text not null,                     -- sha256; plaintext shown once
  scopes        text[] default '{}',
  last_used_at  timestamptz,
  created_by    uuid references profiles(id),
  revoked_at    timestamptz,
  created_at    timestamptz not null default now()
);
create index on api_keys (workspace_id);
create index on api_keys (key_hash);

create table webhooks (
  id            uuid primary key default gen_random_uuid(),
  workspace_id  uuid not null references workspaces(id) on delete cascade,
  url           text not null,
  events        text[] not null default '{}',      -- 'message.received','lead.created'...
  secret        text not null default encode(gen_random_bytes(24),'hex'),
  is_active     boolean not null default true,
  created_at    timestamptz not null default now()
);

create table webhook_deliveries (
  id            uuid primary key default gen_random_uuid(),
  workspace_id  uuid not null references workspaces(id) on delete cascade,
  webhook_id    uuid not null references webhooks(id) on delete cascade,
  event         text not null,
  payload       jsonb,
  response_code integer,
  attempts      integer default 0,
  delivered_at  timestamptz,
  created_at    timestamptz not null default now()
);
create index on webhook_deliveries (webhook_id, created_at desc);

create table notifications (
  id            uuid primary key default gen_random_uuid(),
  workspace_id  uuid not null references workspaces(id) on delete cascade,
  user_id       uuid references profiles(id),      -- null = whole workspace
  type          text not null,                     -- 'inbox','campaign','lead','system','credits'
  title         text not null,
  body          text,
  data          jsonb default '{}'::jsonb,
  read_at       timestamptz,
  created_at    timestamptz not null default now()
);
create index on notifications (workspace_id, user_id, created_at desc);

create table audit_log (
  id            uuid primary key default gen_random_uuid(),
  workspace_id  uuid not null references workspaces(id) on delete cascade,
  actor_id      uuid references profiles(id),
  action        text not null,                     -- 'member.role_changed','billing.updated'...
  target_type   text,
  target_id     uuid,
  metadata      jsonb default '{}'::jsonb,
  ip            inet,
  created_at    timestamptz not null default now()
);
create index on audit_log (workspace_id, created_at desc);

-- 12.1 Pre-aggregated dashboard metrics (avoid live COUNT(*) at scale)
create table dashboard_daily_metrics (
  workspace_id  uuid not null references workspaces(id) on delete cascade,
  day           date not null,
  conversations integer default 0,
  messages      integer default 0,
  leads         integer default 0,
  voice_calls   integer default 0,
  credits_used  integer default 0,
  revenue_cents integer default 0,
  primary key (workspace_id, day)
);

-- ============================================================================
-- 13. HELPER FUNCTIONS & TRIGGERS
-- ============================================================================

-- 13.1 updated_at auto-touch
create or replace function touch_updated_at() returns trigger as $$
begin new.updated_at = now(); return new; end; $$ language plpgsql;

do $$ declare t text;
begin
  foreach t in array array[
    'profiles','workspaces','workspace_settings','channel_connections','contacts',
    'leads','conversations','campaigns','workflows','chatbots','cloned_voices',
    'voice_agents','lead_capture_settings','subscriptions','integrations'
  ] loop
    execute format('create trigger %I_touch before update on %I for each row execute function touch_updated_at();', t, t);
  end loop;
end $$;

-- 13.2 On signup: mirror auth.users → profiles
create or replace function handle_new_user() returns trigger as $$
begin
  insert into profiles (id, email, full_name, avatar_url)
  values (new.id, new.email,
          new.raw_user_meta_data->>'full_name',
          new.raw_user_meta_data->>'avatar_url')
  on conflict (id) do nothing;
  return new;
end; $$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function handle_new_user();

-- 13.3 Membership check (used by all RLS policies)
create or replace function is_workspace_member(ws uuid) returns boolean as $$
  select exists (
    select 1 from workspace_members m
    where m.workspace_id = ws and m.user_id = auth.uid() and m.status = 'active'
  );
$$ language sql stable security definer;

-- 13.4 Permission check (feature-level gating)
create or replace function auth_has_permission(ws uuid, perm text) returns boolean as $$
  select exists (
    select 1 from workspace_members m
    where m.workspace_id = ws and m.user_id = auth.uid() and m.status = 'active'
      and (m.role in ('owner','admin')
           or coalesce((m.permissions #>> string_to_array(perm,'.'))::boolean, false))
  );
$$ language sql stable security definer;

-- 13.5 Atomic credit debit (reserve+commit in one call; refund via negative reuse)
create or replace function debit_credits(
  ws uuid, amt integer, p_feature text, p_ref_type text, p_ref_id uuid, p_member uuid default null
) returns integer as $$
declare new_bal integer;
begin
  update credit_wallets
    set balance = balance - amt, updated_at = now()
    where workspace_id = ws and balance >= amt
    returning balance into new_bal;
  if new_bal is null then
    raise exception 'INSUFFICIENT_CREDITS';
  end if;
  insert into credit_ledger(workspace_id, amount, reason, feature, ref_type, ref_id, member_id, balance_after)
    values (ws, -amt, 'debit', p_feature, p_ref_type, p_ref_id, p_member, new_bal);
  return new_bal;
end; $$ language plpgsql security definer;

-- 13.6 Message counters (kept from current app)
create or replace function increment_message_count(contact_id uuid) returns void as $$
begin
  update contacts set message_count = message_count + 1, last_message_at = now()
  where id = contact_id;
end; $$ language plpgsql security definer;

-- 13.7 RAG retrieval
create or replace function match_chunks(kb uuid, query_embedding vector(768), k int default 6)
returns table(id uuid, content text, similarity float) as $$
  select c.id, c.content, 1 - (c.embedding <=> query_embedding) as similarity
  from knowledge_chunks c
  where c.knowledge_base_id = kb
  order by c.embedding <=> query_embedding
  limit k;
$$ language sql stable;

-- ============================================================================
-- 14. ROW LEVEL SECURITY  (deny by default; membership grants)
-- ============================================================================

-- Enable RLS on every tenant table
do $$ declare t text;
begin
  foreach t in array array[
    'workspaces','workspace_members','workspace_settings','invitations',
    'channel_connections','contacts','pipelines','pipeline_stages','leads','activities',
    'conversations','messages','conversation_notes','canned_replies',
    'campaigns','campaign_recipients','workflows','workflow_runs','workflow_run_steps',
    'chatbots','chatbot_prompt_history','cloned_voices','voice_agents','voice_calls','voice_transcripts',
    'lead_capture_settings','lead_capture_leads','knowledge_bases','knowledge_documents',
    'knowledge_chunks','kg_nodes','kg_edges','subscriptions','credit_wallets','credit_ledger',
    'invoices','integrations','api_keys','webhooks','webhook_deliveries','notifications',
    'audit_log','dashboard_daily_metrics'
  ] loop
    execute format('alter table %I enable row level security;', t);
  end loop;
end $$;

-- profiles: a user sees own profile + profiles of co-members
alter table profiles enable row level security;
create policy profiles_self on profiles for all to authenticated
  using (id = auth.uid()) with check (id = auth.uid());

-- workspaces: members can read; owner/admin update
create policy ws_read   on workspaces for select to authenticated using (is_workspace_member(id));
create policy ws_write  on workspaces for update to authenticated using (auth_has_permission(id,'settings.write'));

-- Generic membership policy for all workspace-scoped tables.
-- (Applied per-table so the workspace_id column resolves correctly.)
do $$ declare t text;
begin
  foreach t in array array[
    'workspace_settings','channel_connections','contacts','pipelines','pipeline_stages',
    'leads','activities','conversations','messages','conversation_notes','canned_replies',
    'campaigns','campaign_recipients','workflows','workflow_runs','workflow_run_steps',
    'chatbots','chatbot_prompt_history','cloned_voices','voice_agents','voice_calls',
    'voice_transcripts','lead_capture_settings','lead_capture_leads','knowledge_bases',
    'knowledge_documents','knowledge_chunks','kg_nodes','kg_edges','subscriptions',
    'credit_wallets','credit_ledger','invoices','integrations','api_keys','webhooks',
    'webhook_deliveries','notifications','audit_log','dashboard_daily_metrics'
  ] loop
    execute format($f$
      create policy %1$s_member on %1$I for all to authenticated
        using (is_workspace_member(workspace_id))
        with check (is_workspace_member(workspace_id));
    $f$, t);
  end loop;
end $$;

-- workspace_members: members read; admins manage
create policy wm_read  on workspace_members for select to authenticated using (is_workspace_member(workspace_id));
create policy wm_write on workspace_members for all    to authenticated
  using (auth_has_permission(workspace_id,'team.write'))
  with check (auth_has_permission(workspace_id,'team.write'));

-- invitations: admins manage
create policy inv_admin on invitations for all to authenticated
  using (auth_has_permission(workspace_id,'team.write'))
  with check (auth_has_permission(workspace_id,'team.write'));

-- Sensitive secrets: block direct client reads of secret columns.
-- channel_connections/integrations/api_keys secrets are only touched by
-- service-role code; the member policy above still lets the UI read config,
-- but API layer must project away secrets_enc / key_hash before returning.
-- (Enforce via views or column-level grants in a follow-up migration.)

-- ============================================================================
-- 15. REALTIME PUBLICATION
-- ============================================================================
alter publication supabase_realtime add table messages;
alter publication supabase_realtime add table conversations;
alter publication supabase_realtime add table notifications;
alter publication supabase_realtime add table voice_calls;
alter publication supabase_realtime add table workflow_runs;
alter publication supabase_realtime add table credit_wallets;

-- ============================================================================
-- 16. SEED (default plans)
-- ============================================================================
insert into plans (id,name,monthly_credits,price_cents,stripe_price_id) values
  ('free','Free',1000,0,null),
  ('pro','Pro',10000,4900,null),
  ('business','Business',50000,19900,null)
on conflict (id) do nothing;

-- ============================================================================
-- 17. POST-CREATION PRIVILEGE GRANTS
-- ============================================================================
grant all privileges on all tables in schema public to postgres, service_role;
grant all privileges on all sequences in schema public to postgres, service_role;
grant all privileges on all functions in schema public to postgres, service_role;

-- ============================================================================
-- END OF SCHEMA
-- ============================================================================
